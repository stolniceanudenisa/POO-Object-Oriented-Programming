//
// Created by Liviu Marian Berciu on 02.05.2023.
//

#ifndef SEM5GR312_PRODUS_H
#define SEM5GR312_PRODUS_H
#include <iostream>
using namespace std;

class Produs {
private:
    int cod;
    std::string nume;
    int pret;

public:
    Produs() = default;
    Produs(int cod, string nume, int pret);

    ~Produs() = default;

    virtual string getDescriere() = 0;

    int getCod() const;

    void setCod(int cod);

    const string &getNume() const;

    void setNume(const string &nume);

    int getPret() const;

    void setPret(int pret);
};


#endif //SEM5GR312_PRODUS_H
