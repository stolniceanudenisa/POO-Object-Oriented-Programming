//
// Created by Liviu Marian Berciu on 02.05.2023.
//

#ifndef SEM5GR312_UI_H
#define SEM5GR312_UI_H

#include "Repo.h"
#include "Produs.h"
#include "ProdusSarat.h"
#include "ProdusDulce.h"
#include "UndoStructure.h"

class UI {
private:
    Repo<Produs *> produse;
    Repo<UndoStructure> undoStack;

    int showMenu() {
        int option;
        cout << "Choose your option:" << endl;
        cout << "1. Read." << endl;
        cout << "2. Delete." << endl;
        cout << "3. Undo." << endl;
        cout << "4. Print all." << endl;
        cin >> option;

        return option;
    }

    void addElem() {
        int pret, cod;
        string nume;

        cout << "Read name - price - code: ";
        cin >> nume >> pret >> cod;
        cout << endl;

        cout << "Is it salted or sweet?" << endl;
        int saltedOrSweet;
        cin >> saltedOrSweet;
        ProdusDulce *pd;
        ProdusSarat *ps;
        switch (saltedOrSweet) {
            case 0: // sweet
                pd = new ProdusDulce(cod, nume, pret);
                this->produse.addElement(pd);
                undoStack.addElement(UndoStructure(pd, "delete"));
                break;
            case 1: // salted
                ps = new ProdusSarat(cod, nume, pret);
                this->produse.addElement(ps);
                undoStack.addElement(UndoStructure(ps, "delete"));
                break;
            default:
                break;
        }
    }

    void undo() {
        UndoStructure lastOp = this->undoStack.getLast();

        if (lastOp.opType == "delete") {
            this->produse.deleteElement(lastOp.produs);
        } else {
            cout << "Not implemented yet" << endl;
        }

        cout << "here" << endl;
    }

    void printAll() {
        for (auto p: this->produse.getAll()) {
            cout << p->getNume() << " " << p->getCod() << endl;
        }
    }
public:
    UI() = default;

    void start() {

        while (true) {
            switch(this->showMenu()) {
                case 1:
                    this->addElem();
                    break;
                case 2:
//                    this->deleteElem();
                    break;
                case 3:
                    this->undo();
                    break;
                case 4:
                    this->printAll();
                    break;
                default:
                    return;
            }
        }
    }
};


#endif //SEM5GR312_UI_H
