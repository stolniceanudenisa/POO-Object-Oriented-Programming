#include <iostream>
using namespace std;

#include "Teste.h"
#include "Repo.h"
#include "Produs.h"
#include "ProdusSarat.h"
#include "ProdusDulce.h"
#include "UI.h"

class Animal {
public:
    virtual void doASound() = 0;
//    {
//        cout << "un sunet" << endl;
//    };
};


class Pisica : public Animal {
public:
    void doASound() override {
        cout << "miau" << endl;
    }
};

class Caine: public Animal {
public:
    void doASound() override {
        cout << "mrrr" << endl;
    }
};


template <typename T>
class Container {
private:
    vector<T> elemente;
    T element;

public:
    Container() = default;
    Container(T elem) {
        this->element = elem;
    }

    void addElem(T elem) {
        this->elemente.push_back(elem);
    }

    void printAll() {
        for (const auto el: this->elemente) {
            cout << el << endl;
        }
    }

};

int main() {

    UI u;

    u.start();
//    testProdusSarat();
//    testProdusDulce();

//    Animal a;
//
//    a.doASound();

//    Pisica p;
//    p.doASound();
//
//    Animal &a2 = p;
//
//    a2.doASound();
//
//    Caine c;
//    Animal &a3 = c;

//    c.doASound();
//    Animal &a4 = c;
//
//    c.doASound();

//    vector<Animal*> animale;
//
//    Caine c;
//    Pisica p;
//    animale.push_back(&c);
//    animale.push_back(&p);
//    for (const auto animal: animale){
//        animal->doASound();
//    }
//
//    Container<string> container;
//
//    Container<int> container2;
//
//    container.addElem("5");
//    container.printAll();


//    Repo<Produs*> repoProduse;
//
//    ProdusSarat ps(1, "Covrig", 10);
//    ProdusDulce pd(2, "Strudel", 11);
//
//    repoProduse.addElement(ps);
////    repoProduse.addElement(&pd);
//
//    for (auto p: repoProduse.getAll()) {
//        cout << p.getDescriere() << endl;
//    }

    return 0;

}
