//
// Created by Liviu Marian Berciu on 02.05.2023.
//

#ifndef SEM5GR312_UNDOSTRUCTURE_H
#define SEM5GR312_UNDOSTRUCTURE_H

#include "Produs.h"
class UndoStructure {
public:
    Produs *produs;
    string opType; // delete, add, update

    UndoStructure() = default;
    UndoStructure(Produs *produs, string opType): produs(produs), opType(opType) {}

};


#endif //SEM5GR312_UNDOSTRUCTURE_H
