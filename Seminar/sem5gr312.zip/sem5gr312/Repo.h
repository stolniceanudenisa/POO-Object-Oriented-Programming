//
// Created by Liviu Marian Berciu on 02.05.2023.
//

#ifndef SEM5GR312_REPO_H
#define SEM5GR312_REPO_H

#include <iostream>
using namespace std;
template <typename T>
class Repo {
private:
    vector<T> elements;

public:
    Repo() = default;

    void addElement(T elem);
    void deleteElement(T elem);
    vector<T> getAll();
    T& getLast();
};

template<typename T>
T& Repo<T>::getLast() {
    T& ref = this->elements.at(this->elements.size() - 1);
    this->elements.pop_back();
    return ref;
}

template<typename T>
void Repo<T>::deleteElement(T elem) {
    std::remove(this->elements.begin(), this->elements.end(),elem);
//    this->elements.erase();
}

template<typename T>
vector<T> Repo<T>::getAll() {
    return this->elements;
}

template<typename T>
void Repo<T>::addElement(T elem) {
    this->elements.push_back(elem);
}




#endif //SEM5GR312_REPO_H
