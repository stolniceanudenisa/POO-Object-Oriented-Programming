//
// Created by Liviu Marian Berciu on 02.05.2023.
//

#include "Teste.h"
#include "ProdusSarat.h"
#include "ProdusDulce.h"
#include "cassert"

void testProdusSarat()
{
    ProdusSarat produsSarat(1, "Covrig", 10);
    assert(produsSarat.getDescriere() == "sarat");
}

void testProdusDulce(){
    ProdusDulce produsDulce(1, "cioco", 7);
    assert(produsDulce.getDescriere() == "dulce");
}
