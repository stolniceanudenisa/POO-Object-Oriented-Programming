//
// Created by Liviu Marian Berciu on 02.05.2023.
//

#ifndef SEM5GR312_TESTE_H
#define SEM5GR312_TESTE_H

void testProdusSarat();
void testProdusDulce();

#endif //SEM5GR312_TESTE_H
