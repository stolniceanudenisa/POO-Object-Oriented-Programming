//
// Created by Liviu Marian Berciu on 15.03.2023.
//

#include "Student.h"

using namespace std;

// First we implement a class' constructors
// In order to properly see how constructors are called and
// what is happening behind the scenes, we will log(print) everytime
// a specific constructor is called

// Default constructor
Student::Student() {
    cout << "Default constructor" << endl;
    this->name = NULL;
    this->age = 0;
}

// Parameters constructor
Student::Student(char *name, int age) {
    // We have to allocate the name field, as currently it
    // holds nothing. The SIZE of the allocation will be strlen(name)
    cout << "Parameters constructor" << endl;

    // Allocate, with an extra byte to hold the '\0' character at the end of the string
    this->name = new char[strlen(name) + 1];
    // Copy the contents of name parameter to this->name
    strncpy(this->name, name, strlen(name));
    this->age = age;
}

// Copy constructor
Student::Student(Student& otherStudent) {
    // This type of constructors are good to use when you want
    // to create instances from already existing ones
//    cout << "Copy constructor" << endl;
//    cout << otherStudent.getAge() << " " << otherStudent.getName() << endl;

    this->name = new char[strlen(otherStudent.name) + 1];
    // Copy the contents of name parameter to this->name
    strncpy(this->name, otherStudent.name, strlen(otherStudent.name));
//    cout << this->name << " is correct" << endl;
    this->age = otherStudent.age;
}

// Destructor
Student::~Student() {
    delete[] this->name;
}

// Overloads
Student &Student::operator=(const Student &otherStudent) {
    cout << "Using = operator" << endl;
    if (this == &otherStudent) {
        return *this;
    }

    this->name = new char[strlen(otherStudent.name) + 1];
    // Copy the contents of name parameter to this->name
    strncpy(this->name, otherStudent.name, strlen(otherStudent.name));
    this->age = otherStudent.age;

    return *this;
}

bool Student::operator==(const Student &s){
    return ((strcmp(this->name, s.name) == 0) && (this->age == s.age));
}

// Here, we define the getters/setters that allow us
// to manipulate an object's fields.
// In order to abide by the ENCAPSULATION principle,
// we only modify fields using getters/setters.
int Student::getAge() {
    return this->age;
}

char *Student::getName() {
    return this->name;
}

void Student::setAge(int age) {
    this->age = age;
}

void Student::setName(char *name) {
    // Check if name is already allocated
    if (this->name) {
        // Dealocate it
        delete []this->name;
    }

    this->name = new char[strlen(name) + 1];
    // Copy the contents of name parameter to this->name
    strncpy(this->name, name, strlen(name));
}
