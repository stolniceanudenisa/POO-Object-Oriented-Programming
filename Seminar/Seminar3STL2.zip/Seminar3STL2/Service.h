//
// Created by Liviu Marian Berciu on 28.03.2023.
//

#ifndef SEMINAR3STL2_SERVICE_H
#define SEMINAR3STL2_SERVICE_H


#include "RepoSTL.h"

class Service {
private:
    RepoSTL *repo;

public:
    Service(RepoSTL &repo);

    vector<Student *> filterByAge(int age);

    void addStudent(char *name, int age);
    vector<Student *> sortStudents();

};
#endif //SEMINAR3STL2_SERVICE_H
