//
// Created by Liviu Marian Berciu on 28.03.2023.
//

#include "RepoSTL.h"
using namespace std;

RepoSTL::RepoSTL()
{

}

void RepoSTL::addStudent(char *name, int age) {
    Student *student = new Student(name, age);

    this->students.push_back(student);
}

Student RepoSTL::getStudentAtPosition(int pos) {
    return *this->students.at(pos);
}

vector<Student *> RepoSTL::getAll() {
    return this->students;
}
