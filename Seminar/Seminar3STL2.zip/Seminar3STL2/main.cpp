#include <iostream>

#include "Student.h"
#include "RepoSTL.h"
#include "Service.h"
#include "UI.h"

int main() {
    RepoSTL repo;

    repo.addStudent("Marcel", 45);
    repo.addStudent("Andrei", 30);
//
//    Student stud2 = repo.getStudentAtPosition(0);
//
//    vector<Student *> students = repo.getAll();
//
//    for (int i = 0; i < students.size(); i++) {
//        cout << students[i]->getName() << endl;
//    }

    Service service(repo);

    UI uiApp(service);
//    vector<Student *> results = service.filterByAge(29);

    uiApp.start();

    return 0;
}
