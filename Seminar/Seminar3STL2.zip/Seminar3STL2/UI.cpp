//
// Created by Liviu Marian Berciu on 28.03.2023.
//

#include "UI.h"

UI::UI(Service &service) {
    this->service = &service;
}

void UI::printAllStudentsOrFilter(int age) {
    for (const auto student: this->service->filterByAge(age)) {
        cout << student->getName() << " with age: " << student->getAge() << endl;
    }
}
void UI::printMenu() {
    cout << "Please choose one of the following options:" << endl;
    cout << " 1. Add a student." << endl;
    cout << " 2. Filter students." << endl;
    cout << " 3. Print students." << endl;
    cout << " 4. Sort students." << endl;
    cout << " 5. Exit" << endl;
}

void UI::addStudentToService(char *name, int age) {
    this->service->addStudent(name, age);
}

void UI::sortStudents() {
    for (const auto student: this->service->sortStudents()) {
        cout << student->getName() << " " << student->getAge() << endl;
    }
}
void UI::start() {
    int age;
    char *name;
    while (true)
    {
        this->printMenu();
        int option;
        cin >> option;

        switch (option) {
            case 1:
                name = new char[25];
                cout << "Please input the desired name and age: ";
                cin >> name >> age;
                this->addStudentToService(name, age);
                break;
            case 2:
                cout << "Please input the desired age: ";
                cin >> age;
                cout << endl;
                this->printAllStudentsOrFilter(age);
                break;
            case 3:
                this->printAllStudentsOrFilter(0);
                break;
            case 4:
                cout << "Sorting students..." << endl;
                this->sortStudents();
                break;
            case 5:
                return;
        }
    }

}