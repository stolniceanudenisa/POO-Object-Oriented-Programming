//
// Created by Liviu Marian Berciu on 28.03.2023.
//

#ifndef SEMINAR3STL2_REPOSTL_H
#define SEMINAR3STL2_REPOSTL_H
#include <iostream>
#include <vector>
#include "Student.h"

using namespace std;

class RepoSTL {
private:
    vector<Student *> students;

    // -> return by REFERENCE
    // -> return by VALUE

public:
    RepoSTL();

    void addStudent(char *name, int age);

    Student getStudentAtPosition(int pos);
    vector<Student *> getAll();
};

#endif //SEMINAR3STL2_REPOSTL_H
