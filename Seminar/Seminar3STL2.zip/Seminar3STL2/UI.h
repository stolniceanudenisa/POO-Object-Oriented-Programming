//
// Created by Liviu Marian Berciu on 28.03.2023.
//

#ifndef SEMINAR3STL2_UI_H
#define SEMINAR3STL2_UI_H


#include "Service.h"

class UI {
private:
    Service *service;

    void printMenu();
    void printAllStudentsOrFilter(int age);
    void addStudentToService(char *name, int age);
    void sortStudents();

public:
    UI(Service &service);

    void start();
};


#endif //SEMINAR3STL2_UI_H
