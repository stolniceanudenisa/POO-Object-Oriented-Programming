//
// Created by Liviu Marian Berciu on 28.03.2023.
//

#include "Service.h"

Service::Service(RepoSTL &repo) {
    this->repo = &repo;
}

vector<Student *> Service::filterByAge(int age) {
    // Return all students from Repo
    vector<Student *> students = this->repo->getAll();
//    for (const auto student: students) {
//
//    }
    vector<Student *> results;

    // Parse all students and print/return those with > age
    for (int i = 0; i < students.size(); i++) {
       Student *stud = students.at(i);

       if (stud->getAge() > age) {
           results.push_back(stud);
       }
    }

    return results;
}

void Service::addStudent(char *name, int age) {
    this->repo->addStudent(name, age);
}

bool cmp(Student *a, Student *b) {
    return a->getAge() < b->getAge();
}

bool cmpName(Student *a, Student *b) {
    return strcmp(a->getName(), b->getName());
}


vector<Student *> Service::sortStudents() {
    vector<Student *> students = this->repo->getAll();

    std::sort(students.begin(), students.end(), cmpName);

    return students;
}