#pragma once
#include <exception>

class NotEnoughMoneyException : public std::exception
{
private:
	int requiredMoney;
public:
	NotEnoughMoneyException(int requiredMoney);
	const char* what() const throw();
};

