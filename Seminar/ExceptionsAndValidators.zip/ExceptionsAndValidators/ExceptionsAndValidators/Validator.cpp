#include "Validator.h"

bool Validator::validate(std::string name, int id, int price) throw(InvalidCoinException, InvalidNameException)
{
    if (name.length() < this->minNameLength)
        throw InvalidNameException();
    if (price < lowerPriceRange)
        throw InvalidPriceException();
    if (price > upperPriceRange)
        throw InvalidPriceException();

    return true;
}
