#pragma once
#include <exception>

class InvalidCoinException : public std::exception
{
};

class InvalidNameException : public std::exception
{
};

class InvalidPriceException : public std::exception
{
};

