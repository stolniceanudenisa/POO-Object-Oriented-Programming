// ExceptionsAndValidators.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "NotEnoughMoneyException.h"
#include "InvalidCoinException.h"

void buy(int amount) {

    int available = 5;
    if (amount > available) {
        throw new NotEnoughMoneyException(amount - available);
    }

}

int main()
{
    try {
        buy(10);
    }
    catch (NotEnoughMoneyException* e) {
        std::cout << "EXception:" << e->what()<<"\n";
    }
    catch (InvalidCoinException* e) {
        std::cout << "EXception:" << e->what() << "\n";
    }
    catch (...) {

    }
}

