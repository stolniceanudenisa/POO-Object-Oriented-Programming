#pragma once
#include <string>
#include "InvalidCoinException.h"

class Validator
{
private:
	int lowerPriceRange;
	int upperPriceRange;
	int minNameLength;
public:
	bool validate(std::string name, int id, int price) 
		throw(InvalidCoinException, InvalidNameException);
};

