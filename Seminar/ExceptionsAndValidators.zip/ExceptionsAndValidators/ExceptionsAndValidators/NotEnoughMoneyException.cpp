#include "NotEnoughMoneyException.h"
#include <string>

NotEnoughMoneyException::NotEnoughMoneyException(int requiredMoney)
{
    this->requiredMoney = requiredMoney;
}

const char* NotEnoughMoneyException::what() const throw()
{   
    std::string msg = "Nu putem da rest, avem nevoie de " + std::to_string(this->requiredMoney);
    
    char* msg_c = new char[msg.length()+1];
    strcpy_s(msg_c, msg.length() + 1, msg.c_str());

    const char* res = const_cast<char*>(msg_c);

    return res;
}
