//
// Created by Alexe Andra on 30.03.2023.
//
#include "service.h"
#include <string.h>
Service::Service(Repository & repository1) {
    this -> repository  = repository1;
}

void Service::addStudent(const char * nume, int varsta) {
    Student s(varsta,nume);
    repository.add(s);

}

int Service::findStudent(const char * nume, int varsta) {
    Student s(varsta, nume);
    return repository.findOne(s);
}

int Service::removeStudent(const char * nume, int varsta) {
    Student s(varsta, nume);
    return repository.remove(s);
}

Student *Service::getAllStudents() {
    return repository.getAll();
}

int Service::updateStudent(const char * numeVechi, int varstaVeche, const char * numeNou, int varstaNoua) {
    Student sVechi(varstaVeche, numeVechi), sNou(varstaNoua, numeNou);
    return repository.update(sVechi, sNou);
}

Student *Service::filter(const char * subsir, int limitaVarsta, int &lungimeRezultat) {
    lungimeRezultat = 0;
    Student rez[10];
    Student* studenti = new Student[10];
    studenti = repository.getAll();
    for(int i = 0; i < repository.size(); i++)
        if(strstr(studenti[i].getNume(), subsir) && studenti[i].getVarsta() > limitaVarsta){
            rez[lungimeRezultat++] = studenti[i];
        }
    return rez;
}

Service::~Service() {

}

Service::Service() {

}

int Service::size() {
    return repository.size();
}
