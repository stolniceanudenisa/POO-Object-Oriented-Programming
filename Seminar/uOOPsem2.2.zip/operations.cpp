//
// Created by Alexe Andra on 16.03.2023.
//
#include "student.h"
#include "operations.h"
#include <cstring>
void filtrare(Student students[], int l, int lim, char* sir, Student rez[], int& lrez )
{
    lrez = 0;
    for (int i = 0; i < l; i++) {
        if(students[i].getVarsta() > lim && strstr(students[i].getNume(), sir))
            rez[lrez++] = students[i];
    }
}

