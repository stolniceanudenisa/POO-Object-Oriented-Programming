//
// Created by Alexe Andra on 16.03.2023.
//
#pragma once

#include "student.h"

void filtrare(Student students[], int l, int lim, char*, Student[], int& );
