//
// Created by Alexe Andra on 30.03.2023.
//

#ifndef UOOPSEM2_2_SERVICE_H
#define UOOPSEM2_2_SERVICE_H
#include "repository.h"
class Service{
private:
    Repository repository;
public:
    Service();
    Service(Repository&);
    void addStudent(const char*, int);
    int findStudent(const char*, int);
    int removeStudent(const char*, int);
    Student* getAllStudents();
    int updateStudent(const char*, int, const char*, int);
    Student* filter(const char*, int, int&);
    ~Service();
    int size();


};
#endif //UOOPSEM2_2_SERVICE_H
