//
// Created by Alexe Andra on 30.03.2023.
//
#include "repository.h"

Repository::Repository() {
    this -> length = 0;
}

void Repository::add(Student & student) {
    elem[length++] = student;
}

int Repository::remove(Student & student) {
    int gasit = 0;
    for(int i = 0; i < length && gasit == 0; i++){
        if(elem[i] == student){
            gasit = 1;
            elem[i] = elem[--length];
        }
    }
    return gasit;
}

int Repository::update(Student & studentVechi, Student & studentNou) {
    int i = 0, gasit = 0;
    while(i < length && !gasit){
        if(elem[i] == studentVechi){
            gasit = 1;
            elem[i] = studentNou;
        }
        i++;
    }
    return gasit;
}

bool Repository::findOne(Student & student) {
    int i = 0, gasit = 0;
    while(i < length && !gasit){
        if(elem[i] == student){
            gasit = 1;
        }
        i++;
    }
    return gasit;
}

Student *Repository::getAll() {
    return elem;
}

int Repository::size() {
    return length;
}

Repository::~Repository() {
    length = 0;
}

