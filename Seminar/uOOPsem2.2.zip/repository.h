//
// Created by Alexe Andra on 30.03.2023.
//

#ifndef UOOPSEM2_2_REPOSITORY_H
#define UOOPSEM2_2_REPOSITORY_H
#include "student.h"
class Repository{
private:
    Student elem[10];
    int length;
public:
    Repository();
    void add(Student&);
    int remove(Student&);
    int update(Student&, Student&);
    bool findOne(Student&);
    Student* getAll();
    int size();
    ~Repository();

};
#endif //UOOPSEM2_2_REPOSITORY_H
