//
// Created by Alexe Andra on 30.03.2023.
//

#ifndef UOOPSEM2_2_TESTE_H
#define UOOPSEM2_2_TESTE_H
void testeRepo();
void testeService();
#endif //UOOPSEM2_2_TESTE_H
