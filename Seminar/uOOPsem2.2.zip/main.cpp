#include <iostream>
#include "student.h"
#include "operations.h"
#include "teste.h"
#include "repository.h"
#include "service.h"
#include "ui.h";
using namespace std;

int main() {
    /*Student s(20, "Maria");
    Student s1(25, "Mariana");
    Student s2(18, "Marian");
    Student v[3] = {s, s1, s2};
    Student rez[5];
    int lrez;
    filtrare(v, 3, 19, "Mari", rez, lrez);
    for(int i = 0; i < lrez; i++)
        cout << rez[i].getNume() << " " << rez[i].getVarsta() << endl;

    testeRepo();
    testeService();
     */
    Repository repo;
    Service serv(repo);
    UI ui(serv);
    ui.afisareMeniu();
    return 0;
}
