//
// Created by Alexe Andra on 30.03.2023.
//
#include "teste.h"
#include "assert.h"
#include "repository.h"
#include "student.h"
#include "service.h"
void testeRepo(){
    Repository repository;
    assert(repository.size() == 0);
    Student s(20, "Tudor");
    repository.add(s);
    assert(repository.findOne(s) == true);
}
void testeService(){
    Repository repository;
    Student s(20, "Tudor");
    repository.add(s);
    Student s1(22, "Ioana");
    repository.add(s1);
    Service serv(repository);
    Student* rez = new Student[10];
    int lungimeRezultat = 0;
    rez = serv.filter("oa", 21, lungimeRezultat);
    assert(lungimeRezultat == 1);
    assert(rez[0] == s1);
}