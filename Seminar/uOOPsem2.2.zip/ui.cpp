//
// Created by Alexe Andra on 30.03.2023.
//
#include "ui.h"
#include <iostream>
using namespace std;
void UI::adaugareStudent() {
    cout << "Introduceti numele studentului: ";
    char* nume = new char [10];
    cin.get();
    cin.getline(nume, 10);
    int varsta;
    cout << "Dati varsta studentului: " << endl;
    cin >> varsta;
    this -> service.addStudent(nume, varsta);
    delete [] nume;
}

void UI::cautareStudent() {
    cout << "Introduceti numele studentului: ";
    char* nume = new char [10];
    cin.get(nume, 10);
    int varsta;
    cout << "Dati varsta studentului: ";
    cin >> varsta;
    int rez = this -> service.findStudent(nume,varsta);
    if(rez == 0){
        cout << "Studentul nu exista!" << endl;
    }else{
        cout << "Studentul exista!" << endl;
    }
    delete [] nume;
}

void UI::stergereStudent() {
    cout << "Introduceti numele studentului: ";
    char* nume = new char [10];
    cin.get(nume, 10);
    int varsta;
    cout << "Dati varsta studentului: ";
    cin >> varsta;
    int rez = this -> service.removeStudent(nume,varsta);
    if(rez == 0){
        cout << "Studentul nu exista!" << endl;
    }else{
        cout << "Studentul a fost sters cu succes!" << endl;
    }
    delete [] nume;
}

void UI::actualizareStudent() {
    cout << "Introduceti numele studentului cautat: ";
    char* numeVechi = new char [10];
    cin.get(numeVechi, 10);
    int varstaVeche;
    cout << "Dati varsta studentului cautat: ";
    cin >> varstaVeche;
    cout << "Introduceti numele nou al studentului: ";
    char* numeNou = new char [10];
    cin.get(numeNou, 10);
    int varstaNoua;
    cout << "Dati varsta noua a studentului: ";
    cin >> varstaNoua;
    int rez = this -> service.updateStudent(numeVechi, varstaVeche, numeNou, varstaNoua);
    if(rez == 0){
        cout << "Studentul nu exista!" << endl;
    }else{
        cout << "Studentul a fost actulaizat cu succes!" << endl;
    }
    delete [] numeVechi;
    delete [] numeNou;

}

void UI::afisareStudenti() {
    Student* s = service.getAllStudents();
    for(int i = 0; i < service.size(); i++){
        cout << s[i].getNume() << " " << s[i].getVarsta() << endl;
    }

}

void UI::afisareNumarStudenti() {

}

void UI::filtrareStudenti() {

}

UI::UI(Service & service1) {
    this -> service = service1;
}

UI::~UI() {

}

void UI::afisareMeniu() {
    bool value = true;
    while (value) {
        cout << "Alegeti o optiune: " << endl;
        cout << "1. Adaugare student." << endl;
        cout << "2.Cautare student" << endl;
        cout << "3. Stergere Student" << endl;
        cout << "4.Actualizare" << endl;
        cout << "5.Filtrare" << endl;
        cout << "6.Afisare studenti" << endl;
        cout << "7. Afisare numar" << endl;
        cout << "0.Exit" << endl;
        cout << "Dati optiunea : " << endl;
        int optiune;
        cin >> optiune;
        switch (optiune) {
            case 1:
                adaugareStudent();
                break;
            case 2:
                cautareStudent();
                break;
            case 3:
                stergereStudent();
                break;
            case 4:
                actualizareStudent();
                break;
            case 5:
                filtrareStudenti();
                break;
            case 6:
                afisareStudenti();
                break;
            case 7:
                afisareNumarStudenti();
                break;
            default:
                cout << "La revedere!";
                value = false;

        }
    }
}

UI::UI() {

}
