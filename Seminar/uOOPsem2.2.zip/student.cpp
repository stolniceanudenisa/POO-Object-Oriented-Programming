//
// Created by Alexe Andra on 16.03.2023.
//
#include "student.h"
#include <cstring>
Student::Student(int v,const char* n) {
    this -> varsta = v;
    this -> nume = new char (strlen(n) + 1);
    strcpy(this -> nume, n);
}
Student::Student(const Student & s) {
    this -> varsta = s.varsta;
    this -> nume = new char (strlen(s.nume) + 1);
    strcpy(this -> nume, s.nume);
}

Student::Student() {
    this -> nume = nullptr;
    this -> varsta = 0;
}

int Student::getVarsta() {
    return this -> varsta;
}

const char *Student::getNume() {
    return this -> nume;
}

void Student::setVarsta(int v) {
    this -> varsta = v;
}

void Student::setNume(const char* n) {
    if(this -> nume) delete[] this -> nume;
    this -> nume = new char (strlen(n) + 1);
    strcpy(this -> nume, n);
}

Student &Student::operator=(const Student& s) {
    if(this != &s)
    {
        if(this -> nume) delete[] this -> nume;
        if(s.nume != nullptr) {
            this->nume = new char[strlen(s.nume) + 1];
            strcpy(this->nume, s.nume);
        }
        this -> varsta = s.varsta;
    }
    return *this;
}

bool Student::operator==(const Student& s) {
    return strcmp(this -> nume, s.nume) == 0 && this -> varsta == s.varsta;
}

Student::~Student() {
    if(this -> nume) delete[] this -> nume;
    this -> varsta = 0;
}

