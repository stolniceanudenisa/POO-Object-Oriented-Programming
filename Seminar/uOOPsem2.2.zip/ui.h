//
// Created by Alexe Andra on 30.03.2023.
//

#ifndef UOOPSEM2_2_UI_H
#define UOOPSEM2_2_UI_H
#include "service.h"
class UI{
private:
    Service service;
    void adaugareStudent();
    void cautareStudent();
    void stergereStudent();
    void actualizareStudent();
    void afisareStudenti();
    void afisareNumarStudenti();
    void filtrareStudenti();
public:
    UI();
    UI(Service&);
    ~UI();
    void afisareMeniu();
};
#endif //UOOPSEM2_2_UI_H
