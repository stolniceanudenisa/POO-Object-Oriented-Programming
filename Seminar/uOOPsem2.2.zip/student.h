#pragma once
class Student
{
private:
    int varsta;
    char* nume;
public:
    Student(); //constructor implicit
    Student(int, const char*); //constructor general
    Student(const Student&); //constructor de copiere
    int getVarsta();
    const char* getNume();
    void setVarsta(int);
    void setNume(const char*);
    Student& operator = (const Student&);
    bool operator == (const Student&);
    ~Student();

};