//
// Created by Liviu Marian Berciu on 04.04.2023.
//

#ifndef SEM3PROJ2_REPOVECTOR_H
#define SEM3PROJ2_REPOVECTOR_H

#include <vector>
#include "Student.h"

using namespace std;
class RepoVector {
private:
    vector<Student> students;

public:
    RepoVector() = default;
    ~RepoVector() = default;

    void addStudent(Student &student);
    Student getStudentAtPosition(int pos);
    vector<Student> getAll();

};


#endif //SEM3PROJ2_REPOVECTOR_H
