//
// Created by Liviu Marian Berciu on 04.04.2023.
//

#ifndef SEM3PROJ2_UI_H
#define SEM3PROJ2_UI_H
#include "Service.h"

class UI {
private:
    Service service;

    int printMenu();
    void addStudent();
    void printAll();
    void printOneStudent();
    void filterStudentsByAge();
    void sortStudentsByAge();

public:
    UI(Service &otherService);
    ~UI() = default;

    void start();
};


#endif //SEM3PROJ2_UI_H
