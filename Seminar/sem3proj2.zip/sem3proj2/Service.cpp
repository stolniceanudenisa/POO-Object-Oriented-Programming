//
// Created by Liviu Marian Berciu on 04.04.2023.
//

#include "Service.h"

Service::Service(RepoVector &otherRepo) {
    this->repo = otherRepo;
}

vector<Student> Service::getAll() {
    return this->repo.getAll();
}

void Service::addStudent(Student stud) {
    this->repo.addStudent(stud);
}

Student Service::getStudentAtPos(int position) {
    return this->repo.getStudentAtPosition(position);
}

vector<Student> Service::filterByAge(int age) {
    vector<Student> results;

    for (auto student: this->repo.getAll()){
        if (student.getAge() > age) {
            results.push_back(student);
        }
    }

    return results;
}

bool cmp(Student &a, Student &b) {
    if (a.getAge() == b.getAge()) {
        return strcmp(a.getName(), b.getName());
    }
    return a.getAge() > b.getAge()
}


vector<Student> Service::sortStudents() {
    vector<Student> students = this->repo.getAll();

    std::sort(students.begin(), students.end(), cmp);

    return students;
}
