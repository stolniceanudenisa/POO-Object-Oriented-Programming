#include <iostream>
#include "RepoTemplate.h"
#include "RepoVector.h"
#include "Service.h"
#include "UI.h"

using namespace std;
int main() {
    RepoVector repo;

    Student stud1 = Student("Mihai", 24);
    Student stud2 = Student("Andrei", 20);
    repo.addStudent(stud1);
    repo.addStudent(stud2);
    Service service(repo);
    UI ui(service);

    ui.start();

//    vector<Student> students = repo.getAll();
//    for (int i = 0; i < students.size(); i++){
//        cout << students[i].getName() << endl;
//    }

//    for (auto student : repo.getAll()) {
//        cout << student.getName() << endl;
//    }

//
//    for (auto student : service.getAll()) {
//        cout << student.getName() << endl;
//    }

    return 0;
}
