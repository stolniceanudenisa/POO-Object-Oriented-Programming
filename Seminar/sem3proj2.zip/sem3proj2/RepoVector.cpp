//
// Created by Liviu Marian Berciu on 04.04.2023.
//

#include "RepoVector.h"

Student RepoVector::getStudentAtPosition(int pos) {
    return this->students[pos];
    // return this->students.at(pos);
}

void RepoVector::addStudent(Student &student) {
    this->students.push_back(student);
}

vector<Student> RepoVector::getAll() {
    return this->students;
}
