//
// Created by Liviu Marian Berciu on 04.04.2023.
//

#ifndef SEM3_314_REPOTEMPLATE_H
#define SEM3_314_REPOTEMPLATE_H

#include <vector>
using namespace std;

template <typename T>
class RepoTemplate {
private:
    vector<T> elements;
public:
    RepoTemplate() = default;
    ~RepoTemplate() = default;

    void addElement(T &element);
    T getElementByPosition(int position);
};

template<typename T>
T RepoTemplate<T>::getElementByPosition(int position) {
    return this->elements.at(position);
}


template<typename T>
void RepoTemplate<T>::addElement(T &element) {
    this->elements.push_back(element);
}


#endif //SEM3_314_REPOTEMPLATE_H
