//
// Created by Liviu Marian Berciu on 15.03.2023.
//

#ifndef SEMINAR2_RELOADED_STUDENT_H
#define SEMINAR2_RELOADED_STUDENT_H
#include <iostream>
#define __STDC_WANT_LIB_EXT1__ 1
#include <cstring>


/**
 * This is the Student class
 *
 * It uses Dynamic Allocation to allocate the NAME field
 *
 * As a best practice, fields such as name and age are PRIVATE,
 * while other class methods are PUBLIC.
 */
class Student {
private: // <--- how you declare a private scope
    char *name;
    int age;
    // <-- you can also create private methods in this scope, that can be
    // called only by functions in side the class (either public, private or protected scopes)

public: // <--- here you declare a public scope, everything following it will be public
    // Constructors go first
    Student();
    Student(char *name, int age);
    Student(const Student &otherStudent);
    Student(Student&& other);

    // Destructor, especially important when allocating objects
    ~Student();

    // Overloads
    Student &operator=(const Student &otherStudent);
    bool operator==(const Student &s);

    int getAge();
    char *getName();

    void setAge(int age);
    void setName(char*name);
};


#endif //SEMINAR2_RELOADED_STUDENT_H
