//
// Created by Liviu Marian Berciu on 04.04.2023.
//

#ifndef SEM3PROJ2_SERVICE_H
#define SEM3PROJ2_SERVICE_H
#include "RepoVector.h"

class Service {
private:
    RepoVector repo;

public:
    Service() = default;
    Service(RepoVector &otherRepo);
    ~Service() = default;

    vector<Student> getAll();
    void addStudent(Student stud);
    Student getStudentAtPos(int position);
    vector<Student> filterByAge(int age);
    vector<Student> sortStudents();
};


#endif //SEM3PROJ2_SERVICE_H
