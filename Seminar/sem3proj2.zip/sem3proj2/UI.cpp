//
// Created by Liviu Marian Berciu on 04.04.2023.
//

#include "UI.h"

UI::UI(Service &otherService) {
    this->service = otherService;
}

int UI::printMenu() {
    cout << "Please choose an option:" << endl;
    cout << "1. Add a student" << endl;
    cout << "2. Print all students" << endl;
    cout << "3. Print one specific student" << endl;
    cout << "4. Filter students based on age" << endl;
    cout << "5. Exit" << endl;
    cout << "Your option: ";
    int option;
    cin >> option;
    cout << endl;
    return option;
}

void UI::addStudent() {
    int age;
    char name[100];
    cout << "Input age: ";
    cin >> age;
    cout << endl << "Input name: ";
    cin >> name;
    cout << endl;

    this->service.addStudent(Student(name, age));
}

void UI::printOneStudent() {
    int position;
    cout << "Input student position: ";
    cin >> position;
    cout << endl;
    Student stud = this->service.getStudentAtPos(position);
    cout << stud.getName() << " " << stud.getAge() << endl;
}

void UI::start() {
    int option;

    while(true) {
        option = this->printMenu();

        switch (option) {
            case 1:
                this->addStudent();
                break;
            case 2:
                this->printAll();
                break;
            case 3:
                this->printOneStudent();
                break;
            case 4:
                this->filterStudentsByAge();
                break;
            case 5:
                this->sortStudentsByAge();
                break;
            case 6:
                cout << "Exiting..." << endl;
                return;
        }

    }
}

void UI::printAll() {
    for (auto student: this->service.getAll()) {
        cout << student.getName() << " " << student.getAge() << endl;
    }
}

void UI::filterStudentsByAge() {
    int age;
    cout << "Input age: ";
    cin >> age;
    cout << endl;

    for (auto student: this->service.filterByAge(age)) {
        cout << student.getName() << " " << student.getAge() << endl;
    }
}

void UI::sortStudentsByAge() {
    for (auto student: this->service.sortStudents()) {
        cout << student.getName() << " " << student.getAge() << endl;
    }
}

