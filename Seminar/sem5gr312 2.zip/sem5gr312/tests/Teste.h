//
// Created by Liviu Marian Berciu on 02.05.2023.
//

#ifndef SEM5GR312_TESTE_H
#define SEM5GR312_TESTE_H
#include "cassert"
#include "../models/ProdusSarat.h"
#include "../models/ProdusDulce.h"
#include "../repositories/Repo.h"


class Teste {
public:

    static void testRepoProdus() {
        Repo repo;

        ProdusSarat *ps = new ProdusSarat(5, "ceapa", 5);
        ProdusDulce *pd = new ProdusDulce(1, "ciocolata", 1);

        repo.addElement(ps);
        repo.addElement(pd);

        assert(repo.getAll().size() == 2);
        assert(repo.getLast()->getNume() == "ciocolata");
        std::cout << "Tests for repo passed." << endl;
    }

    static void runAllTests() {
        Teste::testRepoProdus();
    }
};

#endif //SEM5GR312_TESTE_H
