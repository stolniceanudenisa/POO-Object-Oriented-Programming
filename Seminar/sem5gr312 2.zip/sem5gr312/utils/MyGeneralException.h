//
// Created by Liviu Marian Berciu on 16.05.2023.
//

#ifndef SEM5GR312_MYGENERALEXCEPTION_H
#define SEM5GR312_MYGENERALEXCEPTION_H
#include <iostream>


class MyGeneralException: public std::exception {
private:
    std::string message;
public:
    MyGeneralException(std::string message): message(message){}

    const char *what() const noexcept override {
        return message.c_str();
    }
};


#endif //SEM5GR312_MYGENERALEXCEPTION_H
