//
// Created by Liviu Marian Berciu on 16.05.2023.
//

#ifndef SEM5GR312_VALIDATOR_H
#define SEM5GR312_VALIDATOR_H
#include <iostream>
#include <string>
#include "MyGeneralException.h"
#include "MyCustomNumberException.h"

class Validator {
public:
    static int isNumber(std::string possible_number) {
        try {
            return std::stoi(possible_number);
        } catch (std::exception e) { // <- bad practice
            throw MyCustomNumberException("Received parameter " + possible_number + " is not a number");
        }
    }

    static int isSaltedOrSweet(std::string option) {
        if (option == "salted") {
            return 1;
        } else if (option == "sweet") {
            return 0;
        } else {
            throw MyGeneralException("You have to select between salted or sweet.");
        }
    }
};


#endif //SEM5GR312_VALIDATOR_H
