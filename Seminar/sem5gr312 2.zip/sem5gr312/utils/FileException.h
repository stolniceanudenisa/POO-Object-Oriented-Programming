//
// Created by Liviu Marian Berciu on 16.05.2023.
//

#ifndef SEM5GR312_FILEEXCEPTION_H
#define SEM5GR312_FILEEXCEPTION_H

#include <iostream>

class FileException: public std::exception {

public:
    const char * what() const noexcept override {
        return "Could not open file!";
    }
};


#endif //SEM5GR312_FILEEXCEPTION_H
