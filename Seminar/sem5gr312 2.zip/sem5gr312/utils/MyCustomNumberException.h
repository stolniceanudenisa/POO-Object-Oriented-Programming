//
// Created by Liviu Marian Berciu on 16.05.2023.
//

#ifndef SEM5GR312_MYCUSTOMNUMBEREXCEPTION_H
#define SEM5GR312_MYCUSTOMNUMBEREXCEPTION_H
#include <iostream>

class MyCustomNumberException: public std::exception {
private:
    std::string message;
public:
    MyCustomNumberException(std::string message): message(message){}

    const char *what() const noexcept override {
        return message.c_str();
    }
};

#endif //SEM5GR312_MYCUSTOMNUMBEREXCEPTION_H
