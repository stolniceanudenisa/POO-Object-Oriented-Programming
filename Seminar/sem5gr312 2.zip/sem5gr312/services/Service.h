//
// Created by Liviu Marian Berciu on 16.05.2023.
//

#ifndef SEM5GR312_SERVICE_H
#define SEM5GR312_SERVICE_H


class Service {
private:

};


#endif //SEM5GR312_SERVICE_H
