//
// Created by Liviu Marian Berciu on 16.05.2023.
//

#ifndef SEM5GR312_REPO_H
#define SEM5GR312_REPO_H
#include "../models/Produs.h"

class Repo {
private:
    vector<Produs *> elements;

public:
    Repo() = default;

    void addElement(Produs *elem);
    void deleteElement(Produs * elem);
    vector<Produs *> getAll();
    Produs * getLast();
};

#endif //SEM5GR312_REPO_H
