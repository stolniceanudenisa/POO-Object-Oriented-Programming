//
// Created by Liviu Marian Berciu on 16.05.2023.
//

#ifndef SEM5GR312_GENERICREPOFILE_H
#define SEM5GR312_GENERICREPOFILE_H


#include "GenericRepo.h"
#include "../models/Produs.h"
#include "../models/ProdusDulce.h"
#include "../models/ProdusSarat.h"
#include "../utils/FileException.h"
#include <fstream>
#include <sstream>

using namespace std;

class GenericRepoFile: public GenericRepo<Produs*> {
private:
    string fileName;
    fstream f_descriptor;

public:
    GenericRepoFile() {
        f_descriptor.open("myFile.txt", std::ios::in | std::ios::out);
    }

    GenericRepoFile(string fileName): fileName(fileName) {
        f_descriptor.open(fileName, std::ios::in | std::ios::out);
    }

    ~GenericRepoFile() {
        if (this->f_descriptor.is_open()) {
            this->f_descriptor.close();
        }
    }

    void loadFromFile() {

        if (!f_descriptor.is_open()) {
            throw FileException();
        }

        std::string line;
        while (getline(this->f_descriptor, line)) {
            std::istringstream iss(line);

            string name;
            string age;
            string sarat_sau_dulce;
            ProdusDulce *produsDulce;
            ProdusSarat *produsSarat;

            if(getline(iss, age, ',') && getline(iss, name, ',') && getline(iss, sarat_sau_dulce, ',')) {
                int parsed_age = std::stoi(age);
                int parsed_sarat_sau_dulce = std::stoi(sarat_sau_dulce);
                switch (parsed_sarat_sau_dulce) {
                    case 1:
                        produsDulce = new ProdusDulce(1, name, parsed_age);
                        this->addElement(produsDulce);
                        break;
                    case 2:
                        produsSarat = new ProdusSarat(1, name, parsed_age);
                        this->addElement(produsSarat);
                        break;
                    default:
                        throw std::invalid_argument("Wrong product received");
                        break;
                }
                }
            }

        }

};


#endif //SEM5GR312_GENERICREPOFILE_H
