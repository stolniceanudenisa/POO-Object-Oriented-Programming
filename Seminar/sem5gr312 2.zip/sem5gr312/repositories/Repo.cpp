//
// Created by Liviu Marian Berciu on 16.05.2023.
//

#include "Repo.h"


Produs* Repo::getLast() {
    Produs *ref = this->elements.at(this->elements.size() - 1);
    this->elements.pop_back();
    return ref;
}

void Repo::deleteElement(Produs *elem) {
//    std::find(this->elements.begin(), this->elements.end(), elem);
    int idx = 0;
    for (const auto &current_elem: this->elements){
        if (elem == current_elem) {
            break;
        }
        idx++;
    }

    this->elements.erase(this->elements.begin() + idx);
//    std::remove(this->elements.begin(), this->elements.end(),elem);
//    this->elements.erase();
}

vector<Produs *> Repo::getAll() {
    return this->elements;
}

void Repo::addElement(Produs* elem) {
    this->elements.push_back(elem);
}