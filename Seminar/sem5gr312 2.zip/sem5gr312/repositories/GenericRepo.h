//
// Created by Liviu Marian Berciu on 02.05.2023.
//

#ifndef SEM5GR312_GENERICREPO_H
#define SEM5GR312_GENERICREPO_H

#include <iostream>
using namespace std;
template <typename T>
class GenericRepo {
private:
    vector<T> elements;

public:
    GenericRepo() = default;

    void addElement(T elem);
    void deleteElement(T elem);
    vector<T> getAll();
    T& getLast();
};

template<typename T>
T& GenericRepo<T>::getLast() {
    T& ref = this->elements.at(this->elements.size() - 1);
    this->elements.pop_back();
    return ref;
}

template<typename T>
void GenericRepo<T>::deleteElement(T elem) {
//    std::find(this->elements.begin(), this->elements.end(), elem);
        int idx = 0;
      for (const auto &current_elem: this->elements){
          if (elem == current_elem) {
              break;
          }
          idx++;
      }

      this->elements.erase(this->elements.begin() + idx);
//    std::remove(this->elements.begin(), this->elements.end(),elem);
//    this->elements.erase();
}

template<typename T>
vector<T> GenericRepo<T>::getAll() {
    return this->elements;
}

template<typename T>
void GenericRepo<T>::addElement(T elem) {
    this->elements.push_back(elem);
}




#endif //SEM5GR312_GENERICREPO_H
