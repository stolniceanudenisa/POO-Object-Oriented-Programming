//
// Created by Liviu Marian Berciu on 02.05.2023.
//

#ifndef SEM5GR312_PRODUSDULCE_H
#define SEM5GR312_PRODUSDULCE_H


#include "Produs.h"

class ProdusDulce : public Produs {
public:
    ProdusDulce() = default;
    ProdusDulce(int cod, string nume, int pret);

    string getDescriere() override;
};


#endif //SEM5GR312_PRODUSDULCE_H
