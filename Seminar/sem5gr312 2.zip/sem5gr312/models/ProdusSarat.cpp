//
// Created by Liviu Marian Berciu on 02.05.2023.
//

#include "ProdusSarat.h"

ProdusSarat::ProdusSarat(int cod, string nume, int pret) : Produs(cod, nume, pret) {

}

string ProdusSarat::getDescriere() {
    cout<<"acesta este un produs sarat "<<this->getNume()<<endl;
    return "sarat";
}
