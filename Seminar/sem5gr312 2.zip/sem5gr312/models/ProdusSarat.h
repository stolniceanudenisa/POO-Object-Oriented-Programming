//
// Created by Liviu Marian Berciu on 02.05.2023.
//

#ifndef SEM5GR312_PRODUSSARAT_H
#define SEM5GR312_PRODUSSARAT_H

#include "Produs.h"
class ProdusSarat:public Produs {
public:
    ProdusSarat()=default;
    ProdusSarat(int cod, string nume, int pret);

 string getDescriere() override;
};


#endif //SEM5GR312_PRODUSSARAT_H
