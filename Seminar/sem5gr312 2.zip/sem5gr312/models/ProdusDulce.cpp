//
// Created by Liviu Marian Berciu on 02.05.2023.
//

#include "ProdusDulce.h"

ProdusDulce::ProdusDulce(int cod, string nume, int pret) : Produs(cod, nume, pret) {

}

string ProdusDulce::getDescriere() {
    cout<<"Acesta este un produs dulce! "<<this->getNume()<<endl;
    return "dulce";
}
