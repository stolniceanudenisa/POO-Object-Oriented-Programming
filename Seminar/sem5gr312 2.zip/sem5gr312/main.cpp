#include <iostream>
using namespace std;

#include "tests/Teste.h"

//class Animal {
//public:
//    virtual void doASound() = 0;
////    {
////        cout << "un sunet" << endl;
////    };
//};
//
//
//class Pisica : public Animal {
//public:
//    void doASound() override {
//        cout << "miau" << endl;
//    }
//};
//
//class Caine: public Animal {
//public:
//    void doASound() override {
//        cout << "mrrr" << endl;
//    }
//};
//
//
//template <typename T>
//class Container {
//private:
//    vector<T> elemente;
//    T element;
//
//public:
//    Container() = default;
//    Container(T elem) {
//        this->element = elem;
//    }
//
//    void addElem(T elem) {
//        this->elemente.push_back(elem);
//    }
//
//    void printAll() {
//        for (const auto el: this->elemente) {
//            cout << el << endl;
//        }
//    }
//
//};

int main() {
    Teste::runAllTests();
//    UI u;
//
//    u.start();
//    string possibleNumber;

//    while(true) {
//        try {
//            cout << "Read number:";
//            cin >> possibleNumber;
//            cout << endl;
//            Validator::isNumber(possibleNumber);
//        } catch (MyCustomNumberException& e) {
//            cout << e.what() << endl;
//        }
//    }
//    GenericRepoFile repoFile("myFile.txt");
//    repoFile.loadFromFile();
    return 0;

}
