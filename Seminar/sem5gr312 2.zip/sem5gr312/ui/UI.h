//
// Created by Liviu Marian Berciu on 02.05.2023.
//

#ifndef SEM5GR312_UI_H
#define SEM5GR312_UI_H

#include "../repositories/GenericRepo.h"
#include "../models/Produs.h"
#include "../models/ProdusSarat.h"
#include "../models/ProdusDulce.h"
#include "../models/UndoStructure.h"
#include "../utils/Validator.h"
#include "../repositories/GenericRepoFile.h"

class UI {
private:
    GenericRepoFile produseRepo;
    GenericRepo<UndoStructure> undoStack;

    int showMenu() {
        string raw_option;
        cout << "Choose your option:" << endl;
        cout << "1. Read." << endl;
        cout << "2. Delete." << endl;
        cout << "3. Undo." << endl;
        cout << "4. Print all." << endl;
        cin >> raw_option;

        int option = Validator::isNumber(raw_option);

        return option;
    }

    void addElem() {
        string raw_pret, raw_cod, nume;

        cout << "Read name - price - code: ";
        cin >> nume >> raw_pret >> raw_cod;
        cout << endl;

        cout << "Is it salted or sweet?" << endl;
        string raw_saltedOrSweet;
        cin >> raw_saltedOrSweet;

        int pret = Validator::isNumber(raw_pret);
        int cod = Validator::isNumber(raw_cod);
        int saltedOrSweet = Validator::isSaltedOrSweet(raw_saltedOrSweet);

        ProdusDulce *pd;
        ProdusSarat *ps;

        switch (saltedOrSweet) {
            case 0: // sweet
                pd = new ProdusDulce(cod, nume, pret);
                this->produseRepo.addElement(pd);
                undoStack.addElement(UndoStructure(pd, "delete"));
                break;
            case 1: // salted
                ps = new ProdusSarat(cod, nume, pret);
                this->produseRepo.addElement(ps);
                undoStack.addElement(UndoStructure(ps, "delete"));
                break;
            default:
                break;
        }
    }

    void undo() {
        UndoStructure lastOp = this->undoStack.getLast();

        if (lastOp.opType == "delete") {
            this->produseRepo.deleteElement(lastOp.produs);
        } else {
            cout << "Not implemented yet" << endl;
        }

        cout << "here" << endl;
    }

    void printAll() {
        for (auto p: this->produseRepo.getAll()) {
            cout << p->getNume() << " " << p->getCod() << endl;
        }
    }
public:
    UI() = default;

    void start() {
        this->produseRepo.loadFromFile();

        while (true) {
            try {
                switch (this->showMenu()) {
                    case 1:
                        this->addElem();
                        break;
                    case 2:
//                    this->deleteElem();
                        break;
                    case 3:
                        this->undo();
                        break;
                    case 4:
                        this->printAll();
                        break;
                    default:
                        return;
                }
            } catch (std::exception &e) {
//                cout << "a crapat?" << endl;
                cout << e.what() << endl;
            }
        }
    }
};


#endif //SEM5GR312_UI_H
