//
// Created by Liviu Marian Berciu on 25.04.2023.
//

#ifndef SEM4GR314_STUDENTBURSIER_H
#define SEM4GR314_STUDENTBURSIER_H
#include "Student.h"

class StudentBursier: public Student {
private:
    string iban;
public:
    StudentBursier() = default;
    StudentBursier(string name, int age, string iban);
    StudentBursier(const StudentBursier& other);
    StudentBursier(const StudentBursier&& other);
    std::string getIban() const;

    void setIban(std::string iban);
    StudentBursier& operator=(const StudentBursier &student);
};


#endif //SEM4GR314_STUDENTBURSIER_H
