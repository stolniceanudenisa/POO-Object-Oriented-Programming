//
// Created by Liviu Marian Berciu on 25.04.2023.
//

#include "repo.h"
void Repo::add_student(StudentBursier &student) {
    this->studenti.push_back(student);
}

std::vector<StudentBursier> Repo::getAll() {
    return this->studenti;
}
