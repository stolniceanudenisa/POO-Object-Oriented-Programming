//
// Created by Liviu Marian Berciu on 25.04.2023.
//

#ifndef SEM4GR314_SERVICE_H
#define SEM4GR314_SERVICE_H
#include "repo.h"

class Service {
private:
    Repo repo;

public:
    Service() = default;
    Service(Repo &repo);
    ~Service() = default;
    void addStudent(string name, int age, string iban);
    std::vector<StudentBursier> getAll();
};


#endif //SEM4GR314_SERVICE_H
