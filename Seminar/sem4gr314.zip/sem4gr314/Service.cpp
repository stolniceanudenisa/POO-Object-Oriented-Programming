//
// Created by Liviu Marian Berciu on 25.04.2023.
//

#include "Service.h"

void Service::addStudent(string name, int age, string iban) {
    StudentBursier student(name, age, iban);
    repo.add_student(student);
}

Service::Service(Repo &repo) {
    this->repo = repo;
}

std::vector<StudentBursier> Service::getAll() {
    return this->repo.getAll();
}
