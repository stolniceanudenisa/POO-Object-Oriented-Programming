//
// Created by Liviu Marian Berciu on 25.04.2023.
//

#include "UI.h"

void UI::start() {
    int opt;

    while(true){
        this->print_menu();
        cin>>opt;
        switch (opt) {
            case 1:
                adding();
                break;
            case 2:
                this->afisare_studenti();
                break;
            default:
                return;
        }
    }
}

UI::UI(Service &service) {
    this->service = service;
}

void UI::print_menu() {
    ::printf("1-Adaugare.");
    ::printf("2-Show all.");
}

void UI::adding() {
    string name, iban;
    int age;
    cin>>name>>age>>iban;
    this->service.addStudent(name, age, iban);
}

void UI::afisare_studenti() {
    for (auto student: this->service.getAll()) {
        cout << student.getName() << " " << student.getAge() << " " << student.getIban() << endl;
    }
}