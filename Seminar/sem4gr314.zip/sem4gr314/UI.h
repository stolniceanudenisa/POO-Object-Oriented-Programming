//
// Created by Liviu Marian Berciu on 25.04.2023.
//

#ifndef SEM4GR314_UI_H
#define SEM4GR314_UI_H
#include "Service.h"

class UI {
private:
    Service service;
    void print_menu();
    void adding();
    void afisare_studenti();

public:
    void start();
    UI(Service &service);
    ~UI() = default;

};


#endif //SEM4GR314_UI_H
