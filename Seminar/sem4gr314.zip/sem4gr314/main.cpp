#include <iostream>
#include "Student.h"
#include "StudentBursier.h"
#include "teste.h"
#include "repo.h"
#include "Service.h"
#include "UI.h"

int main() {
    testStudentBursier();

    Student stud;
    Student stud2("Ana", 20);
    Student stud3 = stud2;
    stud3 = stud2;
    StudentBursier Andrei("Andrei", 20, "abcdefsad");
    Repo repo;
    repo.add_student(Andrei);
    Service service(repo);
    service.addStudent("Andrei", 40, "efg");
    UI ui(service);
    ui.start();
    return 0;
}
