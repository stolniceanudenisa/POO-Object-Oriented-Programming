//
// Created by Liviu Marian Berciu on 25.04.2023.
//

#include "StudentBursier.h"

StudentBursier::StudentBursier(string name, int age, string iban):Student(name,age) {
    this->iban = iban;
}

StudentBursier& StudentBursier::operator=(const StudentBursier &student){
    if(this == &student){
        return *this;
    }
    this->iban = student.iban;
    return *this;
}

StudentBursier::StudentBursier(const StudentBursier& other): Student(other) {
    this->iban = other.iban;
}

std::string StudentBursier::getIban() const {
    return this -> iban;
}

void StudentBursier::setIban(std::string iban) {
    this -> iban = iban;
}