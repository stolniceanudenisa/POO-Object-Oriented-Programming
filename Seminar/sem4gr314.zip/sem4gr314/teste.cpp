//
// Created by Liviu Marian Berciu on 25.04.2023.
//

#include "teste.h"

void testStudentBursier()
{
    StudentBursier stud1("Marcel", 10, "abcdefg");
    stud1.setIban("bcd");
    assert(stud1.getIban() == "bcd");

    StudentBursier stud2(stud1);
}