//
// Created by Liviu Marian Berciu on 25.04.2023.
//

#ifndef SEM4GR314_REPO_H
#define SEM4GR314_REPO_H
#include "StudentBursier.h"

class Repo {
private:
    std::vector<StudentBursier>studenti;
public:
    Repo()=default;
    ~Repo()=default;
    void add_student(StudentBursier &student);
    std::vector<StudentBursier> getAll();
};


#endif //SEM4GR314_REPO_H
