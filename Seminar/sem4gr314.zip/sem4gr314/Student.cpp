//
// Created by Liviu Marian Berciu on 25.04.2023.
//

#include "Student.h"

Student::Student(const string &name, int age) : name(name), age(age) {
    cout << "Parameters constructor" << endl;
}

Student::Student() {
    cout << "Default constructor" << endl;
    this->name = "";
    this->age = 0;
}

Student::Student(const Student &other) {
    cout << "Copy constructor" << endl;
    this->name = other.name;
    this->age = other.age;
}

Student::Student(Student &&other): name(""), age(0) {
    cout << "Move cnstructor" << endl;
    this->name = other.name;
    this->age = other.age;
}

Student& Student::operator=(const Student& other) {
    cout << "Operator = " << endl;
    if (&other == this) {
        return *this;
    }
    this->name = other.name;
    this->age = other.age;

    return *this;
}

const string &Student::getName() const {
    return name;
}

void Student::setName(const string &name) {
    Student::name = name;
}

int Student::getAge() const {
    return age;
}

void Student::setAge(int age) {
    Student::age = age;
}
