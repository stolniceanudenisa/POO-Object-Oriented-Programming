//
// Created by Liviu Marian Berciu on 25.04.2023.
//

#ifndef SEM4GR314_STUDENT_H
#define SEM4GR314_STUDENT_H
#include <iostream>

using namespace std;
class Student {
private:
    string name;
    int age;

public:
    Student();
    Student(const string &name, int age);
    Student(const Student &other);
    Student(Student &&other);
    Student& operator=(const Student& other);

    const string &getName() const;

    void setName(const string &name);

    int getAge() const;

    void setAge(int age);
};


#endif //SEM4GR314_STUDENT_H
