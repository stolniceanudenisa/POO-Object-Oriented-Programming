//
// Created by Liviu Marian Berciu on 25.04.2023.
//

#ifndef SEM4GR314_TESTE_H
#define SEM4GR314_TESTE_H

#include "StudentBursier.h"

void testStudentBursier();


#endif //SEM4GR314_TESTE_H
