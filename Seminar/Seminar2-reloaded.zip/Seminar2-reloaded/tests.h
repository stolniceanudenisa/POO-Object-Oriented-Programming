//
// Created by Liviu Marian Berciu on 16.03.2023.
//

#ifndef SEMINAR2_RELOADED_TESTS_H
#define SEMINAR2_RELOADED_TESTS_H

void testStudentClass();
void testStudentRepo();

#endif //SEMINAR2_RELOADED_TESTS_H
