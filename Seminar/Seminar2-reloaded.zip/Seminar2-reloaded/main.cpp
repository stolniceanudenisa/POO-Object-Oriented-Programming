#include <iostream>
#include "Student.h"
#include "tests.h"

int main() {
    // Run tests
    testStudentClass();
    testStudentRepo();

    // Start creating students using all the constructors available
    // Default
    Student student1;
//    std::cout << student1.getName() << std::endl; <-- this will crash as we attempt to log a NULL pointer

    // Parameters
    Student student2("Mihai", 26);
    std::cout << "Initialized with params: " <<  student2.getName() << std::endl;

    // Copy
    Student student3(student2);
    std::cout << student3.getName() << std::endl;

    // = operator
    Student student4;
    student4 = Student("Darius", 20); // <-- first the object is created, then assigned to student4
    std::cout << student4.getName() << std::endl;

    // Dynamically alocated, let's see what happens
    Student *student5 = new Student();
//    std::cout << student5->getName() << std::endl; <-- this crashes as it attempts to print NULL pointer

    Student *student6 = new Student("Marcel", 30);
    std::cout << student6->getName() << " " << (*student6).getAge() << std::endl;

    // Allocate an array of students
    std::cout << "Start array allocation" << std::endl;
    Student *students = new Student[10];
    std::cout << "Address of students: " << students << std::endl;
    // Add previous students
    std::cout << "Add existing students" << std::endl;
    students[0] = student2;
    students[1] = student3;
    students[2] = *student6;

    std::cout << students[0].getName() << std::endl;

    // If you ran the code, you observed that the allocation created 10 default students,
    // for which the addresses will be saved in the array
    // then used the = operator to assign the already existing students to the positions
    // of the array

    // Initialize a static array of students, which does the same thing as above, except the allocation
    // is done on the stack
    Student studentsStatic[10];
    std::cout << "Address of studentsStatic: " << &studentsStatic << std::endl;
    studentsStatic[0] = student2;
    studentsStatic[1] = student3;
    studentsStatic[2] = *student6;

    return 0;
}
