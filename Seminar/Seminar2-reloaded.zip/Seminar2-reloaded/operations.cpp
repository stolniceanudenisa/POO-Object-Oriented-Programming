//
// Created by Liviu Marian Berciu on 16.03.2023.
//

#include "operations.h"

// filter all the students of a given name and older than a given limit
// In: an array of students and their number (integer), a name (String), an age (integer)
// Out: an array of filtered students and their number (integer)
void filterStudents(Student students[], int n, char* s, int a, Student studFilter[], int &m){
    m = 0;
    for(int i = 0; i < n; i++){
        if ((strcmp(s, students[i].getName()) == 0) && (students[i].getAge() >= a)){
            studFilter[m++] = students[i];
        }
    }
}

// filter all the students of a given name and older than a given limit
// In: an array of students and their number (integer), a name (String), an age (integer)
// Out: an array of filtered students and their number (integer)
void filterStudentsWithRepo(StudentRepository &rep, char* s, int a, Student studFilter[], int &m){
    for(int i = 0; i < rep.getCurrentSize(); i++){
        Student crtStudent = rep.getStudentByPosition(i);
        if ((strcmp(s, crtStudent.getName()) == 0) && (crtStudent.getAge() >= a)){
            studFilter[m++] = crtStudent;
        }
    }
}