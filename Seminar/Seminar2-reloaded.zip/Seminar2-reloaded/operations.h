//
// Created by Liviu Marian Berciu on 16.03.2023.
//

#ifndef SEMINAR2_RELOADED_OPERATIONS_H
#define SEMINAR2_RELOADED_OPERATIONS_H
#include "StudentRepository.h"

void filterStudents(Student students[], int n, char* s, int a, Student studFilter[], int &m);
void filterStudentsWithRepo(StudentRepository &rep, char* s, int a, Student studFilter[], int &m);

#endif //SEMINAR2_RELOADED_OPERATIONS_H
