//
// Created by Liviu Marian Berciu on 16.03.2023.
//

#include "tests.h"
#include "Student.h"
#include "cassert"
#include "StudentRepository.h"
#include "operations.h"

void testStudentClass() {
    Student student1;
    assert(student1.getAge() == 0);
    assert(student1.getName() == nullptr);

    // Parameters
    Student student2("Mihai", 26);
    assert(strcmp(student2.getName(),"Mihai") == 0);
    assert(student2.getAge() == 26);

    // Copy
    Student student3(student2);
    assert(strcmp(student3.getName(),"Mihai") == 0);
    assert(student3.getAge() == 26);

    // = operator
    Student student4;
    student4 = Student("Darius", 20); // <-- first the object is created, then assigned to student4
    assert(strcmp(student4.getName(),"Darius") == 0);
    assert(student4.getAge() == 20);


    Student *student6 = new Student("Marcel", 30);
    assert(strcmp(student6->getName(),"Marcel") == 0);
    assert(student6->getAge() == 30);

    Student studentsStatic[10];
    studentsStatic[0] = student2;
    studentsStatic[1] = student3;
    studentsStatic[2] = *student6;
    assert(strcmp(studentsStatic[0].getName(),student2.getName()) == 0);
    assert(studentsStatic[0].getAge() == student2.getAge());
    // ^ do the same for the other elements
    std::cout << "************* TESTS PASSED SUCCESFULLY *************" << std::endl;
}

void testStudentRepo() {
    StudentRepository repo;

    repo.addNewStudent(Student("Mircea", 25));
    repo.addNewStudent(Student("Andrei", 26));
    repo.addNewStudent(Student("Mirel", 27));
    repo.addNewStudent(Student("Gheorghe", 28));

    assert(strcmp(repo.getStudentByPosition(0).getName(), "Mircea") == 0);
    assert(strcmp(repo.getStudentByPosition(1).getName(), "Andrei") == 0);
    assert(strcmp(repo.getStudentByPosition(2).getName(), "Mirel") == 0);
    assert(strcmp(repo.getStudentByPosition(3).getName(), "Gheorghe") == 0);

    int repoSize = repo.getCurrentSize();
    assert(repoSize == 4);

    Student *results = new Student[4];
    int resultsSize = 0;

    filterStudentsWithRepo(repo, "Mircea", 19, results, resultsSize);
    assert ((resultsSize == 1) && (results[0] == repo.getStudentByPosition(0)));
    std::cout << "************* REPO TESTS PASSED SUCCESFULLY *************" << std::endl;
}