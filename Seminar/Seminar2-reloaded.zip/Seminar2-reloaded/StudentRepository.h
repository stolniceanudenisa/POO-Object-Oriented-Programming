//
// Created by Liviu Marian Berciu on 16.03.2023.
//

#ifndef SEMINAR2_RELOADED_STUDENTREPOSITORY_H
#define SEMINAR2_RELOADED_STUDENTREPOSITORY_H
#include "Student.h"

// For this version of repo, we will use a dinamically alocated one
// You already have the static version in the Seminary file
class StudentRepository {
private:
    Student *students;
    int currentSize = 0;
    int maxSize = 1;

public:
    StudentRepository();
    ~StudentRepository();

    void addNewStudent(const Student &student);
    Student &getStudentByPosition(int position);
    Student *getAllStudents();

    int getCurrentSize();
};


#endif //SEMINAR2_RELOADED_STUDENTREPOSITORY_H
