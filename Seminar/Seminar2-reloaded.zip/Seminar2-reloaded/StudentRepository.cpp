//
// Created by Liviu Marian Berciu on 16.03.2023.
//

#include "StudentRepository.h"

StudentRepository::StudentRepository() {
    this->students = new Student[this->maxSize];
}

void StudentRepository::addNewStudent(const Student &student) {
    if (this->currentSize + 1 > this->maxSize) {
        // We don't have enough space, we need to make more
        // Create a new students array where we will save the old ones
        Student *newStudents = new Student[this->maxSize * 2 + 1];
        this->maxSize = this->maxSize * 2 + 1;

        // Copy old students to new students array
        for (int i = 0; i < this->currentSize; i++) {
            newStudents[i] = this->students[i];
        }

        // deallocate old object
        delete[] this->students;

        // set newObject as the correct array
        this->students = newStudents;
    }

    this->students[this->currentSize++] = student;
}

Student &StudentRepository::getStudentByPosition(int position) {
    if (position > this->currentSize) {
        std::cout << "Position bigger than current size." << std::endl;
        throw std::out_of_range("Position is out of range");
    }

    return this->students[position];
}

Student *StudentRepository::getAllStudents() {
    return this->students;
}

int StudentRepository::getCurrentSize() {
    return this->currentSize;
}

StudentRepository::~StudentRepository() {
    delete []this->students;
}
