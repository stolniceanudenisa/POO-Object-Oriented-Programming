#include "Flower.h"


Flower::Flower(){
	cout << "default constructor ... " << endl;
	name = NULL;
	price = 0;
}

Flower::Flower(char* name, int p){
	this->name = new char[strlen(name) + 1];
	strcpy_s(this->name, strlen(name) + 1, name);
	price = p;
}

Flower::Flower(const Flower &f){
	name = new char[strlen(f.name) + 1];
	strcpy_s(name, strlen(name) + 1, f.name);
	price = f.price;
}

Flower::Flower(char* s){
	//to do
}


	
Flower::~Flower(){
	if (name){
		delete[] name;
		name =  NULL;
	}
}

Flower& Flower::operator=(const Flower &f){
	if (this != &f){
		setName(f.name);
		price = f.price;
	}
	return *this;
}
int Flower::getPrice(){
	return price;
}

char* Flower::getName(){
	return name;
}

void Flower::setName(char* n){
	if (name){
		delete[] name;
	}
	name = new char[strlen(n) + 1];
	strcpy_s(name, strlen(n) + 1, n);
}

void Flower::setPrice(int p){
	price = p;
}

char* Flower::toString(){
	int l = strlen(name) + 1 + 5 + 2;
	char* s = new char[l];
	char* aux = new char[5];
	strcpy_s(s, l, name);
	strcat_s(s, l, ";");
	_itoa_s(price, aux, 5, 10);
	strcat_s(s, l, aux);
	if (aux){
		delete[] aux;
		aux = NULL;
	}
	strcat_s(s, l, ";");
	return s;
}

bool Flower::operator<(const Flower &f) const{
	return (strcmp(name,f.name) == -1);
}

bool Flower::operator>(const Flower &f) const{
	return (strcmp(name,f.name) == 1);
}

bool Flower::operator==(const Flower &f) const{
	return (strcmp(name,f.name) == 0);
}

bool Flower::operator!=(const Flower &f) const{
	return (strcmp(name,f.name) != 0);
}

ostream& operator<<(ostream &os, const Flower &f){
	os << f.name << " " << f.price;
	return os;
}

istream& operator>>(istream &is, Flower &f){
	char* s = new char[100];
	is >> s;
	char *next_token;
	char* aux = strtok_s(s, ";", &next_token);
	f.name = new char[strlen(aux) + 1];
	strcpy_s(f.name, strlen(aux) + 1, aux);
	aux = strtok_s(NULL, ";", &next_token);
	f.price = atoi(aux);
	return is;
}