#ifndef FLOWER_H
#define FLOWER_H
#include <fstream>
#include <iostream>
using namespace std;

class Flower{
private:
	char* name;
	int price;
public:
	Flower();
	Flower(char* , int);
	Flower(const Flower &);
	Flower(char* );
	~Flower();
	Flower& operator=(const Flower &);
	char* getName();
	int getPrice();
	void setName(char*);
	void setPrice(int);
	char* toString();
	bool operator<(const Flower &) const;
	bool operator>(const Flower &) const;
	bool operator==(const Flower &) const;
	bool operator!=(const Flower &) const;

	friend ostream& operator<<(ostream &, const Flower &);
	friend istream& operator>>(istream &, Flower &);

};

#endif


