#ifndef LESSTHAN
#define LESSTHAN
class LessThan{
private:
	int limit;
public:
	LessThan(int l) : limit(l){
	}
	LessThan(const LessThan &lt) : limit(lt.limit){
	}
	~LessThan(){}
	LessThan& operator=(const LessThan &lt){
		limit = lt.limit;
	}
	int getLimit(){
		return limit;
	}
	bool operator()(int n){
		return (n < limit);
	}
};
#endif