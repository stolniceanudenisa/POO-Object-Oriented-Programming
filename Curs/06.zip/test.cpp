#include <vector>
#include <iostream>
#include <algorithm>
#include "Flower.h"
#include "LessThan.h"
#include <deque>
#include <list>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
using namespace std;

void vectorOfIntegers(){
	vector<int> v;
	int n = 3;
	v.reserve(n);
	for(int i = 0; i < n; i++)
		v.push_back(i);

		//print the vector elements from 0 to n
	cout << "vector of integers is : " << endl;
	for(int i = 0; i < v.size(); i++){
		cout << v[i] << endl;	
		//cout << v.at(i) << endl;
	}

		//clean the content <=> v.clear();
	while(!v.empty()){
		v.pop_back();
	}		
}
void vectorOfFlowers(){
	std::vector<Flower> v;
	int n = 3;
	Flower f1("daisy", 5);
	Flower f2("rose", 10);
	Flower f3("tulip", 2);
	v.reserve(n);
	v.push_back(f1);
	v.push_back(f2);
	v.push_back(f3);
	std::cout << "vector of flowers is : " << endl;
	for(int i = 0; i < v.size(); i++)
		std::cout << v[i] << endl;


}

void vectorOfFlowerAddresses(){
	vector<Flower*> v;
	int n = 3;
	Flower* f1 = new Flower("daisy", 5);
	Flower* f2 = new Flower("rose", 10);
	Flower* f3 = new Flower("tulip", 2);
	v.reserve(3);
	v.push_back(f1);
	v.push_back(f2);
	v.push_back(f3);

	cout << "Adr: vector of flowers is : " << endl;
	n = v.size();
	for (int i = 0; i < n; i++){
		//cout << v[i] << endl;
		Flower* pf = v[i];
		Flower fc = *pf;
		cout << fc.getName();
		cout << fc ;
	}


	//delete f3;
	//delete f2;
	//delete f1;
}

void vectorOfFlowersWithIterator(){
	vector<Flower> v;
	int n = 3;
	Flower f1("daisy", 5);
	Flower f2("rose", 10);
	Flower f3("tulip", 2);
	v.reserve(4);
	v.push_back(f1);
	v.push_back(f2);
	v.push_back(f3);

	cout << "vector of flowers is : " << endl;
	vector<Flower>::iterator it = v.begin();
	while (it != v.end()){
		cout << *it << endl;
		it++;
	}

	v.clear();
}



void vectorWithBidirectionalIterators(){
	int a[] = {2, 5, 3};
	int l = sizeof(a)/sizeof(int);
	vector<int> v (a, a + sizeof(a)/sizeof(int));

	cout << "vector of integers is : " << endl;
		//use a bidirect (reversible) iterator
	vector<int>::reverse_iterator rit = v.rbegin();
	while( rit != v.rend()){
		cout << *rit << " ";
		++rit;
	}
	cout << endl;
}
/*
bool lessThan5(int val){
	return (val < 5);
}

bool lessThan10(Flower f){
	return (f.getPrice() < 10);
}


void vectorWithStreamIterators(){
	vector<Flower> v;
	int n = 3;
	Flower f1("daisy", 5);
	Flower f2("rose", 10);
	Flower f3("tulip", 2);
	v.push_back(f1);
	v.push_back(f2);
	v.push_back(f3);
		//use an output iterator in order to print the content of the vector
	cout << "vector of flowers is : " << endl;
//	copy(v.begin(), v.end(), ostream_iterator<Flower>(cout, "\n"));

		//use an input iterator in order to read the content of the vector	
	vector<int> v1;
	ifstream fin("dataInt.in");
	if (!fin.fail()){
	//	copy(istream_iterator<int>(cin), istream_iterator<int>(), back_inserter(v1));
		cout << "vector of integers is : " << endl;
		//copy(v1.begin(), v1.end(), ostream_iterator<int>(cout, "\n"));
		fin.close();
	}	
}

void vectorWithIteratorsAndPredicates(){
	int MAX = 10;
	vector<int> v;
	for(int i = 0; i < MAX; i++)
		v.push_back(i);
	vector<int> copyv(MAX);
	remove_copy_if(v.begin(), v.end(), copyv.begin(), lessThan5);
	//remove_copy_if(v.begin(), v.end(), ostream_iterator<int>(cout, " "), lessThan5);
	cout << "copy vector : ";
	for(int i = 0; i < copyv.size(); i++)
		cout << copyv[i] << " ";
	cout << endl;
	
		//use an iterator
	cout << endl << "original vector : ";
	vector<int>::iterator it = v.begin();
	while( it != v.end()){
		cout << *it << " ";
		++it;
	}
	cout << endl;
}

void vectorWithIteratorsAndObjectFunctions(){
	LessThan lt1(5);
	cout << lt1(2);	//false/0
	cout << lt1(7);	//true/1

	int MAX = 10;
	vector<int> v;
	for(int i = 0; i < MAX; i++)
		v.push_back(i);
	vector<int> copyv(MAX);
	remove_copy_if(v.begin(), v.end(), copyv.begin(), lt1);
	//remove_copy_if(v.begin(), v.end(), ostream_iterator<int>(cout, " "), lt1);
	cout << endl << "copy vector : ";
	for(int i = 0; i < copyv.size(); i++)
		cout << copyv[i] << " ";
	cout << endl;
	
		//use an iterator
	cout << endl << "original vector : ";
	vector<int>::iterator it = v.begin();
	while( it != v.end()){
		cout << *it << " ";
		++it;
	}
	cout << endl;
}

void dequeOfInteger(){
	deque<int> d;
	int n = 3;
	for(int i = 0; i < n; i++)
		d.push_back(i);
		//print the deque's elements from 0 to n
	cout << "deque of integer is : " << endl;
	for(int i = 0; i < d.size(); i++){
		cout << d[i] << endl;	
		//cout << d.at(i) << endl;
	}
		//clean the content <=> v.clear();
	while(!d.empty()){
		d.pop_back();
	}	
}

void dequeOfFlowers(){
	deque<Flower> d;
	int n = 3;
	Flower f1("daisy", 5);
	Flower f2("rose", 10);
	Flower f3("tulip", 2);
	d.push_back(f1);
	d.push_back(f2);
	d.push_back(f3);

	cout << "deque of flowers is : " << endl;
	for(int i = 0; i < d.size(); i++)
		cout << d[i] << endl;
}

void dequeOfFlowersWithIterator(){
	deque<Flower> d;
	int n = 3;
	Flower f1("daisy", 5);
	Flower f2("rose", 10);
	Flower f3("tulip", 2);
	d.push_back(f1);
	d.push_back(f2);
	d.push_back(f3);

	cout << "deque of flowers is : " << endl;
	deque<Flower>::iterator it = d.begin();
	while (it != d.end()){
		cout << *it << endl;
		it++;
	}
}

void listOfFlowersWithIterator(){
	list<Flower> l;
	int n = 3;
	Flower f1("daisy", 5);
	Flower f2("rose", 10);
	Flower f3("tulip", 2);
	l.insert(l.begin(), f3);	//add the first node
	l.insert(l.begin()++, f1);	//add the second node after the first node
	l.insert(l.end(), f2);		//add a new node after the previous last node

	cout << "list is : " << endl;
	list<Flower>::iterator it = l.begin();
	while (it != l.end()){
		cout << *it << "; ";
		it++;
	}
	cout << endl;

	l.sort();	//Flower has to implement operator>
	cout << "sorted list is : " << endl;
	it = l.begin();
	while (it != l.end()){
		cout << *it << "; ";
		it++;
	}
	cout << endl;
}

void stackOfFlowers(){
	stack<Flower> s;
	int n = 3;
	Flower f1("daisy", 5);
	Flower f2("rose", 10);
	Flower f3("tulip", 2);
	s.push(f1);
	s.push(f2);
	s.push(f3);

	cout << "stack is : " << endl;
	while (!s.empty()){
		cout << s.top() << endl;	//access the top element
		s.pop();					//remove the top element
	}
	cout << endl;
}

void queueOfFlowers(){
	queue<Flower> q;
	int n = 3;
	Flower f1("daisy", 5);
	Flower f2("rose", 10);
	Flower f3("tulip", 2);
	q.push(f1);
	q.push(f2);
	q.push(f3);

	cout << "queue is : " << endl;
	while (!q.empty()){
		cout << q.front() << endl;	//access the first element
		q.pop();					//remove the first element
	}
	cout << endl;
}

void priorityQueueOfFlowers(){
	priority_queue<Flower> pq;
	int n = 3;
	Flower f2("daisy", 5);
	Flower f3("rose", 10);
	Flower f1("tulip", 2);
	pq.push(f1);
	pq.push(f2);
	pq.push(f3);

	cout << "priority queue is : " << endl;
	while (!pq.empty()){
		cout << pq.top() << endl;	//access the top element
		pq.pop();					//remove the top element
	}
	cout << endl;
}

void setOfFlowers(){
	set<Flower> s;
	Flower f1("daisy", 5);
	Flower f2("rose", 10);
	Flower f3("tulip", 2);
	Flower f4("rose", 20);
	s.insert(f1);
	s.insert(f2);
	s.insert(f3);
	s.insert(f4);

	cout << "set of flowers is : " << endl;
	set<Flower>::iterator it = s.begin();
	while( it != s.end()){
		cout << *it << " ";
		++it;
	}
	cout << endl;	

	set<Flower>::iterator itf = s.find(f2);	//int counter = s.count(f2);
	if (itf != s.end())	//<=> if (counter == 1)
		cout << "Flower (" << f2 << ") belongs to the set ..." << endl;
	else
		cout << "Flower (" << f2 << ") doesn't belong to the set ..." << endl;

	Flower f5("snowdrop", 1);
	itf = s.find(f5);		//int counter = s.count(f2);
	if (itf != s.end())		//if (counter == 1)
		cout << "Flower (" << f5 << ") belongs to the set ..." << endl;
	else
		cout << "Flower (" << f5 << ") doesn't belong to the set ..." << endl;

	
}

void multiSetOfFlowers(){
	multiset<Flower> ms;
	Flower f1("daisy", 5);
	Flower f2("rose", 10);
	Flower f3("tulip", 2);
	Flower f4("rose", 20);
	ms.insert(f1);
	ms.insert(f2);
	ms.insert(f3);
	ms.insert(f4);

	cout << "multiset of flowers is : " << endl;
	multiset<Flower>::iterator it = ms.begin();
	while( it != ms.end()){
		cout << *it << " ";
		++it;
	}
	cout << endl;	

	multiset<Flower>::iterator itf = ms.find(f2);	//int counter = ms.count(f2);
	if (itf != ms.end())	//<=> if (counter != 0)
		cout << "Flower (" << f2 << ") belongs to the multiset ..." << endl;
	else
		cout << "Flower (" << f2 << ") doesn't belong to the multiset ..." << endl;

	Flower f5("snowdrop", 1);
	itf = ms.find(f5);		//int counter = ms.count(f2);
	if (itf != ms.end())		//if (counter != 0)
		cout << "Flower (" << f5 << ") belongs to the multiset ..." << endl;
	else
		cout << "Flower (" << f5 << ") doesn't belong to the multiset ..." << endl;

	int counter = ms.count(f2);
	cout << "Flower (" << f2 << ") appears " << counter << " times in the multiset " << endl;	
}

void mapOfFlowers(){
	map<char, Flower> m;
	Flower f1("daisy", 5);
	Flower f2("rose", 10);
	Flower f3("tulip", 2);
	Flower f4("dahlia", 20);
	//pair<char, Flower> p;
	//p(f1.getName()[0], f1);

	m.insert(pair<char, Flower>(f1.getName()[0], f1));
	m.insert(pair<char, Flower>(f2.getName()[0], f2));
	m.insert(pair<char, Flower>(f3.getName()[0], f3));
	m.insert(pair<char, Flower>(f4.getName()[0], f4));
	
	cout << "map of flowers is : " << endl;
	map<char, Flower>::iterator it = m.begin();
	while( it != m.end()){
		cout << "key = " << (*it).first << " value = " << (*it).second << endl;
		++it;
	}
	cout << endl;	

	map<char, Flower>::iterator itf = m.find(f2.getName()[0]);	
	if (itf != m.end())
		cout << "Flower (" << f2 << ") belongs to the map ..." << endl;
	else
		cout << "Flower (" << f2 << ") doesn't belong to the map..." << endl;

	
	int counter = m.count(f1.getName()[0]);
	cout << "Flower (" << f1 << ") appears " << counter << " times in the map " << endl;	
}

void multiplemapOfFlowers(){
	multimap<char, Flower> mm;
	Flower f1("daisy", 5);
	Flower f2("rose", 10);
	Flower f3("tulip", 2);
	Flower f4("dahlia", 20);
	mm.insert(pair<char, Flower>(f1.getName()[0], f1));
	mm.insert(pair<char, Flower>(f2.getName()[0], f2));
	mm.insert(pair<char, Flower>(f3.getName()[0], f3));
	mm.insert(pair<char, Flower>(f4.getName()[0], f4));
	
	cout << "multiplemap of flowers is : " << endl;
	multimap<char, Flower>::iterator it = mm.begin();
	while( it != mm.end()){
		cout << "key = " << (*it).first << " value = " << (*it).second << endl;
		++it;
	}
	cout << endl;	

	multimap<char, Flower>::iterator itf = mm.find(f2.getName()[0]);	
	if (itf != mm.end())
		cout << "Flower (" << f2 << ") belongs to the multiplemap ..." << endl;
	else
		cout << "Flower (" << f2 << ") doesn't belong to the multiplemap..." << endl;

	
	int counter = mm.count(f1.getName()[0]);
	cout << "Flower with key = " << f1.getName()[0] << " appears " << counter << " times in the multiplemap: ";
	it = mm.equal_range(f1.getName()[0]).first;
	while (it != mm.equal_range(f1.getName()[0]).second){
		cout << (*it).second << ", ";
		it++;
	}
	cout << endl;
}

void sortVectorOfIntegers(){
	vector<int> v;
	v.push_back(9);
	v.push_back(1);
	v.push_back(4);
	cout << "initial vector : ";
	for(int i = 0; i < v.size(); i++)
		cout << v[i] << " ";
	cout << endl;
	sort(v.begin(), v.end());
	cout << "ascending sorted vector : ";
	for(int i = 0; i < v.size(); i++)
		cout << v[i] << " ";
	cout << endl;
	reverse(v.begin(), v.end());
	cout << "descending sorted vector : ";
	for(int i = 0; i < v.size(); i++)
		cout << v[i] << " ";
	cout << endl;	

	sort(v.begin(), v.end(), lessThan5);
	//sort(v.begin(), v.end(), lessThan5);
	for(int i = 0; i < v.size(); i++)
		cout << v[i] << " ";
	cout << endl;	
}

void sortVectorOfFlowers(){
	vector<Flower> v;
	Flower f1("rose", 10);
	Flower f2("daisy", 5);
	Flower f3("tulip", 2);
	v.push_back(f1);
	v.push_back(f2);
	v.push_back(f3);

	cout << "initial vector : ";
	for(int i = 0; i < v.size(); i++)
		cout << v[i] << ", ";
	cout << endl;
	sort(v.begin(), v.end());
	cout << "ascending sorted vector : ";
	for(int i = 0; i < v.size(); i++)
		cout << v[i] << ", ";
	cout << endl;
	reverse(v.begin(), v.end());
	cout << "descending sorted vector : ";
	for(int i = 0; i < v.size(); i++)
		cout << v[i] << ", ";
	cout << endl;	
}

void swapVector(){
	vector<int> v1;
	v1.push_back(9);
	v1.push_back(1);
	v1.push_back(4);

	vector<int> v2;
	cout << "before swap " << endl << " v1 = ";
	for(int i = 0; i < v1.size(); i++)		cout << v1[i] << ", ";	cout << endl;
	cout << " v2 = ";
	for(int i = 0; i < v2.size(); i++)		cout << v2[i] << ", ";	cout << endl;
	swap(v1, v2);
	cout << "after swap " << endl << " v1 = ";
	for(int i = 0; i < v1.size(); i++)		cout << v1[i] << ", ";	cout << endl;
	cout << " v2 = ";
	for(int i = 0; i < v2.size(); i++)		cout << v2[i] << ", ";	cout << endl;
}

void copyVector(){
	vector<int> v1;
	v1.push_back(9);
	v1.push_back(1);
	v1.push_back(4);

	vector<int> v2(v1.size());//v2 have enough space to receive a copy of the contents of v1

	cout << "before copy " << endl;
	cout << " v1 = ";	for(int i = 0; i < v1.size(); i++)		cout << v1[i] << ", ";	cout << endl;
	cout << " v2 = ";	for(int i = 0; i < v2.size(); i++)	cout << v2[i] << ", ";	cout << endl;
	
	copy(v1.begin(), v1.end(), v2.begin());

	cout << "after copy " << endl;
	cout << " v1 = ";	for(int i = 0; i < v1.size(); i++)		cout << v1[i] << ", ";	cout << endl;
	cout << " v2 = ";	for(int i = 0; i < v2.size(); i++)		cout << v2[i] << ", ";	cout << endl;


	vector<int> v3;//v3 is empty

	cout << "before copy " << endl;
	cout << " v1 = ";	for(int i = 0; i < v1.size(); i++)	cout << v1[i] << ", ";	cout << endl;
	cout << " v3 = ";	for(int i = 0; i < v3.size(); i++)	cout << v3[i] << ", ";	cout << endl;
	
	//copy(v1.begin(), v1.end(), back_inserter(v3));

	cout << "after copy " << endl;
	cout << " v1 = ";	for(int i = 0; i < v1.size(); i++)		cout << v1[i] << ", ";	cout << endl;
	cout << " v3 = ";	for(int i = 0; i < v3.size(); i++)		cout << v3[i] << ", ";	cout << endl;
}

void copyVectorCond(){
	vector<int> v1;
	v1.push_back(9);
	v1.push_back(1);
	v1.push_back(4);

	vector<int> v2;

	cout << "before copy " << endl;
	cout << " v1 = ";	for(int i = 0; i < v1.size(); i++)		cout << v1[i] << ", ";	cout << endl;
	cout << " v2 = ";	for(int i = 0; i < v2.size(); i++)	cout << v2[i] << ", ";	cout << endl;
	
//	remove_copy_if(v1.begin(), v1.end(), back_inserter(v2), lessThan5);
	//LessThan lt(5);
	//remove_copy_if(v1.begin(), v1.end(), back_inserter(v2), lt);

	cout << "after copy " << endl;
	cout << " v1 = ";	for(int i = 0; i < v1.size(); i++)		cout << v1[i] << ", ";	cout << endl;
	cout << " v2 = ";	for(int i = 0; i < v2.size(); i++)		cout << v2[i] << ", ";	cout << endl;
}
*/


int main(){
		// sequence containers
	//vectorOfIntegers();
	//vectorOfFlowers();
	//vectorOfFlowerAddresses();
	vectorOfFlowersWithIterator();
	//vectorWithBidirectionalIterators();
	//dequeOfInteger();
	//dequeOfFlowers();
	//dequeOfFlowersWithIterator();
	//listOfFlowersWithIterator();

		//adaptors
	//stackOfFlowers();	
	//queueOfFlowers();
	//priorityQueueOfFlowers();

		//associative containers
	//setOfFlowers();
	//multiSetOfFlowers();
	//mapOfFlowers();
	//multiplemapOfFlowers();

			//algorithms
	//sortVectorOfIntegers();
	//sortVectorOfFlowers();
	//swapVector();
	//copyVector();
	//copyVectorCond();

	//vectorWithStreamIterators();
	//vectorWithIteratorsAndPredicates();
	//vectorWithIteratorsAndObjectFunctions();
	return 0;
}
