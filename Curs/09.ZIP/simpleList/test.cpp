#include "ArrayContainer.h"
#include "ListContainer.h"
#include "DoubleListContainer.h"
#include "Flower.h"
#include "Pair.h"
#include "MapContainer.h"
#include "MultipleMapContainer.h"
#include "HashTableContainer.h"

#include "IntegerKey.h"
#include <iostream>
using namespace std;


int hashFunctionFlower(IE* e){
	return ((Flower*)e)->getNoPetals() % 10;
}

void mainContainer(){
	//IContainer* c = new ArrayContainer(5);
	IContainer* c = new ListContainer();
	//IContainer* c = new DoubleListContainer();
	//IContainer* c = new HashTableContainer(hashFunctionFlower);
	Flower* f1 = new Flower("tulip", 5);
	Flower* f2 = new Flower("rose", 17);
	Flower* f3 = new Flower("daisy", 25);
	c->addElem(f1);
	c->addElem(f2);
	c->addElem(f3);
	IIterator* it = c->getIterator();
	while (it->isValid()){
		char* s = it->getCrtElem()->toString();
		cout << s << endl;
		delete[] s;
		it->moveNext();
	}
	c->removeElem(f3);
	it->moveFirst();
	while (it->isValid()){
		char* s = it->getCrtElem()->toString();
		cout << s << endl;
		delete[] s;
		it->moveNext();
	}
	delete it;
	delete f3;
	delete f2;
	delete f1;
	delete c;
}

void mainAssociativeContainer(){
	//IContainer* c = new MapContainer();
	IContainer* c = new MultipleMapContainer();
	Flower* f1 = new Flower("tulip", 5);
	Flower* f2 = new Flower("rose", 15);
	Flower* f3 = new Flower("daisy", 25);
	IntegerKey* key1 = new IntegerKey(5);
	IntegerKey* key2 = new IntegerKey(1);
	IntegerKey* key3 = new IntegerKey(3);
	IE* p1 = new Pair(key1, f1);
	IE* p2 = new Pair(key2, f2);
	IE* p3 = new Pair(key1, f3);
	c->addElem(p1);
	c->addElem(p2);
	c->addElem(p3);
	IIterator* it = c->getIterator();
	while (it->isValid()){
		char* s = it->getCrtElem()->toString();
		cout << s << endl;
		delete[] s;
		it->moveNext();
	}
	c->removeElem(key1);
	it->moveFirst();
	while (it->isValid()){
		char* s = it->getCrtElem()->toString();
		cout << s << endl;
		delete[] s;
		it->moveNext();
	}
	delete it;
	delete p3;
	delete p2;
	delete p1;
	delete key3;
	delete key2;
	delete key1;
	delete f3;
	delete f2;
	delete f1;
	delete c;
}


int main(){
	mainContainer();
	//mainAssociativeContainer();
	return 0;
}