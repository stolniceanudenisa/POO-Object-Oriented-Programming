const int MAX = 2;

class Student{
private:
	static int counter;
	int id;
	char* name;

public:
	Student(char* n){
		cout << "constr for student of id " << counter + 1 << " and name " << n << endl;
		id = counter + 1;
		counter++;
		name = new char[strlen(n)  + 1];
		strcpy(name, n);	
		if (counter > MAX)
			throw 0;
	
	}
	~Student(){
		cout << "Destr for student " << name << endl;
		if (name){
			delete[] name;
			name = NULL;
		}
	}
};

int Student::counter = 0;