#include <iostream>
using namespace std;

#include "Student.h"

class SmartPointer
{
private:
	int* data;

public:
	SmartPointer(int* p) : data(p){
		cout << "s-a alocat...";
	};
	~SmartPointer(){
		if (this->data != NULL){
			delete this->data;
			this->data = NULL;
			cout << "s-a dealocat...";
		}
	};
	int& operator*(){
		return *this->data;
	}
};


int main(){
	try{
		Student s1("Mary");
		Student s2("John");
		Student s3("Donna");	//throw an exc
	}
	catch(int &exc){
		cout << "exception : " << exc << endl;
	}
	catch(...){
		cout << "other exceptions..." << endl;
	}

	try{
		int* v = new int{ 3 };
		throw std::exception("o exceptie");
		delete v;
	}
	catch (std::exception &exc){
		cout << exc.what();
	}
	
	try
	{
		SmartPointer a{ new int{ 3 } };
		throw std::exception{ "An exc has occured, but all the res were properly managed \n" };
		// no need to delete + no more leaks
	}
	catch (std::exception& e)
	{
		cout << e.what();
	}

	return 0;
}