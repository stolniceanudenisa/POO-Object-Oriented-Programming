#include "MyException.h"
#include <stdlib.h>
#include <iostream>
using namespace std;

int division(double a, double b){
	if (b == 0)
		throw MyException("division by zero...");	//user-defined exception
	return a / b;
}

int division2(double a, double b){
	if (b == 0)
		throw 10;	//error code = exception
	return a / b;
}
void allocation(int capacity, int value){
	int* v = NULL;
	//v = new int[capacity];
	if (v == NULL)
		throw MyException("not reserved memory ...");
	for(int i = 0; i < capacity; i++)
		v[i] = value;
	for(int i = 0; i < capacity; i++)
		cout << v[i] << " ";
	cout << endl;
	delete[] v;
}

void oneException(){
	double x = 5;
	double y = 0;	//y = 2;
	try{
		allocation(10000, division(x,y));
	}
	catch(MyException &exc){
		cout << "exception : " << exc.getMessage() << endl;
	}
}


void moreThrownExceptions(){
	double x = 5;
	double y = 0;
	try{
		division2(x,y);	//throws int exc
		division(x, y);	//throws user-defined exc
	}
	catch(MyException &exc){
		cout << "exception : " << exc.getMessage() << endl;
	}
	catch(int &exc){
		cout << "exception : " << exc << endl;
	}
}

void morePossibleExceptions(){
	double x = 5;
	double y = 0;
	try{
		division(x, y);	//throws user-defined exc
	}
	catch(char* exc){
		cout << "exception : " << exc << endl;
	}
	catch(MyException &exc){
		cout << "exception : " << exc.getMessage() << endl;
	}
	catch(int &exc){
		cout << "exception : " << exc << endl;
	}
}

void anyException(){
	double x = 5;
	double y = 0;
	try{
		division(x, y);	//throws user-defined exc
	}
	catch(char* exc){
		cout << "exception : " << exc << endl;
	}
	catch(int &exc){
		cout << "exception : " << exc << endl;
	}
	catch(...){
		cout << "exception not identified" << endl;
	}
}

void exceptionWithoutCatch(){
	double x = 5;
	double y = 0;
	division(x, y);	//throws user-defined exc
	
}

void exceptionThatDoesntMatchAnyCatchClause(){
	double x = 5;
	double y = 0;
	try{
		division(x, y);	//throws user-defined exc
	}
	catch(char* exc){
		cout << "exception : " << exc << endl;
	}
	catch(int &exc){
		cout << "exception : " << exc << endl;
	}
}

int main(){
//	exceptionWithoutCatch();
//	oneException();
//	moreThrownExceptions();	
//	morePossibleExceptions();
//	anyException();
	exceptionThatDoesntMatchAnyCatchClause();
	
	return 0;
}