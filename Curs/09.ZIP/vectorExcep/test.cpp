#include <iostream>
using namespace std;
#include "Vector.h"


int main(){
	Vector v(3);
	try{
		v.addElem(1);
		v.addElem(2);
		v.addElem(3);
		v.addElem(4);
	}
	catch(FullVectorException &exc){
		cout << " exception : " << exc.what() << endl;
		v.resize();
	}
	catch(...){
		cout << " other exception ... " << endl;
	}
	
	try{
		v[2] = 4;
		for(int i = 0; i <= v.getSize(); i++)
			cout << v[i] << " ";
		
	}
	catch(IndexOutOfBoundsException &exc){
		cout << " exception : " << exc.what() << endl;
	}
	catch(...){
		cout << " other exception ... " << endl;
	}	

	return 0;
}