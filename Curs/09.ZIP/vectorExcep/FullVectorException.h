#ifndef FULLVECTOREXCEPTION_H
#define FULLVECTOREXCEPTION_H
#include <stdexcept>

class FullVectorException : public runtime_error{
private:
	char* message;
public:
	FullVectorException(char* msg) : 
		runtime_error(msg), message(msg){
	}
	char* what() {
		return message;
	}
};
#endif