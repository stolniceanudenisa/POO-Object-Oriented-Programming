#ifndef INDEXOUTOFBOUNDSEXCEPTION_H
#define INDEXOUTOFBOUNDSEXCEPTION_H
#include <stdexcept>

class IndexOutOfBoundsException : 
	public runtime_error{
private:
	char* message;
public:
	IndexOutOfBoundsException(char* msg) :
		runtime_error(msg), message(msg){
	}
	char* what(){
		return message;
	}
};
#endif