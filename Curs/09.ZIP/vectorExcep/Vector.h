#ifndef VECTOR_H
#define VECTOR_H

#include "FullVectorException.h"
#include "IndexOutOfBoundsException.h"

class Vector{
private:
	int size;
	int capacity;
	int *elements;
public:
	Vector(int c){
		size = 0;
		capacity = c;
		elements = new int[c];
	}
	Vector(const Vector &v){
		size = v.size;
		capacity = v.capacity;
		for(int i = 0; i < size; i++)
			elements[i] = v.elements[i];
	}
	~Vector(){
		if (elements){
			delete[] elements;
			elements = NULL;
		}
	}
	void addElem(int el) throw(FullVectorException){
		
		if (size == capacity){
	
			FullVectorException exc("the vector is full; it must be re-sized...");
			throw exc;
		}
		elements[size++] = el;

		
	}
	int& operator[](int pos) throw(IndexOutOfBoundsException){
		if ((pos < 0) || (pos >= size))
			throw IndexOutOfBoundsException("incorrect index; use an index between 0 and the vector size ...");
		return elements[pos];
	}
	void resize(){
		int* aux = new int[capacity * 2];
		for(int i = 0; i < size; i++)
			aux[i] = elements[i];
		delete[] elements;
		elements = aux;
		capacity *= 2;
	}
	int getSize(){
		return size;
	}
};
#endif