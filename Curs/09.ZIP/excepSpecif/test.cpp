#include <iostream>
using namespace std;

class MyException{
private:
	const char* message;
public:
	MyException(const char* m) : message(m){
	}
	const char* getMessage(){
		return message;
	}
};



int division1(int a, int b) {
	if (a == 0)
		throw 0;
	if (b == 0)
		throw MyException("division by zero...");
	if (a == b)
		throw 5.25;
	return a / b;
}

void run1(){
	try{
		//int res = division1(0, 5);
		//int res = division1(3, 0);
		int res = division1(5, 5);
		//int res = division1(3, 2);
		cout << "res = " << res << endl;
	}
	catch(int &exc){
		cout << "exception : " << exc << endl;
	}
	catch(MyException &exc){
		cout << "exception : " << exc.getMessage() << endl;
	}
	catch(...){
		cout << "other exceptions..." << endl;
	}
}

int division2(int a, int b) throw(int, MyException)
{
	if (a == 0)
		throw 0;
	if (b == 0)
		throw MyException("division by zero...");
	return a / b;
}

void run2(){
	try{
		int res = division2(0, 5);
		//int res = division2(3, 0);
		//int res = division2(3, 2);
		cout << "res = " << res << endl;
	}
	catch(int &exc){
		cout << "exception : " << exc << endl;
	}
	catch(MyException &exc){
		cout << "exception : " << exc.getMessage() << endl;
	}
}

int division3(int a, int b) throw(){
	return a / b;
}

void run3(){
	try{
		//int res = division3(0, 5);
		int res = division3(3, 0);
		//int res = division32(3, 2);
		cout << "res = " << res << endl;
	}
	catch(int &exc){
		cout << "exception : " << exc << endl;
	}
}

int division4(int a, int b) throw(int){
	if (a == 0)
		throw 0;
	if (b == 0)
		throw MyException("division by zero...");
	return a / b;
}

void run4(){
	try{
		//int res = division4(0, 5);
		int res = division4(3, 0);
		//int res = division4(3, 2);
		cout << "res = " << res << endl;
	}
	catch(int &exc){
		cout << "exception : " << exc << endl;
	}
}

int main1(){
	//run1();
	//run2();
	//run3();
	run4();
	return 0;
}