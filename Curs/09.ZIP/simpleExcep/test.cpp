#include <iostream>
using namespace std;

double division(double a, double b){
	if (b == 0.0)
		throw "division by 0";
	return a/b;
}

int main(){
	double x = 5.0;
	double y = 2.0;
	double z;
	try{
		z = division(x, y);
		cout << "result = " << z << endl;
	}
	catch(char* exc){
		cout << " exception : " << exc << endl;
	}
	
	y = 0.0;
	try{
		z = division(x, y);
		cout << "result = " << z << endl;
	}
	catch(char* exc){
		cout << " exception : " << exc << endl;
	}
	
	return 0;
}