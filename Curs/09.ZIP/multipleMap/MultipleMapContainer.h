//    * Each element has a unique key
//    * Each element is composed of a key and a mapped value
//    * Elements follow a strict weak ordering

#ifndef MULTIPLEMAPCONTAINER_H
#define MULTIPLEMAPCONTAINER_H

#include "IContainer.h"
#include "SNode.h"

class MultipleMapContainer : public IContainer{
private:
	SNode* head;
public:
	MultipleMapContainer();
	MultipleMapContainer(const MultipleMapContainer &);
	~MultipleMapContainer();
	MultipleMapContainer& operator=(const MultipleMapContainer &);
	void addElem(IE*);
	void removeElem(IE*);
	int getSize();
	bool containsKey(IE*);
	bool contains(IE*);//containsElem
	friend class MultipleMapIterator;
	IIterator* getIterator();
};

class MultipleMapIterator : public IIterator{
private:
	MultipleMapContainer* container;
	SNode* crtPos;
public:
	MultipleMapIterator(MultipleMapContainer* lc){
		container = lc;
		crtPos = lc->head;;
	}
	~MultipleMapIterator(){	
	}
	void moveNext(){
		crtPos = (SNode*)crtPos->getNext();
	}
	bool hasNext(){
		return (crtPos->getNext() != NULL);
	}
	bool isValid(){
		return (crtPos != NULL);
	}
	IE* getCrtElem(){
		return crtPos->getInfo();
	}
	void moveFirst(){
		crtPos = container->head;
	}
};

MultipleMapContainer::MultipleMapContainer(){
	head = NULL;
}

MultipleMapContainer::MultipleMapContainer(const MultipleMapContainer &mc){
	if (mc.head != NULL){
		head = new SNode();
		head->setInfo(mc.head->getInfo());
		head->setNext(NULL);
		SNode* crtMc = (SNode*)mc.head->getNext();
		SNode* crt = head;
		while (crtMc){
			SNode* aux = new SNode();
			aux->setInfo(crtMc->getInfo());
			aux->setNext(NULL);
			crt->setNext(aux);
			crt = aux;
			crtMc = (SNode*)crtMc->getNext();
		}
	}
}

MultipleMapContainer::~MultipleMapContainer(){
	SNode* crt = head;
	while(crt){
		SNode* aux = crt;
		crt = (SNode*)crt->getNext();
		delete aux;
	}
}
MultipleMapContainer& MultipleMapContainer::operator=(const MultipleMapContainer &mc){
	if (this != &mc){
		SNode* crt = head;
		while(crt){
			SNode* aux = crt;
			crt = (SNode*)crt->getNext();
			delete aux;
		}
		if (mc.head != NULL){
			head = new SNode();
			head->setInfo(mc.head->getInfo());
			head->setNext(NULL);
			SNode* crtMc = (SNode*)mc.head->getNext();
			SNode* crt = head;
			while (crtMc){
				SNode* aux = new SNode();
				aux->setInfo(crtMc->getInfo());
				aux->setNext(NULL);
				crt->setNext(aux);
				crt = aux;
				crtMc = (SNode*)crtMc->getNext();
			}
		}
	}		
	return *this;
}

void MultipleMapContainer::addElem(IE* e){
//	if (!containsKey(((Pair*)e)->getKey())){
		SNode* aux = new SNode();
		aux->setInfo(e);
		SNode* crt = head;
		SNode* prev = NULL;
		while ((crt != NULL) && (((Pair*)crt->getInfo())->getKey()->compareTo(((Pair*)e)->getKey()) == -1)){
			prev = crt;
			crt = (SNode*)crt->getNext();
		}
		if (prev == NULL){
			aux->setNext(crt);
			head = aux;
		}
		else{
			aux->setNext(crt);
			prev->setNext(aux);
		}
//	}
}
void MultipleMapContainer::removeElem(IE* k){
	if ((head != NULL) && (((Pair*)head->getInfo())->getKey()->compareTo(k) == 0)){
		while ((head != NULL) && (((Pair*)head->getInfo())->getKey()->compareTo(k) == 0)){
			SNode* crt = head;
			head = (SNode*)head->getNext();
			delete crt;		
		}
	}
	else{
		SNode* crt = head;
		SNode* prev = head;
		while ((crt != NULL) && (((Pair*)crt->getInfo())->getKey()->compareTo(k) != 0)){
			prev = crt;
			crt = (SNode*)crt->getNext();
		}
		while ((crt != NULL) && (((Pair*)crt->getInfo())->getKey()->compareTo(k) == 0)){
			prev->setNext(crt->getNext());
			delete crt;
			crt = (SNode*)prev->getNext();
		}
	}
}
int MultipleMapContainer::getSize(){
	SNode* crt = head;
	int n = 0;
	while (crt != NULL){
		crt = (SNode*)crt->getNext();
		n++;
	}
	return n;
}
bool MultipleMapContainer::containsKey(IE* k){
	SNode* crt = head;
	while (crt != NULL){
    Pair* p = (Pair*) crt->getInfo();
    IE* keyCrt = p->getKey();
		//if (((Pair*)crt)->getKey()->compareTo(k) == 0)
    if (keyCrt->compareTo(k) == 0)
			return true;
		crt = (SNode*)crt->getNext();
	}
	return false;
}
bool MultipleMapContainer::contains(IE* e){
	SNode* crt = head;
	while (crt != NULL){
		if (crt->getInfo()->compareTo(e) == 0)
			return true;
		crt = (SNode*)crt->getNext();
	}
	return false;
}
IIterator* MultipleMapContainer::getIterator(){
	return new MultipleMapIterator(this);
}

#endif