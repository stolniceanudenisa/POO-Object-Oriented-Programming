#include "Flower.h"
#include "Repo.h"
#include "Service.h"
#include <assert.h>
#include <iostream>

void testFlowers(){
    Flower f;
    assert (f.getPrice() == 0);
    
    Flower f2 = Flower("rose", 10);
    assert (f2.getPrice() == 10);
    assert (strcmp(f2.getName(), "rose") == 0);
}

void testRepo(){
    Repo r; 
    Flower f1 = Flower("rose", 10);
    r.addElem(f1);
    Flower f2 = r.getElemPos(0);
    assert(f1 == f2);   //f1.operator==(f2)
    assert (r.getSize() == 1);
}


void testServ(){
    // Repo r;
    // Service s(r);
    // s.addFlower("rose", 10);
    // Flower f1 = s.getFlowerFromPos(0);
    
    // Flower f2 = Flower("rose", 10);
    // assert(f1 == f2);   //f1.operator==(f2)

    // assert(f1.getPrice() == 10);
    // assert (strcmp(f1.getName(), "rose") == 0);

    RepoT<Flower> rf;
    RepoT<Client> rc;
    Service s(rf, rc);
    s.addFlower("rose", 10);
    Flower f1 = s.getFlowerFromPos(0);
    
    Flower f2 = Flower("rose", 10);
    assert(f1 == f2);   //f1.operator==(f2)

    assert(f1.getPrice() == 10);
    assert (strcmp(f1.getName(), "rose") == 0);

    s.addClient(20);
    assert (s.getClientFromPos(0).getId() == 20);
}

int main(){

    testFlowers();
    testRepo();

    std::cout << " good job!";

    return 0;
}