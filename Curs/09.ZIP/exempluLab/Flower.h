#ifndef FLOWER_H
#define FLOWER_H

#include <cstring>

class Flower{
private:
    char* name;
    int price;
public:
    Flower(){
        this->name = NULL;
        this->price = 0;
    }
    Flower(char* n, int p){
        this->name = new char[strlen(n) + 1];
        strcpy_s(this->name, strlen(n) + 1, n);
        this->price = p;
    }
    Flower(const Flower &f){
        this->name = new char[strlen(f.name) + 1];
        strcpy_s(this->name, strlen(f.name) + 1, f.name);
        this->price = f.price;
    }
    ~Flower(){
        delete[] this->name;
        this->name = NULL;
    }
    Flower& operator=(const Flower& f){
        if (this->name)
            delete[] this->name;
        this->name = new char[strlen(f.name) + 1];
        strcpy_s(this->name, strlen(f.name) + 1, f.name);
        this->price = f.price;
        return *this;
    }
    int getPrice(){
        return this->price;
    }
    char* getName(){
        return this->name;
    }

    bool operator==(Flower &f){
        return ((this->price == f.price) && (strcmp(this->name, f.name) == 0));
    }
};

#endif