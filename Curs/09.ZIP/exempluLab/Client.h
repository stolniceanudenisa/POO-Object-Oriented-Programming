class Client{
    private:
    int id;
    public:
    Client(){
        this->id = -1;
    }
    Client(int i){
        this->id = i;
    }
    Client(const Client &c){
        this->id = c.id;
    }
    ~Client(){}

    Client& operator=(const Client &c){
        this->id = c.id;
        return *this;
    }

    int getId(){
        return this->id;
    }

    bool operator==(Client &c){
        return this->id == c.id;
    }

};