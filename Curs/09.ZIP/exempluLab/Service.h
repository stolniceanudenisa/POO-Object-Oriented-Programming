#ifndef SERVICE_H
#define SERVICE_H
#include "Repo.h"
#include "RepoT.h"
#include "Client.h"
#include "Flower.h"

class Service{
private:
    // Repo repFlowers;
    RepoT<Flower> repFlowers;
    RepoT<Client> repClients;

public:
    // Service(Repo &r){
    //     this->repFlowers = r;
    // }
    Service(RepoT<Flower> &rf, RepoT<Client> &rc){
        this->repFlowers = rf;
        this->repClients = rc;
    }
    ~Service(){}
    void addFlower(char* n, int p){
        Flower f = Flower(n, p);
        this->repFlowers.addElem(f);
    }

    Flower getFlowerFromPos(int pos){
        return this->repFlowers.getElemPos(pos);
    }


    void addClient(int i){
        Client c = Client(i);
        this->repClients.addElem(c);
    }

    Client getClientFromPos(int pos){
        return this->repClients.getElemPos(pos);
    }
};

#endif