#ifndef REPO_H
#define REPO_H

#include <vector>
using namespace std;

class Repo{
private:
    vector<Flower> elements;
    // Flower elements[100];
    // Flower* elements;
public:
    Repo(){}
    ~Repo(){}
    void addElem(Flower &f){
        this->elements.push_back(f);
    }
    Flower getElemPos(int pos){
        return this->elements[pos];
    }
    int getSize(){
        return this->elements.size();
    }

};
#endif 