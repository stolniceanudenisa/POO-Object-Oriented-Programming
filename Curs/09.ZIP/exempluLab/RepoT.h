#ifndef REPOT_H
#define REPOT_H

#include <vector>
using namespace std;

template <class T>
class RepoT{
private:
    vector<T> elements;
    
public:
    RepoT(){}
    ~RepoT(){}
    void addElem(T &el){
        this->elements.push_back(el);
    }
    T getElemPos(int pos){
        return this->elements[pos];
    }
    int getSize(){
        return this->elements.size();
    }

};
#endif 