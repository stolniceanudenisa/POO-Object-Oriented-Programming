//    * Each element has a unique key
//    * Each element is composed of a key and a mapped value
//    * Elements follow a strict weak ordering

#ifndef HashTableContainer_H
#define HashTableContainer_H

#include "IContainer.h"
#include "HashTableElement.h"

const int MAX = 20;
typedef int (*hashFunction)(IE*);

class HashTableContainer : public IContainer{
private:
	int size;
	HashTableElement* elements;
	hashFunction hashFc;
public:
	HashTableContainer(hashFunction);
	HashTableContainer(const HashTableContainer &);
	~HashTableContainer();
	HashTableContainer& operator=(const HashTableContainer &);
	void addElem(IE*);
	void removeElem(IE*);
	int getSize();
	bool contains(IE*);//containsElem
	friend class HashTableIterator;
	IIterator* getIterator();
};

class HashTableIterator : public IIterator{
private:
	HashTableContainer* container;
	int crtPos;
	IIterator* listIt;
public:
	HashTableIterator(HashTableContainer* lc){
		container = lc;
		crtPos = 0;
		while ((crtPos < container->getSize()) && (container->elements[crtPos].getKey() == -1))
			crtPos++;
		if (crtPos < container->getSize())
			listIt = container->elements[crtPos].getList()->getIterator();
		else
			listIt = NULL;
	}
	~HashTableIterator(){	
	}
	void moveNext(){
		if (listIt->hasNext())
			listIt->moveNext();
		else{
			crtPos++;
			while ((crtPos < container->getSize()) && (container->elements[crtPos].getKey() == -1))
				crtPos++;
			if (crtPos < container->getSize())
				listIt = container->elements[crtPos].getList()->getIterator();
		}
	}
	bool hasNext(){
		int i = crtPos;
		bool has = false;
		while ((i < container->getSize()) && (!has)){
			if (container->elements[i].getKey() == -1)
				has = true;
			i++;
		}
		return has;
	}
	bool isValid(){
		return (container->elements[crtPos].getKey() != -1);
	}
	IE* getCrtElem(){
		return listIt->getCrtElem();
	}
	void moveFirst(){
		crtPos = 0;
		while ((crtPos < container->getSize()) && (container->elements[crtPos].getKey() == -1))
			crtPos++;
		if (crtPos < container->getSize())
			listIt = container->elements[crtPos].getList()->getIterator();
		else
			listIt = NULL;
	}
};

HashTableContainer::HashTableContainer(hashFunction f){
	size = 0;
	elements = new HashTableElement[MAX];
	hashFc = f;
}

HashTableContainer::HashTableContainer(const HashTableContainer &htc){
	size = htc.size;
	hashFc = htc.hashFc;
	for(int i = 0; i < size; i++)
		elements[i] = *htc.elements[i].clone();
}

HashTableContainer::~HashTableContainer(){
	if (elements){
		delete[] elements;
		elements = NULL;
	}
}
HashTableContainer& HashTableContainer::operator=(const HashTableContainer &htc){
	if (this != &htc){
		size = htc.size;
		hashFc = htc.hashFc;
		for(int i = 0; i < size; i++)
			elements[i] = *htc.elements[i].clone();
	}		
	return *this;
}

void HashTableContainer::addElem(IE* e){
	int pos = hashFc(e);
	if (pos > size)
		size = pos + 1;
	elements[pos].setKey(pos);
	elements[pos].getList()->addElem(e);
}
void HashTableContainer::removeElem(IE* e){
	int pos = hashFc(e);
	if ((pos >= 0) && (pos < size)){
		//delete elements[pos].key;
		elements[pos].getList()->removeElem(e);
		if (elements[pos].getList()->getSize() == 0)
			elements[pos].setKey(-1);
	}
}
int HashTableContainer::getSize(){
	return size;
}

bool HashTableContainer::contains(IE* e){
	int i = 0;
	bool found = false;
	while ((i < size) && (!found)){
		if (elements[i].getKey() != -1)
			found = elements[i].getList()->contains(e);
		i++;
	}
	return found;
}
IIterator* HashTableContainer::getIterator(){
	return new HashTableIterator(this);
}

#endif