#ifndef LISTCONTAINER_H
#define LISTCONTAINER_H

#include "IContainer.h"
#include "SNode.h"

class ListContainer : public IContainer{
private:
	SNode* head;
public:
	ListContainer();
	ListContainer(const ListContainer &);
	~ListContainer();
	ListContainer& operator=(const ListContainer &);
	void addElem(IE*);
	void removeElem(IE*);
	int getSize();
	bool contains(IE*);
	friend class ListIterator;
	IIterator* getIterator();
};

class ListIterator : public IIterator{
private:
	ListContainer* container;
	SNode* crtPos;
public:
	ListIterator(ListContainer* lc){
		container = lc;
		crtPos = lc->head;;
	}
	~ListIterator(){	
	}
	void moveNext(){
		crtPos = (SNode*)crtPos->getNext();
	}
	bool hasNext(){
		return (crtPos->getNext() != NULL);
	}
	bool isValid(){
		return (crtPos != NULL);
	}
	IE* getCrtElem(){
		return crtPos->getInfo();
	}
	void moveFirst(){
		crtPos = container->head;
	}
};

ListContainer::ListContainer(){
	head = NULL;
}
ListContainer::ListContainer(const ListContainer &ac){
	if (ac.head != NULL){
		head = new SNode();
		head->setInfo(ac.head->getInfo());
		head->setNext(NULL);
		SNode* crtAc = (SNode*)ac.head->getNext();
		SNode* crt = head;
		while (crtAc){
			SNode* aux = new SNode();
			aux->setInfo(crtAc->getInfo());
			aux->setNext(NULL);
			crt->setNext(aux);
			crt = aux;
			crtAc = (SNode*)crtAc->getNext();
		}
	}
}
ListContainer::~ListContainer(){
	SNode* crt = head;
	while(crt){
		SNode* aux = crt;
		crt = (SNode*)crt->getNext();
		delete aux;
	}
}
ListContainer& ListContainer::operator=(const ListContainer &ac){
	if (this != &ac){
		SNode* crt = head;
		while(crt){
			SNode* aux = crt;
			crt = (SNode*)crt->getNext();
			delete aux;
		}
		if (ac.head != NULL){
			head = new SNode();
			head->setInfo(ac.head->getInfo());
			head->setNext(NULL);
			SNode* crtAc = (SNode*)ac.head->getNext();
			SNode* crt = head;
			while (crtAc){
				SNode* aux = new SNode();
				aux->setInfo(crtAc->getInfo());
				aux->setNext(NULL);
				crt->setNext(aux);
				crt = aux;
				crtAc = (SNode*)crtAc->getNext();
			}
		}
	}		
	return *this;
}
void ListContainer::addElem(IE* e){
	SNode* aux = new SNode();
	aux->setInfo(e);
	aux->setNext(head);
	head = aux;
}
void ListContainer::removeElem(IE* e){
	SNode* crt = head;
	if (e->equals(crt->getInfo())){
		head = (SNode*)head->getNext();
		delete crt;
	}
	else{
		while (crt){
			SNode* nodeToBeDeleted = (SNode*)crt->getNext();
			if (nodeToBeDeleted != NULL){
				if (e->equals(nodeToBeDeleted->getInfo())){
					crt->setNext(nodeToBeDeleted->getNext());
					delete nodeToBeDeleted;
				}
			}
			crt = (SNode*)crt->getNext();				
		}
	}
}
int ListContainer::getSize(){
	int size = 0;
	SNode* crt = head;
	while (crt){
		size++;
		crt = (SNode*)crt->getNext();
	}
	return size;
}
bool ListContainer::contains(IE* e){
	SNode* crt = head;
	while (crt){
		if (e->equals(crt->getInfo()))
			return true;
		crt = (SNode*)crt->getNext();
	}
	return false;
}
IIterator* ListContainer::getIterator(){
	return new ListIterator(this);
}

#endif