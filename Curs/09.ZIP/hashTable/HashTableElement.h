#ifndef HASHTABLEELEMENT_H
#define HASHTABLEELEMENT_H

#include "IE.h"
#include "SNode.h"
#include "ListContainer.h"

class HashTableElement{
private:
	int key;
	ListContainer* list;
public:
	HashTableElement(){
		key = -1;
		list = new ListContainer();
	}
	HashTableElement(int k, ListContainer* l){
		key = k;
		list = l;
	}
	HashTableElement(const HashTableElement &h){
		key = h.key;
		list = h.list;
	}
	~HashTableElement(){
	}
	HashTableElement& operator=(const HashTableElement &h){
		if (this != &h){
			key = h.key;
			list = h.list;
		}
		return *this;
	}
	void setKey(int k){
		key = k;
	}
	void setList(ListContainer* l){
		list = l;
	}
	int getKey(){
		return key;
	}
	ListContainer* getList(){
		return list;
	}
	HashTableElement* clone(){
		HashTableElement* hte = new HashTableElement(key, new ListContainer(*list));
		return hte;
	}
};
#endif