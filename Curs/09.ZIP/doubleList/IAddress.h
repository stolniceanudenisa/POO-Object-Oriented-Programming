#ifndef IADDRESS_H
#define IADDRESS_H

class IAddress{
public:
	virtual void setInfo(IE*) = 0;
	virtual void setNext(IAddress*) = 0;
	virtual IE* getInfo() = 0;
	virtual IAddress* getNext() = 0;
	virtual ~IAddress(){}
};
#endif