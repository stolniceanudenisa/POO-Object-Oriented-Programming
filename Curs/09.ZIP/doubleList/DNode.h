#ifndef DNODE_H
#define DNODE_H

#include "SNode.h"

class DNode : public SNode{
private:
	DNode* prev;
public:
	DNode(){
		info = NULL;
		next = NULL;
		prev = NULL;
	}
	DNode(IE* e, SNode* n, DNode* p){
		info = e;
		next = n;
		prev = p;
	}
	DNode(const DNode &n){
		info = n.info;
		next = n.next;
		prev = n.prev;
	}
	~DNode(){
		if (info){
			delete info;
			info = NULL;
		}
	}
	DNode& operator=(const DNode &n){
		if (this != &n){
			info = n.info;
			next = n.next;
			prev = n.prev;
		}
		return *this;
	}
	void setPrev(IAddress* n){
		prev = (DNode*) n;
	}
	IAddress* getPrev(){
		return prev;
	}
};
#endif