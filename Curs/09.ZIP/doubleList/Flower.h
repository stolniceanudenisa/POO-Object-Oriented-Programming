#ifndef FLOWER_H
#define FLOWER_H

#include "IE.h"
#include <iostream>
using namespace std;

class Flower : public IE{
private:
	char* name;
	int noPetals;
public:
	Flower(){
		cout << "[Flower] : default constructor " << endl;
		name = NULL;
		noPetals = 0;
	}
	Flower(char* n, int nP){
		name = new char[strlen(n) + 1];
		strcpy(name, n);
		noPetals = nP;
	}
	Flower(const Flower& f){
		cout << "[Flower] : copy constructor " << endl;
		name = new char[strlen(f.name) + 1];
		strcpy(name, f.name);
		noPetals = f.noPetals;
	}
	~Flower(){
		cout << "[Flower] : detructor " << endl;
		if (name){
			delete[] name;
			name = NULL;
		}
	}
	Flower& operator=(const Flower &f){
		cout << "[Flower] : operator= " << endl;
		if (this != &f){
			if (name)
				delete[] name;
			name = new char[strlen(f.name) + 1];
			strcpy(name, f.name);
			noPetals = f.noPetals;
		}
		return *this;
	}
	void setName(char* n){
		if (name)
			delete[] name;
		name = new char[strlen(n) + 1];
		strcpy(name, n);
	}
	void setNoPetals(int n){
		noPetals = n;
	}
	char* getName(){
		return name;
	}
	int getNoPetals(){
		return noPetals;
	}
	IE* clone(){
		Flower* f = new Flower;
		f->name = new char[strlen(name) + 1];
		strcpy(f->name, name);
		f->noPetals = noPetals;
		return f;
	}
	void copy(IE* e){
		Flower* f = (Flower*)e;
		name = new char[strlen(f->name) + 1];
		strcpy(name, f->name);
		noPetals = f->noPetals;
	}
	bool equals(IE* e){
		return ((strcmp(name, ((Flower*)e)->name) == 0 ) && (noPetals == ((Flower*)e)->noPetals));
	}
	int compareTo(IE* e){
		return strcmp(name, ((Flower*)e)->name);
	}
	char* toString(){
		char* s = new char[strlen(name) + strlen("this is flower  with  petals") + 6 + 1];
		strcpy(s, "This is flower ");
		strcat(s, name);
		strcat(s, " ");
		char* aux = new char[6];
		itoa(noPetals, aux, 10);
		strcat(s, aux);
		strcat(s, " petals");
		delete[] aux;
		return s;
	}
};
#endif