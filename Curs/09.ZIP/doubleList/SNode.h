#ifndef SNODE_H
#define SNODE_H

#include "IE.h"
#include "IAddress.h"

class SNode : public IAddress{
protected:
	IE* info;
	SNode* next;
public:
	SNode(){
		info = NULL;
		next = NULL;
	}
	SNode(IE* e, SNode* n){
		info = e->clone();
		next= n;
	}
	SNode(const SNode &n){
		info = n.info->clone();
		next = n.next;
	}
	~SNode(){
		if (info){
			delete info;
			info = NULL;
		}
	}
	SNode& operator=(const SNode &n){
		if (this != &n){
			info = n.info->clone();
			next = n.next;
		}
		return *this;
	}
	void setInfo(IE* e){
		info = e->clone();
	}
	void setNext(IAddress* n){
		next = (SNode*) n;
	}
	IE* getInfo(){
		return info;
	}
	IAddress* getNext(){
		return next;
	}
};
#endif