#ifndef DOUBLELISTCONTAINER_H
#define DOUBLELISTCONTAINER_H

#include "IContainer.h"
#include "DNode.h"

class DoubleListContainer : public IContainer{
private:
	DNode* head;
	DNode* tail;
public:
	DoubleListContainer();
	DoubleListContainer(const DoubleListContainer &);
	~DoubleListContainer();
	DoubleListContainer& operator=(const DoubleListContainer &);
	void addElem(IE*);
	void removeElem(IE*);
	int getSize();
	bool contains(IE*);
	friend class DoubleListIterator;
	IIterator* getIterator();
};

class DoubleListIterator : public IIterator{
private:
	DoubleListContainer* container;
	DNode* crtPos;
public:
	DoubleListIterator(DoubleListContainer* lc){
		container = lc;
		crtPos = lc->head;;
	}
	~DoubleListIterator(){	
	}
	void moveNext(){
		crtPos = (DNode*)crtPos->getNext();
	}
	bool hasNext(){
		return (crtPos->getNext() != NULL);
	}
	bool isValid(){
		return (crtPos != NULL);
	}
	IE* getCrtElem(){
		return crtPos->getInfo();
	}
	void moveFirst(){
		crtPos = container->head;
	}
};

DoubleListContainer::DoubleListContainer(){
	head = NULL;
	tail = NULL;
}
DoubleListContainer::DoubleListContainer(const DoubleListContainer &dlc){
	if (dlc.head != NULL){
		head = new DNode();
		head->setInfo(dlc.head->getInfo());
		head->setNext(NULL);
		head->setPrev(NULL);
		DNode* crtAc = (DNode*)dlc.head->getNext();
		DNode* crt = head;
		while (crtAc){
			DNode* aux = new DNode();
			aux->setInfo(crtAc->getInfo());
			aux->setNext(NULL);
			aux->setPrev(crt);
			crt->setNext(aux);
			crt = aux;
			crtAc = (DNode*)crtAc->getNext();
		}
		tail = crt;
	}
}
DoubleListContainer::~DoubleListContainer(){
	SNode* crt = head;
	while(crt){
		SNode* aux = crt;
		crt = (SNode*)crt->getNext();
		delete aux;
	}
}
DoubleListContainer& DoubleListContainer::operator=(const DoubleListContainer &ac){
	if (this != &ac){
		SNode* crt = head;
		while(crt){
			SNode* aux = crt;
			crt = (SNode*)crt->getNext();
			delete aux;
		}
		if (ac.head != NULL){
			head = new DNode();
			head->setInfo(ac.head->getInfo());
			head->setNext(NULL);
			head->setPrev(NULL);
			DNode* crtAc = (DNode*)ac.head->getNext();
			DNode* crt = head;
			while (crtAc){
				DNode* aux = new DNode();
				aux->setInfo(crtAc->getInfo());
				aux->setNext(NULL);
				aux->setPrev(crt);
				crt->setNext(aux);
				crt = aux;
				crtAc = (DNode*)crtAc->getNext();
			}
			tail = crt;
		}
	}		
	return *this;
}
void DoubleListContainer::addElem(IE* e){
	DNode* aux = new DNode();
	aux->setInfo(e);
	if (head == NULL){
		aux->setNext(NULL);
		aux->setPrev(NULL);
		head = tail = aux;
	}
	else{
		aux->setNext(NULL);
		aux->setPrev(tail);
		tail->setNext(aux);
		tail = aux;	
	}
}
void DoubleListContainer::removeElem(IE* e){
	DNode* crt = head;
	if (e->equals(crt->getInfo())){
		head = (DNode*)head->getNext();
		delete crt;
	}
	else{
		while (crt){
			DNode* nodeToBeDeleted = (DNode*)crt->getNext();
			if (nodeToBeDeleted != NULL){
				if (e->equals(nodeToBeDeleted->getInfo())){
					crt->setNext(nodeToBeDeleted->getNext());
					delete nodeToBeDeleted;
				}
			}
			crt = (DNode*)crt->getNext();				
		}
	}
}
int DoubleListContainer::getSize(){
	int size = 0;
	DNode* crt = head;
	while (crt){
		size++;
		crt = (DNode*)crt->getNext();
	}
	return size;
}
bool DoubleListContainer::contains(IE* e){
	DNode* crt = head;
	while (crt){
		if (e->equals(crt->getInfo()))
			return true;
		crt = (DNode*)crt->getNext();
	}
	return false;
}
IIterator* DoubleListContainer::getIterator(){
	return new DoubleListIterator(this);
}

#endif