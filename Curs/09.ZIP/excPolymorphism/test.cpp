#include <iostream>
using namespace std;

class MyExceptionBase{
protected:
	const char* message;
public:
	MyExceptionBase(const char* m) : message(m){
	}
	const char* getMessage(){
		return message;
	}
};

class MyExceptionDerived : public MyExceptionBase{
private:
	const char* messageDerived;
public:
	MyExceptionDerived(const char* m) : MyExceptionBase(m), messageDerived(m){
	}
	const char* getMessage(){
		return messageDerived;
	}
};

int division(double a, double b){
	if (a == 0)
		throw MyExceptionBase("zero division...");	//user-defined exception
	if (b == 0)
		throw MyExceptionDerived("division by zero...");	//user-defined exception
	return a / b;
}

void throwABaseExcCatchOnlyTheBase(){
	try{
		division(0,2);
	}
	catch(MyExceptionBase &exc){	//this is the matched exception
		cout << "exception : " << exc.getMessage() << endl;
	}
}

void throwABaseExcCatchBothTheBaseAndTheDerived(){
	try{
		division(0,2);
	}
	catch(MyExceptionDerived &exc){
		cout << "exception : " << exc.getMessage() << endl;
	}
	catch(MyExceptionBase &exc){	//this is the matched exception
		cout << "exception : " << exc.getMessage() << endl;
	}
}

void throwADerivedExcCatchOnlyTheDerived(){
	try{
		division(2,0);
	}
	catch(MyExceptionDerived &exc){	//this is the matched exception
		cout << "exception : " << exc.getMessage() << endl;
	}
}


void throwADerivedExcCatchBothTheBaseAndTheDerived(){
	try{
		division(2,0);
	}
	catch(MyExceptionDerived &exc){	//this is the matched exception
		cout << "exception : " << exc.getMessage() << endl;
	}
	catch(MyExceptionBase &exc){	
		cout << "exception : " << exc.getMessage() << endl;
	}
}

void throwADerivedExcCatchOnlyTheBase(){
	try{
		division(2,0);
	}
	catch(MyExceptionBase &exc){	//this is the matched exception
		cout << "exception : " << exc.getMessage() << endl;
	}
	catch(MyExceptionDerived &exc){	//this is the matched exception
		cout << "exception : " << exc.getMessage() << endl;
	}
}
int main(){
//	throwABaseExcCatchOnlyTheBase();
	throwABaseExcCatchBothTheBaseAndTheDerived();
//	throwADerivedExcCatchOnlyTheDerived();
//	throwADerivedExcCatchBothTheBaseAndTheDerived();
//	throwADerivedExcCatchOnlyTheBase();
	return 0;
}