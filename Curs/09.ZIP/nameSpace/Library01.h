namespace Library01{
	class Flower{
	};
	const int MIN = 0;
}