#include "Library01.h"
#include "Library02.h"

void main1(){
	//Flower f;	//'Flower' : undeclared identifier
	Library01::Flower f1;
	Library01::Flower f2;
	Library01::Gardener g;
	int v = Library01::MAX;
}

void main2(){
	using namespace Library01;
	int m = MIN;
	Flower f1;
	using namespace Library02;
	//Flower f2;	//error C2872: 'Flower' : ambiguous symbol
}

void main3(){
	using Library01::Flower;
	Flower f1;	// Library01::Flower;
	using namespace Library02;
	Library02::Flower f2; //Library02::Flower
}

int main(){
	main1();
	main2();
	main3();
	return 0;
}