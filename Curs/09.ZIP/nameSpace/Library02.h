namespace Library02{
	class Flower{
	};
}

namespace Library01{
	class Gardener{
	};
	const int MAX = 10;
}