#ifndef INTEGERKEY_H
#define INTEGERKEY_H

class IntegerKey : public IE{
private:
	int keyValue;
public:
	IntegerKey(){
		keyValue = 0;
	}
	IntegerKey(int v){
		keyValue = v;
	}
	IntegerKey(const IntegerKey &k){
		keyValue = k.keyValue;
	}
	~IntegerKey(){
	}
	IntegerKey& operator=(const IntegerKey &k){
		if (this != &k){
			keyValue = k.keyValue;
		}
		return *this;
	}
	void setKeyValue(int v){
		keyValue = v;
	}
	int getKeyValue(){
		return keyValue;
	}
	IE* clone(){
		IntegerKey* k = new IntegerKey(keyValue);
		return k;
	}
	void copy(IE* e){
		IntegerKey* k = (IntegerKey*)e;
		keyValue = k->keyValue;
	}
	bool equals(IE* e){
		return (keyValue == ((IntegerKey*)e)->keyValue);
	}
	int compareTo(IE* e){
		if (keyValue < ((IntegerKey*)e)->keyValue)
			return -1;
		if (keyValue > ((IntegerKey*)e)->keyValue)
			return 1;
		return 0;
	}
	char* toString(){
		char* s = new char[strlen("this is key ") + 5 + 1];
		strcpy(s, "This is key ");
		char* aux = new char[6];
		itoa(keyValue, aux, 10);
		strcat(s, aux);
		delete[] aux;
		return s;
	}
};
#endif