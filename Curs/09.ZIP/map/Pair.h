#ifndef PAIR_H
#define PAIR_H

#include "IE.h"
#include "IntegerKey.h"

class Pair : public IE{
private:
	IE* key;
	IE* value;
public:
	Pair(IE* k, IE* v){
		key = k->clone();
		value = v->clone();
	}
	Pair(const Pair &p){
		key = p.key->clone();
		value = p.value->clone();
	}
	~Pair(){
		if (key){
			delete key;
			key = NULL;
		}
		if (value){
			delete value;
			value = NULL;
		}
	}
	Pair& operator=(const Pair &p){
		if (this != &p){
			setKey(p.key);
			setValue(p.value);
		}
		return *this;
	}
	IE* clone(){
		Pair* p = new Pair(key, value);
		return p;
	}
	void setKey(IE* k){
		if (key)
			delete key;
		key = k->clone();
	}
	void setValue(IE* v){
		if (value)
			delete value;
		value = v->clone();
	}
	IE* getKey(){
		return key;
	}
	IE* getValue(){
		return value;
	}
	void copy(IE* e){
		key = ((Pair*)e)->key->clone();
		value = ((Pair*)e)->value->clone();
	}
	bool equals(IE* e){
		return key->equals(((Pair*)e)->key);
	}
	int compareTo(IE* e){
    Pair* p = (Pair*)e;
    IntegerKey* keyP = (IntegerKey*)p->key;
		return key->compareTo(keyP);
	}
	char* toString(){
		char* sK = key->toString();
		char* sV = value->toString();
		char* s = new char[strlen(sK) + strlen(sV) + 1];
		strcpy(s, sK);
		strcat(s, sV);
		delete[] sK;
		delete[] sV;
		return s;
	}
};
#endif