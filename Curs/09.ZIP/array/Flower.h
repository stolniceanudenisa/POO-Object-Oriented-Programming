#ifndef FLOWER_H
#define FLOWER_H

#include "IE.h"
#include <iostream>
#include <cstring>
using namespace std;

class Flower : public IE{
private:
	char* name;
	int noPetals;
public:
	Flower(){
		cout << "[Flower] : default constructor " << endl;
		name = NULL;
		noPetals = 0;
	}
	Flower(char* n, int nP){
		name = new char[strlen(n) + 1];
		strcpy(name, n);
		noPetals = nP;
	}
	Flower(const Flower& f){
		cout << "[Flower] : copy constructor " << endl;
		name = new char[strlen(f.name) + 1];
		strcpy(name, f.name);
		noPetals = f.noPetals;
	}
	~Flower(){
		cout << "[Flower] : detructor " << endl;
		if (name){
			delete[] name;
			name = NULL;
		}
	}
	Flower& operator=(const Flower &f){
		cout << "[Flower] : operator= " << endl;
		if (this != &f){
			if (this->name)
				delete[] this->name;
			this->name = new char[strlen(f.name) + 1];
			strcpy(this->name, f.name);
			this->noPetals = f.noPetals;
		}
		return *this;
	}
	void setName(char* n){
		if (name)
			delete[] name;
		name = new char[strlen(n) + 1];
		strcpy(name, n);
	}
	void setNoPetals(int n){
		noPetals = n;
	}
	char* getName(){
		return name;
	}
	int getNoPetals(){
		return noPetals;
	}
	IE* clone(){
		Flower* pf = new Flower;
		pf->name = new char[strlen(this->name) + 1];
		strcpy(pf->name, this->name);
		pf->noPetals = this->noPetals;

		return pf;
	}
	void copy(IE* e){
		Flower* f = (Flower*)e;
		this->name = new char[strlen(f->name) + 1];
		strcpy(this->name, f->name);
		this->noPetals = f->noPetals;
	}
	bool equals(IE* pe){
		return ((strcmp(this->name, ((Flower*)pe)->name) == 0 ) &&
		 (this->noPetals == ((Flower*)pe)->noPetals));
	}
	int compareTo(IE* e){
		return strcmp(this->name, ((Flower*)e)->name);
	}
	char* toString(){
		char* s = new char[strlen(this->name) + strlen(": this is flower  with  petals") + 6 + 1];
		strcpy(s, ": This is flower ");
		strcat(s, this->name);
		strcat(s, " with ");
		char* aux = new char[6];
		itoa(this->noPetals, aux, 10);
		strcat(s, aux);
		strcat(s, " petals");
		delete[] aux;
		return s;
	}
};
#endif