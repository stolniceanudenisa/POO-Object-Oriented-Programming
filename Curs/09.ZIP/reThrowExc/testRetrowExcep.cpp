//---------------------------------------------------------------------------

#pragma hdrstop

//---------------------------------------------------------------------------

#pragma argsused


#include <iostream>
using namespace std;

const int MAX = 2;

class Student{
private:
	char* name;

public:
	Student(){
		name = NULL;
	}
	Student(char* n){
		name = new char[strlen(n)  + 1];
		strcpy_s(name,strlen(n) + 1, n);
	}
	~Student(){
		if (name){
			delete[] name;
			name = NULL;
		}
	}
	char* getName(){
		return name;
	}
};

void work(){
	Student* ps;
	try{
		

		ps = new Student();
		if (ps->getName() == NULL)
			throw "Student without name";
		if (strcmp(ps->getName(), "John") == 0)
			cout << "founded..." << endl;
		else
			cout << "not founded..." << endl;
		delete ps;
	}
	catch(...){
		cout << "name exception : " << endl;
		delete ps;
		throw;
	}
}

int main(){
	try{
		work();
	}
	catch(...){
		cout << "some exception..." << endl;
	}
	return 0;
}
