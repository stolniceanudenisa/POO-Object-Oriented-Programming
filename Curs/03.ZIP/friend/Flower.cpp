#include <string.h>
#include "Flower.h"

//Descr: create a flower 
//In: -
//Out: an instance of Flower
Flower::Flower(){
	cout << "default constructor" << endl;
	this->name = NULL;
	this->price = 0;
}

//Descr: create a flower
//In: a name and a price
//Out: an instance (with info) of Flower
Flower::Flower(char* n, int p){
	cout << "constructor with param" << endl;
	this->name = new char[strlen(n) + 1];
	strcpy_s(this->name, strlen(n) + 1, n);
	this->price = p;
}

//Descr: create a flower using info from another flower
//In: a flower f
//Out: an instance of Flower with info from f
Flower::Flower(const Flower &f){
	cout << "copy constructor" << endl;
	this->name = new char[strlen(f.name) + 1];
	strcpy_s(this->name, strlen(f.name) + 1, f.name);
	this->price = f.price;
}

//Descr: distroy a flower 
//In: a flower 
//Out: - (destructor)
Flower::~Flower(){
	if (this->name != NULL){
		cout << "destructor of flower " << name << endl;
		delete[] this->name;
		this->name = NULL;
	}
}

//Descr: access the price of a flower 
//In: a flower 
//Out: the price
int Flower::getPrice(){
	return this->price;
}

//Descr: access the name of a flower 
//In: a flower 
//Out: the name
char* Flower::getName(){
	return this->name;
}

//Descr: change the name of a flower 
//In: a flower and a name
//Out: the flower with changed name
void Flower::setName(char* n){
	if (this->name){
		delete[] this->name;
	}
	this->name = new char[strlen(n) + 1];
	strcpy_s(this->name, strlen(n) + 1, n);
}

//Descr: change the price of a flower 
//In: a flower and a price
//Out: the flower with changed price
void Flower::setPrice(int p){
	this->price = p;
}

//Descr: convert a flower into a string
//In: a flower 
//Out: a string with info about the flower 
char* Flower::toString(){
	if (this->name != NULL){
		int noChars = strlen(this->name) + 1 + 5 + 2;
		char* s = new char[noChars];
		char* aux = new char[5];
		strcpy_s(s, noChars, this->name);
		strcat_s(s, noChars, ";");
		_itoa_s(this->price, aux, 5, 10);
		strcat_s(s, noChars, aux);

		if (aux){
			delete[] aux;
			aux = NULL;
		}
		strcat_s(s, noChars, ";");
		return s;
	}
	else
		return "";
}

//Descr: compare 2 flowers (the current one and a new one)
//In: two flowers 
//Out: true/false
bool Flower::compare(Flower &f){
	return ((strcmp(this->name, f.name) == 0) && (this->price == f.price));
}


//Descr: gardener changes the price of a flower 
//In: a flower and a price
//Out: the flower with changed price
void Gardener::changePrice(Flower &f, int p) {
	f.price = p;
}