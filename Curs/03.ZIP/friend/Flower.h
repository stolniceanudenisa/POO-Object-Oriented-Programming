
#ifndef FLOWER_H
#define FLOWER_H

#include <stdlib.h>
#include <iostream>
using namespace std;

const int MAX_NAME = 10;

class Flower;

class Gardener {
public:
	void changePrice(Flower &f, int p);
};

class Flower{
private:
	char* name;
	int price;
public:
	Flower();
	Flower(char* name, int p);
	Flower(const Flower &f);
	~Flower();
	char* getName();
	int getPrice();
	void setName(char* n);
	void setPrice(int p);
	char* toString();
	bool compare(Flower &f);

	friend bool theSameFlowerWithFriend(Flower &f1, Flower &f2);
	friend void Gardener::changePrice(Flower &f, int p);  // Struct member friend

	friend Gardener;
};





#endif


