#include "Rational.h"


//Descr: create a rational no
//In: -
//Out: an instance of Rational
Rational::Rational(){
	cout<<" implicit constructor Rational(0,1)"<<endl;
	this->nom = 0; //this->nom = 0;
	this->denom = 1; //this->denom = 1;
}
/*
Rational::Rational():nom(0), denom(1){
	cout << " implicit constructor Rational" << endl;
}
*/

//Descr: create a rational no
//In: 2 numbers: valNom, valDenom
//Out: an instance of Rational = valNom/valDenom
Rational::Rational(int valNom, int valDenom){
	cout << " constructor by parameters Rational : ";
	this->nom = valNom;
	if (valDenom != 0){
		this->denom = valDenom;
		this->simplify();
	}
	else
		this->denom = 1;
	cout << this->nom << " / " << this->denom << endl;
}

//Descr: create a rational no
//In: a number no
//Out: an instance of Rational = no / 1
Rational::Rational(int no){
	cout << " conversion constructor Rational (from int): ";
	this->nom = no;
	this->denom = 1;
	cout << this->nom << " / " << this->denom << endl;
}

//Descr: create a rational no from another Rational no
//In: a Rational r
//Out: an instance of Rational equal to r
Rational::Rational(const Rational &r){
	cout << " copy constructor Rational from " <<
	r.nom << "/" << r.denom << endl;
	this->nom = r.nom;
	this->denom = r.denom;
}

//Descr: destroy a rational no
//In: the current Rational no
//Out: -
Rational::~Rational(){
	cout << " destructor Rational for "	<< this->nom << "/" << this->denom << endl;
}

//Descr: simplify a rational no
//In: the current Rational no
//Out: a correct instance of Rational
void Rational::simplify(){
	int n1 = abs(this->nom);
	int n2 = abs(this->denom);
	while (n1 != n2){
		if (n1 > n2) 
			n1 -= n2;
		else 
			n2 -= n1;
	}
	this->nom = this->nom / n1;
	this->denom = this->denom / n1;
}

//Descr: change the nominator of a rational no
//In: a rational no and a value
//Out: the rational no with changed nominator
void Rational::setNom(int valNom){
	nom = valNom;
	this->simplify();
}

//Descr: change the denominator of a rational no
//In: a rational no and a value
//Out: the rational no with changed denominator
void Rational::setDenom(int valDenom){
	if (valDenom != 0){
		denom = valDenom;
	}
	this->simplify();
}

//Descr: access the nominator of a rational no
//In: a rational no 
//Out: the nominator
int Rational::getNom(){
	return nom;
}

//Descr: acces the denominator of a rational no
//In: a rational no
//Out: the denominator
int Rational::getDenom(){
	return denom;
}

//Descr: add sign to a rational no
//In: a rational no 
//Out: the rational no with + sign
const Rational& Rational::operator+(){
	cout << " unary operator + (sign) " << endl;
	return (*this);
}

//Descr: change the sign of a rational no
//In: a rational no 
//Out: a new rational no with the changed sign
const Rational Rational::operator-(){
	cout << " unary operator - (sign) " << endl;
	return Rational(-this->nom, this->denom);
}

//Descr: access the adress of a rational no
//In: a rational no 
//Out: the address of no
Rational* Rational::operator&(){
	cout <<" adress operator & for crt obj: " <<
	this->nom << " / " << this->denom << endl;
	return this;
}

//Descr: change by a unit a rational no (prefixed)
//In: a rational no 
//Out: the new rational no (no + 1)
//const 
Rational& Rational::operator++(){
	cout << " prefixed form of ++ for crt obj: " <<
	this->nom << " / " << this->denom << endl;
	this->nom += this->denom;
	return *this;
}

//Descr: change by a unit a rational no (postfixed)
//In: a rational no 
//Out: the old value of rational no (the crt value of no is increased by one unit)
//const 
Rational Rational::operator++(int){
	cout << " postfixed form of ++ for crt obj: " << this->nom << " / " << this->denom << endl;
	Rational before(this->nom, this->denom);
	this->nom += this->denom;
	return before;
}

//Descr: add two rational no (binary operator)
//In: two rational numbers (the crt one, rRight)
//Out: a new rational no = the sum of inputs
//const 
Rational Rational::operator+(const Rational& rRight) {
	//cout << " this + rRight = " << this->nom << " / " << this->denom << " + " << rRight.nom << " / " << rRight.denom << endl;
	//Rational rNew;
	//rNew.nom = this->nom * rRight.denom + this->denom * rRight.nom;
	//rNew.denom = this->denom * rRight.denom;
	//rNew.simplify();
	//return rNew;
	return Rational(this->nom * rRight.denom + this->denom * rRight.nom, this->denom * rRight.denom);
}

//Descr: create a new rational no (equal to a given rational no)
//In: a rational no (rRight)
//Out: a new rational no (equal to rRight)
Rational& Rational::operator=(const Rational& rRight){
	cout << " this = rRight = " << this->nom << " / " << this->denom << " = " << rRight.nom << " / " << rRight.denom << endl;
	if(this != &rRight){
		this->nom = rRight.nom;
		this->denom = rRight.denom;
	}
	else
		cout << "self assignemnt";
	return *this;
}

//Descr: add two rational no (binary operator)
//In: two rational numbers (the crt one, rRight)
//Out: the crt rational number is updated to the sum of inputs
Rational& Rational::operator+=(const Rational& rRight){
	cout << " this += rRight = " << this->nom << " / " << this->denom << " += " << rRight.nom << " / " << rRight.denom << endl;
	if(this != &rRight){
		this->nom = this->nom * rRight.denom +
		this->denom * rRight.nom;
		this->denom = this->denom * rRight.denom;
	}
	else{
		this->nom = this->nom * 2;
	}
	return *this;
}

//Descr: add two rational no (binary operator)
//In: two rational numbers (the crt one, rRight)
//Out: the crt rational number is updated to the sum of inputs
void Rational::addToThis(const Rational &rRight){
	cout << " this.addToThis(rRight) = " << this->nom << " / " << this->denom << " .addToThis( " << rRight.nom << " / " << rRight.denom << ")" << endl;
	if(this != &rRight){
		nom = nom * rRight.denom + denom * rRight.nom;
		denom = denom * rRight.denom;
	}
}

//Descr: compare two rational no 
//In: two rational numbers (the crt one, rRight)
//Out: true/false
int Rational::operator==(const Rational& rRight){
	cout << " this == rRight = " << this->nom << " / " << this->denom << " == " << rRight.nom <<" / " << rRight.denom << endl;
	return ((this->nom == rRight.nom) && (this->denom = rRight.denom));
}


//global operator
//Descr: add an interger no and a rational no 
//In: two  numbers (an integer and a Rational)
//Out: a new Ratioanal number = the sum of inputs
Rational operator+(int riLeft, Rational& rRight){
	cout << " int + rRight = " << riLeft << " + " << rRight.nom << " / " << rRight.denom << endl;
	return Rational(riLeft * rRight.denom + rRight.nom, rRight.denom);
}

//global operator
//Descr: add two rational no 
//In: two Rational numbers 
//Out: a new Ratioanal number = the sum of inputs
Rational operator+(Rational& rLeft, Rational& rRight){
	cout << " FRIEND : rLeft + rRight = " << rLeft.nom << " / " << rLeft.denom << " + " << rRight.nom << " / " << rRight.denom << endl;
	return Rational(rLeft.nom * rRight.denom + rLeft.denom * rRight.nom, rLeft.denom * rRight.denom);
}

//IO operators
//Descr: load a rational no from an input stream
//In: an input stream
//Out: a new Ratioanal number
istream& operator>>(istream& is, Rational& r){
	cout << " is >> r " << endl;
	cout << "nom = ";
	is >> r.nom;
	cout << "denom = ";
	is >> r.denom ;
	cout << r.nom << " / " << r.denom << endl;
	return is;
}

//IO operators
//Descr: save a rational no into an output stream
//In: an output stream, a Rational no
//Out: the output stream (loaded by info about Rational no)
ostream& operator<<(ostream& os, Rational& r){
	cout << " os << r for " << r.nom << " / " << r.denom << endl;
	os << r.nom << " / " << r.denom << endl;
	return os;
}
