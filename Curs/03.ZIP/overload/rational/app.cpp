#include "tests.h"

int main(){
	tests();
	return 0;
}