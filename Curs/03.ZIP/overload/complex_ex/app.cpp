

#include "Gardener.h"

int main(){
	Flower f1("daisy", 5);
	Flower f2("rose", 10);
	Gardener g;
	g.setName("Istvan");
	g.addFlower(f1);
	g.addFlower(f2);
	char* s = g.toString();
	cout << "the flowers of gardener " << g.getName() << " are : " << s << endl;
	if (s){
		delete[] s;
		s = NULL;
	}
	return 0;
}
