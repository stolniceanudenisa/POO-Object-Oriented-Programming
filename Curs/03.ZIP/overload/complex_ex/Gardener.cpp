#include "Gardener.h"
#include <string.h>

//Descr: create a gardener 
//In: -
//Out: an instance of Gardener
Gardener::Gardener(){
	this->name = NULL;
	this->noFlowers = 0;
	this->flowers = new Flower[MAX_FLOWERS];
}

//Descr: create a gardener
//In: a name, a no of flowers, an array of flowers
//Out: an instance (with info) of Gardener
Gardener::Gardener(char* n, int nF, Flower* f){
	this->name = new char[strlen(n) + 1];
	strcpy_s(this->name, strlen(n) + 1, n);
	this->noFlowers = nF;
	this->flowers = new Flower[nF];
	for (int i = 0; i < this->noFlowers; i++)
		this->flowers[i] = f[i];
}

//Descr: create a gadener (conversion constructor)
//In: info about gardener as string
//Out: an instance (with info) of Gardener
Gardener::Gardener(char* s){
	//to do
}

//Descr: distroy a gardener 
//In: a gardener
//Out: - (destructor)
Gardener::~Gardener(){
	if (this->name){
		delete[] this->name;
		this->name = NULL;
	}
	if (this->flowers){
		delete[] this->flowers;
		this->flowers = NULL;
	}
}

//Descr: create a gardener using info from another gardener
//In: a gardener g
//Out: an instance of Gardener with info from g
Gardener::Gardener(const Gardener &g){
	this->name = new char[strlen(g.name) + 1];
	strcpy_s(this->name, strlen(g.name) + 1, g.name);
	this->noFlowers = g.noFlowers;
	this->flowers = new Flower[noFlowers];
	for (int i = 0; i < this->noFlowers; i++)
		this->flowers[i] = g.flowers[i];
}

//Descr: create a new Gardener (equal to a given gardener g)
//In: a gardener (g)
//Out: a new gardener (equal to g)
Gardener& Gardener::operator=(const Gardener &g){
	if (this != &g){
		if (this->name)
			delete[] this->name;
		this->name = new char[strlen(g.name) + 1];
		strcpy_s(this->name, strlen(g.name) + 1, g.name);
		this->noFlowers = g.noFlowers;
		if (this->flowers)
			delete[] this->flowers;
		this->flowers = new Flower[noFlowers];
		for (int i = 0; i < this->noFlowers; i++)
			this->flowers[i] = g.flowers[i];
	}
	return *this;
}

//Descr: change the name of a gardener 
//In: a gardener and a name
//Out: the gardener with changed name
void Gardener::setName(char* n){
	if (this->name)
		delete[] this->name;
	this->name = new char[strlen(n) + 1];
	strcpy_s(this->name, strlen(n) + 1, n);
}

//Descr: add a flower to a gardener
//In: a flower and a gardener
//Out: the flower's array of gardener is updated
void Gardener::addFlower(Flower &f){
	if (this->noFlowers == MAX_FLOWERS){
		Flower* flowersAux = new Flower[2 * MAX_FLOWERS];
		for (int i = 0; i < this->noFlowers; i++)
			flowersAux[i] = this->flowers[i];
		delete[] this->flowers;
		this->flowers = flowersAux;
	}
	this->flowers[noFlowers++] = f;
}

//Descr: access the name of a gardener 
//In: a gardener
//Out: the name
char* Gardener::getName(){
	return this->name;
}

//Descr: access the no of flowers of a gardener 
//In: a gardener
//Out: the no of flowers
int Gardener::getNoFlowers(){
	return this->noFlowers;
}

//Descr: access a flower (from a position) of a gardener 
//In: a gardener and a position
//Out: the flower from that position
Flower& Gardener::getFlower(int pos){
	if ((pos >= 0) && (pos < this->noFlowers))
		return this->flowers[pos];
}

//Descr: convert a gardener to a string
//In: a gardener
//Out: the corresponding string
char* Gardener::toString(){
	int length = strlen(this->name) + this->noFlowers * (MAX_NAME + 1) + 6;
	char* s = new char[length];
	//strcpy_s(s, length, name);
	//strcat_s(s, length, ",");
	char* aux = new char[5];
	_itoa_s(this->noFlowers, aux, 5, 10);
	//strcat_s(s, length, aux);
	//strcat_s(s, length, ":");
	strcpy_s(s, strlen(this->name) + this->noFlowers * (MAX_NAME + 1) + 6, "");
	for(int i = 0; i < noFlowers; i++){
		strcat_s(s, length, this->flowers[i].toString());
	}
	return s;
}

//Descr: compare two gardeners
//In: two gardeners
//Out: true/false
bool Gardener::compare(Gardener &g){
	return (strcmp(name, g.name) == 0);
}