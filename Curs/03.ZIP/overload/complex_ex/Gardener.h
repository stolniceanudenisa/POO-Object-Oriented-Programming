#ifndef GARDENER_H
#define GARDENER_H

#include "Flower.h"

const int MAX_FLOWERS = 10;

class Gardener{
private:
	char* name;
	Flower* flowers;
	int noFlowers;
public:
	Gardener();
	Gardener(char* n, int nF, Flower* f);
	Gardener(char* s);
	Gardener(const Gardener &g);
	~Gardener();
	Gardener& operator=(const Gardener &g);

	void setName(char* n);
	void addFlower(Flower &f);
	
	
	char* getName();
	int getNoFlowers();
	Flower& getFlower(int pos);
	
	char* toString();
	bool compare(Gardener &g);
};

#endif



