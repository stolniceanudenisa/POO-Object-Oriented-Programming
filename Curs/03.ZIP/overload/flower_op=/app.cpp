#include "tests.h"
#include <iostream>

using namespace std;

int main(){
	tests();
	cout << " finish... " << endl;
	return 0;
}