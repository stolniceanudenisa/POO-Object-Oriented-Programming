#include "tests.h"
#include "Flower.h"

void tests(){
	Flower f1;			//implicit constructor
	f1.setName("tulip");
	f1.setPrice(10);

	Flower f2 = f1;		//copy constructor
	Flower f3;			//implicit constructor
	f3 = f2;			//assign op or implicit assign op beacuse memebr data are of elementary type => a new ob
	f1 = f1;			//(implicit) assign op => self assign

}
