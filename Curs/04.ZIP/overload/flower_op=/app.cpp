#include "tests.h"
#include <iostream>
using namespace std;


int main(){
	tests();
	cout << " flower power... " << endl;
	return 0;
}