#ifndef RATIONAL_H
#define RATIONAL_H
#include <iostream>
using namespace std;

class Rational{
private: //optional; implicit all the data and methods are private
	int nom;
	int denom;
	void simplify();
public:
	Rational();
	Rational(int valNom, int valDenom);
	Rational(int no);
	Rational(const Rational &r);
	~Rational();
	void setNom(int valNom);
	void setDenom(int valDenom);
	int getNom();
	int getDenom();

		//unary operators
	const Rational& operator+();
	const Rational operator-();
	Rational* operator&();
		//binary local operators
	const Rational& operator++();
	const Rational operator++(int);
	const Rational operator+(const Rational& rRight) const;
	void addToThis(const Rational &r);
	Rational& operator=(const Rational& rRight);
	Rational& operator+=(const Rational& rRight);
	int operator==(const Rational& rRight);

		//global operators
	friend Rational operator+(Rational& rLeft, Rational& r);
	friend Rational operator+(int riLeft, Rational& r);
		
		//IO operators
	friend istream& operator>>(istream& is, Rational& r);
	friend ostream& operator<<(ostream& os, Rational& r);
};

#endif