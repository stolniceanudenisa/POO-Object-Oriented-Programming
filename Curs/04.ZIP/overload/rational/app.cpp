#include "tests.h"
#include <iostream>
using namespace std;


int main(){
	tests();
	cout << " all tests are ok " << endl;
	return 0;
}