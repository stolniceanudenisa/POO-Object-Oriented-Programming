#include "Rational.h"
#include <iostream>
#include <conio.h>
#include <assert.h>
using namespace std;

void printRational(Rational r){
	cout << r.getNom() << " / " << r.getDenom()<<endl;
}

void functionWithoutReference(Rational r){
	cout<<"func with param called by value " << endl;
}

void functionWithReference(Rational &r){
	cout<<"func with param called by address "<<endl;
}

void testConstructors(){
		//static (fixed) objects
	Rational r1; //implicit constructor
	assert ((r1.getNom() == 0)  && (r1.getDenom() == 1));
	//cout << "r1 = ";	printRational(r1);
	Rational r2(2,3); //constr with param
	assert ((r2.getNom() == 2)  && (r2.getDenom() == 3));
	//cout << "r2 = ";	printRational(r2);
	Rational r3(5); //conversion constr
	assert ((r3.getNom() == 5)  && (r3.getDenom() == 1));
	//cout << "r3 = ";	printRational(r3);
	functionWithoutReference(r1);//with copy constr.
	functionWithReference(r2); //without copy constr.

		//dynamic objects
	Rational* pr1; //no constructor
	pr1 = new Rational(); //implicit constructor
	assert ((pr1->getNom() == 0)  && (pr1->getDenom() == 1));
	//cout << "pr1 = ";	printRational(*pr1);
	Rational* pr2=new Rational(2,3);//constr by param
	assert ((pr2->getNom() == 2)  && (pr2->getDenom() == 3));
	//cout << "pr2 = ";	printRational(*pr2);
	Rational* pr3 = new Rational(5); //convers constr
	assert ((pr3->getNom() == 5)  && (pr3->getDenom() == 1));
	//cout << "pr3 = ";	printRational(*pr3);
	functionWithoutReference(*pr1);//with copy constr
	functionWithReference(*pr2); //without copy constr
	if (pr3 != NULL){
		delete pr3; //destructor
		pr3 = NULL;
	}
	if (pr2 != NULL){
		delete pr2;//destructor
		pr2 = NULL;
	}
	if (pr1 != NULL){
		delete pr1;//destructor
		pr1 = NULL;
	}
}

void testSetGet(){
	Rational r;
	r.setNom(1);
	r.setDenom(3);
	assert ((r.getNom() == 1)  && (r.getDenom() == 3));
	//cout << r.getNom() << "/" << r.getDenom();
	Rational* pr = new Rational();
	pr->setNom(1);
	pr->setDenom(3);
	assert ((pr->getNom() == 1)  && (pr->getDenom() == 3));
	//cout << pr->getNom() << "/" << pr->getDenom();
	if (pr != NULL){
		delete pr;
		pr = NULL;
	}
}

void testSign(){
	Rational r1(4,5); //constructor by param
	assert ((r1.getNom() == 4)  && (r1.getDenom() == 5));
	//cout << "r1 = " << r1.getNom() << " / " << r1.getDenom() << endl;
	Rational r2(2); //conversion constructor
	assert ((r2.getNom() == 2)  && (r2.getDenom() == 1));
	//cout << "r2 = " << r2.getNom() << " / " << r2.getDenom() << endl;
	Rational r3 = +r1;
	assert ((r3.getNom() == 4)  && (r3.getDenom() == 5));
	//cout << "r3 = " << r3.getNom() << " / " << r3.getDenom() << endl;
	Rational r4 = -r2;
	assert ((r4.getNom() == -2)  && (r4.getDenom() == 1));
	//cout << "r4 = " << r4.getNom() << " / " << r4.getDenom() << endl;
}

void testAdress(){
	Rational r1(1,2);
	Rational r2(3,5);
	Rational* pr = &r1;
	assert ((r1.getNom() == 1)  && (r1.getDenom() == 2));
	//cout << "r1 = " << r1.getNom() << " / " <<	r1.getDenom() << endl;
	assert ((r2.getNom() == 3)  && (r2.getDenom() == 5));
	//cout << "r2 = " << r2.getNom() << " / " <<	r2.getDenom() << endl;
	assert ((pr->getNom() == 1)  && (pr->getDenom() == 2));
	//cout << "pr = " << pr->getNom() << " / " << pr->getDenom() << endl;
		//delete pr; !!!error pr is the address of a fixed object (from stack)
}

void testPlusPlus(){
	Rational r(1,5);
	assert ((r.getNom() == 1)  && (r.getDenom() == 5));
	//cout << "intial r = ";	printRational(r);
	++r;
	cout << "++r = ";	printRational(++r);
	cout << "r++ = ";	printRational(r++);
}

void testPlus(){
	Rational r1(1,5);
	Rational r2(3,7);
	cout << " r1 = ";	printRational(r1);
	cout << "r2 = ";	printRational(r2);
	cout << "r1+r2 = ";	printRational(r1 + r2);
		//until here operator+ can be defined as
		//const Rational Rational::operator+(const Rational& rRight) const
		//because we need a chain assignemnt /addition we have to use:
		//Rational Rational::operator+(const Rational& rRight) const
	Rational r3(4,9);
	cout << "r1+r2+r3 = ";	printRational(r1 + r2 + r3);
	cout << "nom for (r1 + r2) = " << (r1+r2).getNom();
}

void testPlusReturnValue(){
	Rational r1(1,5);
	Rational r2(3,7);
	cout << " r1 = ";	printRational(r1);
	cout << "r2 = ";	printRational(r2);
	cout << "r1+r2 = ";	printRational(r1 + r2);	
}

void testEqual(){ //assignemnt
	Rational r1(1,5);
	Rational r2(3,7);
	cout << " r1 = ";	printRational(r1);
	cout << "r2 = ";	printRational(r2);
	r1 = r2;
	cout << "r1 = ";	printRational(r1);
	cout << "r2 = ";	printRational(r2);
	Rational r3(4,9);
	r1 = r2 = r3;
	cout << "r1 = ";	printRational(r1);
	cout << "r2 = ";	printRational(r2);
	cout << "r3 = ";	printRational(r3);
	cout << "nom for (r1=r2)= "<< (r1=r2).getNom();
}

void testPlusEqual(){
	Rational r1(1,2);
	Rational r2(1,3);
	cout << " r1 = ";	printRational(r1);
	cout << " r2 = ";	printRational(r2);
	r1 += r2;
	//r1.addToThis(r2);	//IT'S OK BECAUSE WE DON�T NEED
						//THE RESULT OF ADDITION
	cout << "r1 = ";	printRational(r1);
	cout << "r2 = ";	printRational(r2);
	Rational r3(2,3);	printRational(r2);
	r1 += r2 += r3;
	//r1.addToThis(r2).addTotThis(r3); !!!ERROR =>
	//void.addToThis;
	cout << "r1 = ";	printRational(r1);
	cout << "r2 = ";	printRational(r2);
	cout << "r3 = ";	printRational(r3);
	cout<<"nom for (r1+=r2)=" << (r1 += r2).getNom();
}

void testEquality(){
	Rational r1(1,2);
	Rational r2(1,3);
	cout << " r1 = ";	printRational(r1);
	cout << " r2 = ";	printRational(r2);
	if (r1 == r2)
		cout << " equal rational numbers " << endl;
	else
		cout << " different rational numbers " << endl;
}

void testFriendPlus(){
	Rational r1(1,2);
	Rational r2(1,3);
	cout << " r1 = ";	printRational(r1);
	cout << " r2 = ";	printRational(r2);
	Rational r3;
	r3 = r1 + 5; //conversion constructor,
		//addition and assignment
	cout << "r3 = "; 	printRational(r3);
	Rational r4;
	r4 = 8 + r2; //addition by friend plus and
		//assignemnt
	cout << "r4 = ";	printRational(r4);
}

void testStream(){
	Rational r1;
	cin >> r1;
	cout << r1;
	Rational* pr1 = new Rational();
	cin >> *pr1;
	cout << *pr1;
}

void tests(){
	testConstructors();
	testSign();
	testAdress();
	testPlusPlus();
	testPlus();
	testEqual();
	testPlusEqual();
	testEquality();
	testFriendPlus();
	
	testStream();

	testPlusReturnValue();
}


