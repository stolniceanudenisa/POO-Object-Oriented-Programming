#include <iostream>
using namespace std;
#include "Flower.h"
#include <String.h>


bool theSameFlowerWithoutFriend(Flower& f1, Flower &f2){
	//return (strcmp(f1.name, f2.name) == 0)	//ERROR: cannot access private member declared in class 'Flower'
	return (strcmp(f1.getName(), f2.getName()) == 0);
}

void withoutFriend(){
	Flower f1;
	f1.setName("tulip");
	f1.setPrice(10);
	Flower f2;
	f2.setName("tlip");
	f2.setPrice(5);

	if (theSameFlowerWithoutFriend(f1, f2))
		cout << " the same flower ... "  << endl;
	else
		cout << " different flowers ... "  << endl;
}

bool theSameFlowerWithFriend(Flower &f1, Flower &f2){
	return (strcmp(f1.name, f2.name) == 0);
}

void withFriend(){
	Flower f1;
	f1.setName("tulip");
	f1.setPrice(10);
	Flower f2;
	f2.setName("tlip");
	f2.setPrice(5);

	if (theSameFlowerWithFriend(f1, f2))
		cout << " the same flower ... "  << endl;
	else
		cout << " different flowers ... "  << endl;
}

void friendGlobalFunction(){
	withoutFriend();
	withFriend();
}

void friendMemberFunction(){
  Flower f;
  f.setName("daisy");
  Gardener g;
  g.changePrice(f, 100);
  cout << f.getPrice() << endl; 
}

void friendClass(){
  Flower f;
  f.setName("rose");
  f.setPrice(5);
  Gardener g;
  g.changePrice(f, 100);
 
  cout << f.getName() << " " << f.getPrice() << endl; 
}

int main(){
	friendGlobalFunction();
	friendMemberFunction();
	friendClass();

	cout << " good job! " << endl;
	return 0;
}
