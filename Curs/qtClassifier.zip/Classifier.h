#ifndef CLASSIFIER_H
#define CLASSIFIER_H
#include <string>
#include <sstream>
#include <fstream>
#include <vector>
#include <iostream>
#include "Data.h"
using namespace std;


class Classifier{
protected:
	std::vector<Data> knowledgeBase;
public:
	Classifier(){};
	void loadTrainData(char* fileName){
		std::ifstream fin(fileName);
		while (!fin.eof()){
			std::string line;
			fin >> line;
			Data d = Data(line);
			this->knowledgeBase.push_back(d);
		}
		fin.close();
	}
	virtual string bestMatched(string s) = 0;
	virtual ~Classifier(){
	}
};


#endif

