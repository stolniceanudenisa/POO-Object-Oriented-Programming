/*
 * NearestNeighbour.h
 *
 *  Created on: Apr 9, 2019
 *      Author: laura
 */

#ifndef NEARESTNEIGHBOUR_H_
#define NEARESTNEIGHBOUR_H_

#include "Classifier.h"

template <class T>
class NearestNeighbour:public Classifier{
private:
	Distance<T>* dist;
public:
	NearestNeighbour(Distance<T> *d):Classifier(){
		this->dist = d;
	}

	string bestMatched(string s){
		Data d = Data(s + "noLabel");
		string answer = "no label";
		double minDist = s.length();
		for (int i = 0; i < this->knowledgeBase.size(); i++){
			double crtDist = d.compare(this->knowledgeBase[i], this->dist);
			if (crtDist < minDist){
				minDist = crtDist;
				answer = this->knowledgeBase[i].getLabel();
			}	//if
		}	//for i
		return answer;
	}
};



#endif /* NEARESTNEIGHBOUR_H_ */
