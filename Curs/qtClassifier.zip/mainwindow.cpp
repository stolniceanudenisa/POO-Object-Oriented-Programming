#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "DecisionTree.h"
#include "NearestNeighbour.h"
#include "Distance.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_radioButton_clicked()
{

    this->c = new DecisionTree();
    //...
}

void MainWindow::on_radioButton_2_clicked()
{
    Distance<string> *distance;
    distance = new HammingDistance<string>();
    this->c = new NearestNeighbour<string>(distance);
    this->c->loadTrainData("D:\\_Work\\School\\_2018-2019\\sem2\\OOP\\code\\exqt\\test3\\data.in");
}

void MainWindow::on_pushButton_clicked()
{
    QString phrase = this->ui->inputText->toPlainText();
    string label = this->c->bestMatched(phrase.toStdString());
    QString qslabel = QString::fromStdString(label);
    this->ui->categoryText->setText(qslabel);
}

void MainWindow::on_seeFlowers_clicked()
{

}
