/*
 * DecisionTree.h
 *
 *  Created on: Apr 9, 2019
 *      Author: laura
 */

#ifndef DECISIONTREE_H_
#define DECISIONTREE_H_

#include "Classifier.h"
#include <algorithm>

class DecisionTree:public Classifier{


public:
	DecisionTree():Classifier(){
	}
	string bestMatched(string s){
		Data d = Data(s + "noLabel");
		string answer = "no label";
		vector<string> food = {"mere", "pere", "nuci"};
		vector<string> school = {"scoala", "invata"};
		//rule 1
		int noFood = 0;
		for (int i = 0; i < d.getFeatures().size(); i++)
			if (std::find(food.begin(), food.end(), d.getFeatures()[i]) != food.end())
				noFood++;
		//rule 2
		int noSchool = 0;
		for (int i = 0; i < d.getFeatures().size(); i++)
			if (std::find(school.begin(), school.end(), d.getFeatures()[i]) != school.end())
				noSchool++;
		if (noFood > noSchool)
			answer = "food";
		else
			answer = "school";
		return answer;
	}
};



#endif /* DECISIONTREE_H_ */
