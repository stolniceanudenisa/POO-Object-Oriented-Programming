//Sa se determine produsul a 2 matrici alocate static (citire, init, tiparire, produs)
//---------------------------------------------------------------------------
#include <iostream>
using namespace std;

const int MAX = 10;

//---------------------------------------------------------------------------
void readMatrix(int &nrLin, int &nrCol, int mat[][MAX]){
  //Descr: read the elems of a matrix 
  //In: - (reading fc)
  //Out:  the elems of matrix mat and its dimens (nrLin, NrCol)
   cout << "lin no =" ;	//printf("nr lin = ");
   cin >> nrLin;		//scanf("%d", &nrLin);
   cout << "col no = ";	//printf("nr co l= ");
   cin >> nrCol;		//scanf("%d", &nrCol);

   for(int i = 0; i < nrLin; i++)
      for(int j = 0; j < nrCol; j++){
         cout << "mat[" << i + 1 << "," << j + 1 << "] = ";	//printf("mat[%d,%d] = ", i+1, j+1);
         cin >> mat[i][j];									//scanf("%d", &mat[i][j]);
      }     //for j
}
//---------------------------------------------------------------------------
void initMatrix(int nrLin, int nrCol, int mat[][MAX], int val){
  //Descr: initialises all the elems of a matrix by a value 
  //In: the matrix, its dimens, an integer value
  //Out: the matrix (wih all elems equal to the given value)
   for(int i = 0; i < nrLin; i++)
      for(int j = 0; j < nrCol; j++)
         mat[i][j] = val;
}
//---------------------------------------------------------------------------
void printMatrix(int nrLin, int nrCol, int mat[][MAX]){
  //Descr:prints a matrix 
  //In: a matrix mat and its dimens (nrLin, nrCol)
  //Out:  - (printing fc)
   for(int i = 0; i < nrLin; i++){
      for(int j = 0; j < nrCol; j++)
         cout << mat[i][j] << " ";	//printf("%d ", mat[i][j]);
      cout << endl;			//printf("\n");
   }     //for i
}
//---------------------------------------------------------------------------
void productMatrix(int nrLin1, int nrCol1, int mat1[][MAX], int nrLin2, int nrCol2, int mat2[][MAX]){
  //Descr: computes the product of two matrix
  //In: two matrix and their dimens
  //Out: - (the product matrix is printed inside the fc !!!!!!)
   if (nrCol1 == nrLin2){
      int mat_produs[MAX][MAX];
      for(int i = 0; i < nrLin1; i++){
         for(int k = 0; k < nrCol2; k++){
            int sum_j = 0;
            for(int j = 0; j < nrCol1; j++)
				sum_j += mat1[i][j] * mat2[j][k];
            mat_produs[i][k] = sum_j;
          }    //for k
      }     //for i
	  cout << "produc matrix is: " << endl;		//printf("produc matrix is:  \n");
      printMatrix(nrLin1, nrCol2, mat_produs);
   }
   else
      cout << "the product is not possible" << endl;	//printf("the product is not possible... \n");
}
//---------------------------------------------------------------------------
bool productMatrix2(int nrLin1, int nrCol1, int mat1[][MAX], int nrLin2, int nrCol2, int mat2[][MAX], int mat_produs[][MAX]){
  //Descr: computes the product of two matrix
  //In: two matrix and their dimens
  //Out: the product matrix and its dimens and an aswer (T, if the product was computed, F, otherwise)
   if (nrCol1 == nrLin2){
      for(int i = 0; i < nrLin1; i++){
         for(int k = 0; k < nrCol2; k++){
            int sum_j = 0;
            for(int j = 0; j < nrCol1; j++)
				sum_j += mat1[i][j] * mat2[j][k];
            mat_produs[i][k] = sum_j;
          }    //for k
      }     //for i
	  return true;
   }
   else
     return false;
}

//---------------------------------------------------------------------------
int main(int argc, char* argv[])
{
   int n1;
   int n2;
   int m1;
   int m2;
   int a[MAX][MAX];
   int b[MAX][MAX];
   int c[MAX][MAX];

   readMatrix(n1, m1, a);
   printMatrix(n1, m1, a);
   
   readMatrix(n2, m2, b);
   printMatrix(n2, m2, b);
   
   //productMatrix(n1, m1, a, n2, m2, b);
   if (productMatrix2(n1, m1, a, n2, m2, b, c)){
		cout << "produc matrix is: " << endl;		//printf("produc matrix is:  \n");
		printMatrix(n1, m2, c);
   }
   else{
	    cout << "the product is not possible" << endl;	//printf("the produc is not possible... \n");
   }
   return 0;
}
//---------------------------------------------------------------------------
