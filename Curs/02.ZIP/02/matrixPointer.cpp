//Sa se determine produsul a 2 matrici alocate dinamic (creare, distrugere,
//citire, init, tiparire, produs)
//matricea e transmisa ca param de iesire prin referinta
//---------------------------------------------------------------------------

#include <iostream>
using namespace std;

const int MAX = 10;
//---------------------------------------------------------------------------
void allocation(int nrLin, int nrCol, int** &mat){
  //Descr: memory allocation for a matrix
  //In: a matrix and its dimens
  //Out: matrix (with allocated memory)
	mat = new int* [nrLin];
	for(int i = 0; i < nrLin; i++)
		mat[i] = new int[nrCol];
}
//---------------------------------------------------------------------------
void deallocation(int nrLin, int** &mat){
  //Descr: memory dezallocation for a matrix
  //In: a matrix and its no of lines
  //Out: matrix (without memory)
      //in the reverse order of allocation
	for(int i = 0; i < nrLin; i++){
		delete[] mat[i];
		mat[i] = NULL;
	}
	delete[] mat;
	mat = NULL;
}
//---------------------------------------------------------------------------
void readMatrix(int &nrLin, int &nrCol, int **&mat){
  //Descr: read the elems of a matrix 
  //In: - (reading fc)
  //Out:  the elems of matrix mat and its dimens (nrLin, NrCol)
	cout << "lin no =" ;	//printf("nr lin = ");
	cin >> nrLin;		//scanf("%d", &nrLin);
	cout << "col no = ";	//printf("nr co l= ");
	cin >> nrCol;		//scanf("%d", &nrCol);

	allocation(nrLin, nrCol, mat);

	for(int i = 0; i < nrLin; i++)
      for(int j = 0; j < nrCol; j++){
         cout << "mat[" << i + 1 << "," << j + 1 << "] = ";	//printf("mat[%d,%d] = ", i+1, j+1);
         cin >> mat[i][j];									//scanf("%d", &mat[i][j]);
      }     //for j
}
//---------------------------------------------------------------------------
void init(int nrLin, int nrCol, int **mat, int val){
  //Descr: initialises all the elems of a matrix by a value 
  //In: the matrix, its dimens, an integer value
  //Out: the matrix (wih all elems equal to the given value)
  for(int i = 0; i < nrLin; i++)
      for(int j = 0; j < nrCol; j++)
         mat[i][j] = val;
}
//---------------------------------------------------------------------------
void printMatrix(int nrLin, int nrCol, int **mat){
  //Descr:prints a matrix 
  //In: a matrix mat and its dimens (nrLin, nrCol)
  //Out:  - (printing fc)
  for(int i = 0; i < nrLin; i++){
      for(int j = 0; j < nrCol; j++)
         cout << mat[i][j] << " ";	//printf("%d ", mat[i][j]);
      cout << endl;			//printf("\n");
    }     //for i
}
//---------------------------------------------------------------------------
void product(int nrLin1, int nrCol1, int** mat1, int nrLin2, int nrCol2, int** mat2){
  //Descr: computes the product of two matrix
  //In: two matrix and their dimens
  //Out: - (the product matrix is printed inside the fc !!!!!!)
		//product nmatrix is local to this fc
		//it is printed inside the fc   
   if (nrCol1 == nrLin2){
      int **mat_produs;
	  allocation(nrLin1, nrCol2, mat_produs);
      for(int i = 0; i < nrLin1; i++){
         for(int k = 0; k < nrCol2; k++){
            int sum_j = 0;
            for(int j = 0; j < nrCol1; j++)
				sum_j += mat1[i][j] * mat2[j][k];
            mat_produs[i][k] = sum_j;
          }    //for k
      }     //for i
	  cout << "produc matrix is: " << endl;		//printf("produc matrix is:  \n");
      printMatrix(nrLin1, nrCol2, mat_produs);
	  deallocation(nrLin1, mat_produs);
   }
   else
      cout << "the product is not possible" << endl;	//printf("the product is not possible... \n");
}
//---------------------------------------------------------------------------
bool product2(int nrLin1, int nrCol1, int** mat1, int nrLin2, int nrCol2, int** mat2, int **&mat_produs){
  //Descr: computes the product of two matrix
  //In: two matrix and their dimens
  //Out: the product matrix and its dimens and an aswer (T, if the product was computed, F, otherwise)
 
		//product nmatrix is an output param
		//it will be printed outside to the fc
   if (nrCol1 == nrLin2){
	  allocation(nrLin1, nrCol2, mat_produs);
      for(int i = 0; i < nrLin1; i++){
         for(int k = 0; k < nrCol2; k++){
            int sum_j = 0;
            for(int j = 0; j < nrCol1; j++)
				sum_j += mat1[i][j] * mat2[j][k];
            mat_produs[i][k] = sum_j;
          }    //for k
      }     //for i
	  return true;
   }
   else
	   return false;
}
//---------------------------------------------------------------------------
int** product3(int nrLin1, int nrCol1, int** mat1, int nrLin2, int nrCol2, int** mat2){
  //Descr: computes the product of two matrix
  //In: two matrix and their dimens
  //Out: the product matrix or NULL
		//product nmatrix is return as fc result
		//it will be printed outside to the fc
   if (nrCol1 == nrLin2){
	  int **mat_produs;
	  allocation(nrLin1, nrCol2, mat_produs);
      for(int i = 0; i < nrLin1; i++){
         for(int k = 0; k < nrCol2; k++){
            int sum_j = 0;
            for(int j = 0; j < nrCol1; j++)
				sum_j += mat1[i][j] * mat2[j][k];
            mat_produs[i][k] = sum_j;
          }    //for k
      }     //for i
	  return mat_produs;
   }
   else
	   return NULL;
}
//---------------------------------------------------------------------------

void run1(){
	   int n1;
   int n2;
   int m1;
   int m2;
   int **a;
   int **b;

   readMatrix(n1, m1, a);
   printMatrix(n1, m1, a);
   
   readMatrix(n2, m2, b);
   printMatrix(n2, m2, b);
   		//product nmatrix is local to this fc
		//it is printed inside the fc
   product(n1, m1, a, n2, m2, b);
   
   deallocation(n1, a);
   deallocation(n2, b);
}
//---------------------------------------------------------------------------
void run2(){
	   int n1;
   int n2;
   int m1;
   int m2;
   int **a;
   int **b;
   int **c;

   readMatrix(n1, m1, a);
   printMatrix(n1, m1, a);
   
   readMatrix(n2, m2, b);
   printMatrix(n2, m2, b);
   		//product nmatrix is an output param of the fc
		//it will be printed outside to the fc
   if (product2(n1, m1, a, n2, m2, b, c)){
	  cout << "produc matrix is: " << endl;		//printf("produc matrix is:  \n");
      printMatrix(n1, m2, c);
	  deallocation(n1, c);
   }
   else
      cout << "the product is not possible" << endl;	//printf("the product is not possible... \n");
   
   deallocation(n1, a);
   deallocation(n2, b);
}
//---------------------------------------------------------------------------
void run3(){
	   int n1;
   int n2;
   int m1;
   int m2;
   int **a;
   int **b;
   int **c;

   readMatrix(n1, m1, a);
   printMatrix(n1, m1, a);
   
   readMatrix(n2, m2, b);
   printMatrix(n2, m2, b);
   
		//product nmatrix is return as fc result
		//it will be printed outside to the fc
   if (( c = product3(n1, m1, a, n2, m2, b)) != NULL){
	  cout << "produc matrix is: " << endl;		//printf("produc matrix is:  \n");
      printMatrix(n1, m2, c);
	  deallocation(n1, c);
   }
   else
      cout << "the product is not possible" << endl;	//printf("the product is not possible... \n");
   
   deallocation(n1, a);
   deallocation(n2, b);
}
//---------------------------------------------------------------------------
int main(int argc, char* argv[]){
	//run1();
	//run2();
	run3();
	return 0;
}



	   