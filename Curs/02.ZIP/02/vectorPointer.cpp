//---------------------------------------------------------------------------
#include <iostream>
using namespace std;

typedef int* vector;

int maxim(int l, int* v){
  //Descr: computes the max elem of an array
  //In: an array v and its length l
  //Out: the max elem of v
  int i;
  int max = v[0];
  for(i = 1; i < l; i++)
    if (v[i] > max)
         max = v[i];
  return max;
}
//---------------------------------------------------------------------------
void readVector(int &l, int* v){
  //Descr: reads the elem of an array
  //In:  - (reading fc)
  //Out: the elements of array v and its length (l)
  int i;
  cout << "nr elem = ";	//printf("nr elem = ");
  cin >> l;				//scanf("%d", &l);
  for(i = 0; i < l; i++){
    cout << "v[" << i + 1 << "] = ";	//printf("v[%d] = ", i + 1);
    cin >> v[i];						//scanf("%d", &v[i]);
  }     //for i
}
//---------------------------------------------------------------------------                    
void printVector(int l, int* v){
  //Descr: prints the elem of an array
  //In: an array v and its length l
  //Out: - (printing fc)
  int i;
  cout << "vector is ";		//printf("vector is: ");
  for(i = 0; i < l; i++)
    cout << v[i] << " ";	//printf("%d ", v[i]);
  cout << endl;				//printf("\n");
}
//---------------------------------------------------------------------------
void allocation(int l, int* &v){
  //Descr: allocates memory for the elem of an array 
  //In: an array v and its length l
  //Out: an array v (its address)
  v = new int[l];
}
//---------------------------------------------------------------------------
void allocation2(int l, int** v){
  //Descr: allocates memory for the elem of an array 
  //In: an array v and its length l
  //Out: an array v (its address)
  *v = new int[l];
}
//---------------------------------------------------------------------------
void deallocation(int* &v){
  //Descr: frees memory for the elem of an array 
  //In: an array v 
  //Out:  - 
	if (v != NULL){
		delete[] v;
		v = NULL;
	}
}
//---------------------------------------------------------------------------
void deallocation2(int** v){
  //Descr: frees memory for the elem of an array 
  //In: an array v 
  //Out:  - 
	if (*v != NULL){
		delete[] *v;
		*v = NULL;
	}
}
//---------------------------------------------------------------------------
void run1(){	//local allocation/release
   int n;
   int* b;
   b = new int[10];
   readVector(n, b);
   printVector(n, b);
   cout << "Max is " << maxim(n, b);	//printf("Max is %d \n", maxim(n, b));
   if (b != NULL){
	  delete[] b;
	  b = NULL;
   }
}
//---------------------------------------------------------------------------
void run2(){	//allocation/release in other functions - with reference
   int n;
   int* b;
   allocation(10, b);
   readVector(n, b);
   printVector(n, b);
   cout << "Max is " << maxim(n, b);	//printf("Max is %d \n", maxim(n, b));
   deallocation(b);
}
//---------------------------------------------------------------------------
void run3(){	//allocation/release in other functions - with pointers
   int n;
   int* b;
   allocation2(10, &b);
   readVector(n, b);
   printVector(n, b);
   cout << "Max is " << maxim(n, b);	//printf("Max is %d \n", maxim(n, b));
   deallocation2(&b);
}
//---------------------------------------------------------------------------
int main3(int argc, char* argv[]){
   run1();
   run2();
   run3();
   return 0;
}