#include "Tree.h"
#include <iostream>
using namespace std;

Tree::Tree():Plant(){
	cout << "[Tree] : default constructor " << endl;
	height = 0;
}

Tree::Tree(const Tree& t) : Plant(t){
	cout << "[Tree] : copy constructor " << endl;
	height = t.height;
}

Tree::~Tree(){
	cout << "[Tree] : detructor " << endl;
}

Tree& Tree::operator=(const Tree &t){
	cout << "[Tree] : operator= " << endl;
	if (this != &t){
		Plant::operator =(t);
		height = t.height;
	}
	return *this;
}

Plant* Tree::clone(){
	Tree* newTree = new Tree();
	newTree->setName(name);
	newTree->height = height;
	return newTree;
}

void Tree::setHeight(int n){
	height = n;
}

int Tree::getHeight(){
	return height;
}

char* Tree::toString(){
	int l = strlen(name) + strlen("this is a tree  of height ") + 6 + 1;
	char* s = new char[l];
	strcpy_s(s, l, "This is a tree ");
	strcat_s(s, l, name);
	strcat_s(s, l, " of height ");
	char* aux = new char[6];
	_itoa_s(height, aux, 6, 10);
	strcat_s(s, l, aux);
	delete[] aux;
	return s;
}

ostream& operator<<(ostream &os, Tree &t){
	os << "This is a tree " << t.name << " of height " << t.height;
	return os;
}