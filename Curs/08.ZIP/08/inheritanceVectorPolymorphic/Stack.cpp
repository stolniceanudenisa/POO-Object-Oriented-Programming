#include "Stack.h"

Stack::Stack(int c){
	capacity = c;
	size = 0;
	elements = new Plant*[c];
}

Stack::Stack(const Stack &s){
	capacity = s.capacity;
	size = s.size;
	for(int i = 0; i < size; i++)
		//elements[i] = s.elements[i];
		//elements[i] = new Plant(*s.elements[i]);
		elements[i] = s.elements[i]->clone();
}

Stack::~Stack(){
	if (elements){
		for(int i = 0; i < size; i++)
			if (elements[i]){
				delete elements[i];
				elements[i] = NULL;
			}
		delete[] elements;
		elements = NULL;
	}
}

Stack& Stack::operator=(const Stack &s){
	if (this != &s){
		capacity = s.capacity;
		size = s.size;
		for(int i = 0; i < size; i++)
			//elements[i] = s.elements[i];
			//elements[i] = new Plant(*s.elements[i]);
			elements[i] = s.elements[i]->clone();
	}
	return *this;
}

int Stack::getCapacity(){
	return capacity;
}

int Stack::getSize(){
	return size;
}

Plant* Stack::top(){	//access the top element 
	if (size > 0)
		return elements[size - 1];
	return NULL;
}

void Stack::push(Plant* p){	//put an elem on the Stack
	if (size < capacity){
		//elements[size++] = p;
		//elements[size++] = new Plant(*p);
		elements[size++] = p->clone();
	}
	else
		cout << "stack is full..." << endl;
}

Plant* Stack::pop(){	//get the top element and remove it from the stack
	if (size > 0){
		return elements[--size];
	}
	return NULL;
}