#include "Plant.h"
#include <iostream>
using namespace std;

Plant::Plant(){
	cout << "[Plant] : default constructor " << endl;
	name = new char[10];
}

Plant::Plant(const Plant &p){
	cout << "[Plant] : copy constructor " << endl;
	name = new char[strlen(p.name) + 1];
	strcpy_s(name, strlen(p.name) + 1, p.name);
}

Plant::~Plant(){
	cout << "[Plant] : destructor " << endl;
	if (name){
		delete[] name;
		name = NULL;
	}
}

Plant& Plant::operator=(const Plant &p){
	cout << "[Plant] : operator = " << endl;
	if (this != &p){
		if (name)
			delete[] name;
		name = new char[strlen(p.name) + 1];
		strcpy_s(name, strlen(p.name) + 1, p.name);
	}
	return *this;
}

Plant* Plant::clone(){
	Plant* newPlant = new Plant();
	newPlant->setName(this->name);
	return newPlant;
}

void Plant::setName(char* n){
	if (name)
		delete[] name;
	name = new char[strlen(n) + 1];
	strcpy_s(name, strlen(n) + 1, n);
}

char* Plant::getName(){
	return name;
}

char* Plant::toString(){
	int l = strlen(name) + strlen("this is a plant ") + 1;
	char* s = new char[l];
	strcpy_s(s, l, "This is a plant ");
	strcat_s(s, l, name);
	return s;
}

ostream& operator<<(ostream &os, Plant &p){
	os << "This is a plant " << p.name;
	return os;
}