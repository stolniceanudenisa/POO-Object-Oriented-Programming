#include "Vector.h"

Vector::Vector(){
	size = 0;
	elements = new Plant*[10];
}

Vector::Vector(const Vector& v){
	size = v.size;
	elements = new Plant*[v.size];
	for(int i = 0; i < v.size; i++)
		//elements[i] = v.elements[i];
		//elements[i] = new Plant(*v.elements[i]);
		elements[i] = v.elements[i]->clone();
}

Vector::~Vector(){
	if (elements){
		for(int i = 0; i < size; i++)
			if (elements[i]){
				delete elements[i];
				elements[i] = NULL;
			}
		delete[] elements;
		elements = NULL;
	}
}

Vector& Vector::operator=(const Vector& v){
	if (this != &v){
		size = v.size;
		if (elements)
			delete[] elements;
		elements = new Plant*[v.size];
		for(int i = 0; i < v.size; i++)
			//elements[i] = v.elements[i];
			//elements[i] = new Plant(*v.elements[i]);
			elements[i] = v.elements[i]->clone();
	}
	return *this;
}

int Vector::getSize(){
	return size;
}

Plant* Vector::getElem(int pos){
	return elements[pos];
}

void Vector::addElem(Plant* p){
	//elements[size++] = p;
	//elements[size++] = new Plant(*p);
	elements[size++] = p->clone();
}
