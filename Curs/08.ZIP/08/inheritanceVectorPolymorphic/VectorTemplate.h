#ifndef VECTORTEMPLATE_H
#define VECTORTEMPLATE_H

#include <stdlib.h>

template <class T>
class VectorTemplate{
private:
	int size;
	T* elements;
public:
	VectorTemplate();
	VectorTemplate(const VectorTemplate<T> &v);
	~VectorTemplate();
	VectorTemplate<T>& operator=(const VectorTemplate<T> &v);
	int getSize();
	T getElem(int);
	void addElem(T el);

};

template <class T>
VectorTemplate<T>::VectorTemplate(){
	size = 0;
	elements = new T[10];
}

template <class T>
VectorTemplate<T>::VectorTemplate(const VectorTemplate<T> &v){
	size = v.size;
	elements = new T[v.size];
	for (int i = 0; i < v.size; i++)
		//elements[i] = v.elements[i];
		elements[i] = v.elements[i]->clone();
}

template <class T>
VectorTemplate<T>::~VectorTemplate(){
	if (elements){
		delete[] elements;
		elements = NULL;
	}
}

template <class T>
VectorTemplate<T>& VectorTemplate<T>::operator=(const VectorTemplate<T> &v){
	if (this != &v){
		size = v.size;
		if (elements)
			delete[] elements;
		elements = new T[v.size];
		for (int i = 0; i < v.size; i++)
			//elements[i] = v.elements[i];
			elements[i] = v.elements[i]->clone();
	}
	return *this;
}

template <class T>
int VectorTemplate<T>::getSize(){
	return size;
}

template <class T>
T VectorTemplate<T>::getElem(int pos){
	return elements[pos];
}

template <class T>
void VectorTemplate<T>::addElem(T el){
	//elements[size++] = el;
	elements[size++] = el->clone();
}


#endif