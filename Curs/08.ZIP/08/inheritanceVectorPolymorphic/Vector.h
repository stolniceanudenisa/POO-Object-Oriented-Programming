#ifndef VECTOR_H
#define VECTOR_H

#include "Plant.h"

class Vector{
private:
	int size;
	Plant* * elements;
public:
	Vector();
	Vector(const Vector&);
	~Vector();
	Vector& operator=(const Vector&);
	int getSize();
	Plant* getElem(int);
	void addElem(Plant*);

};
#endif