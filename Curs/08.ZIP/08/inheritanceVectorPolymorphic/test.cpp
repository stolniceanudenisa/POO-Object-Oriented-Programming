#include "VectorTemplate.h"
#include "Vector.h"
#include "Flower.h"
#include "Tree.h"
#include "Stack.h"
#include "Queue.h"
using namespace std;

void mainPlants(){
	Plant p1;
	p1.setName("rose");
	Plant p2;
	p2.setName("daisy");
	Vector v;
	v.addElem(&p1);
	v.addElem(&p2);
	char* s = v.getElem(0)->toString();
	cout << s << endl;
	delete[] s;
	s = v.getElem(1)->toString();
	cout << s << endl;
	delete[] s;
}


void mainFlowers(){
	Flower f1;
	f1.setName("rose");
	f1.setNoPetals(5);
	Flower f2;
	f2.setName("daisy");
	f2.setNoPetals(10);
	Vector v;
	v.addElem(&f1);
	v.addElem(&f2);
	char* s = v.getElem(0)->toString();
	cout << s << endl;
	delete[] s;
	s = v.getElem(1)->toString();
	cout << s << endl;
	delete[] s;
}

void mainFlowersAndTrees(){
	Flower* fp = new Flower();
	fp->setName("daisy");
	fp->setNoPetals(11);
	Tree* tp = new Tree();
	tp->setName("PeachTree");
	tp->setHeight(10);

	Vector v;
	v.addElem(fp);
	v.addElem(tp);

	for(int i = 0; i < 2; i++){
		char* s = v.getElem(i)->toString();
		cout << s << endl;	//flower and tree
		delete[] s;
	}
	
	for(int i = 0; i < 2; i++){
		cout << *v.getElem(i) << endl;	//plant and plant
	}
	delete tp;
	delete fp;
}


void mainFlowersAndTreesTemplate(){
	Flower* fp = new Flower();
	fp->setName("daisy");
	fp->setNoPetals(11);
	Tree* tp = new Tree();
	tp->setName("PeachTree");
	tp->setHeight(10);

	VectorTemplate<Plant*> v;
	v.addElem(fp);
	v.addElem(tp);

	fp->setName("rose");

	cout << "in vector: " << endl;

	for (int i = 0; i < 2; i++){
		char* s = v.getElem(i)->toString();
		cout << s << endl;	//flower and tree
		delete[] s;
	}

	for (int i = 0; i < 2; i++){
		cout << *v.getElem(i) << endl;	//Plant and Plant
	}
}

void mainFlowersAndTreesInStack(){
	Flower* fp = new Flower();
	fp->setName("daisy");
	fp->setNoPetals(11);
	Tree* tp = new Tree();
	tp->setName("PeachTree");
	tp->setHeight(10);

	Stack s(5);
	s.push(fp);
	s.push(tp);

	for(int i = 0; i < 2; i++){
		Plant* pp = s.pop();
		char* ss = pp->toString();
		cout << ss << endl;	//flower and tree
		delete[] ss;
		delete pp;
	}
	if (tp)
		delete tp;
	if (fp)
		delete fp;
}

void mainFlowersAndTreesInQueue(){
	Flower* fp = new Flower();
	fp->setName("daisy");
	fp->setNoPetals(11);
	Tree* tp = new Tree();
	tp->setName("PeachTree");
	tp->setHeight(10);

	Queue q(5);
	q.enqueue(fp);
	q.enqueue(tp);

	for(int i = 0; i < 2; i++){
		Plant* pp = q.dequeue();
		char* ss = pp->toString();
		cout << ss << endl;	//flower and tree
		delete[] ss;
		delete pp;
	}
	if (tp)
		delete tp;
	if (fp)
		delete fp;
}
int main(){
	//mainPlants();
	//mainFlowers();
	//mainFlowersAndTrees();

	mainFlowersAndTreesTemplate();

	//mainFlowersAndTreesInStack();
	//mainFlowersAndTreesInQueue();
	return 0;
}