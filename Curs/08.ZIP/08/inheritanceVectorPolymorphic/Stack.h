#ifndef STACK_H
#define STACK_H

#include "Plant.h"

class Stack{
private:
	int capacity;
	int size;
	Plant** elements;
public:
	Stack(int);
	Stack(const Stack&);
	~Stack();
	Stack& operator=(const Stack&);
	int getCapacity();
	int getSize();
	Plant* top();	//access the top element 
	void push(Plant*);	//put an elem on the Stack
	Plant* pop();	//get the top element and remove it from the stack
};
#endif