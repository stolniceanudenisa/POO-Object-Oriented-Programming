#ifndef PLANT_H
#define PLANT_H
#include <string>
#include <stdlib.h>
#include <iostream>
using namespace std;

class Plant{
protected:
	char* name;
public:
	Plant();
	Plant(const Plant &);
	virtual ~Plant();
	virtual Plant* clone();
	virtual Plant& operator=(const Plant&);
	void setName(char* n);
	char* getName();
	virtual char* toString();
	friend ostream& operator<<(ostream &, Plant &);
};
#endif