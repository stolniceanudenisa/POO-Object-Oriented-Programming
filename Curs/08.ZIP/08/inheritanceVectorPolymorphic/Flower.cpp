#include "Flower.h"
#include <iostream>
using namespace std;

Flower::Flower():Plant(){
	cout << "[Flower] : default constructor " << endl;
	noPetals = 0;
}
Flower::Flower(const Flower& f):Plant(f){
	cout << "[Flower] : copy constructor " << endl;
	noPetals = f.noPetals;
}

Flower::~Flower(){
	cout << "[Flower] : detructor " << endl;
}

Flower& Flower::operator=(const Flower &f){
	cout << "[Flower] : operator= " << endl;
	if (this != &f){
		Plant::operator=(f);
		noPetals = f.noPetals;
	}
	return *this;
}

Plant* Flower::clone(){
	Flower* newFlower = new Flower();
	newFlower->setName(name);
	newFlower->noPetals = noPetals;
	return newFlower;
}

void Flower::setNoPetals(int n){
	noPetals = n;
}

int Flower::getNoPetals(){
	return noPetals;
}

char* Flower::toString(){
	int l = strlen(name) + strlen("this is a flower  with  petals") + 6 + 1;
	char* s = new char[l];
	strcpy_s(s, l, "This is a flower ");
	strcat_s(s, l, name);
	strcat_s(s, l, " with ");
	char* aux = new char[6];
	_itoa_s(noPetals, aux, 6, 10);
	strcat_s(s, l, aux);
	strcat_s(s, l, " petals");
	delete[] aux;
	return s;
}

ostream& operator<<(ostream &os, Flower &f){
	os << "This is a flower " << f.name << " with " << f.noPetals << " petals ";
	return os;
}