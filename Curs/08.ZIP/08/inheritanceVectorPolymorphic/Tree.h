#ifndef TREE_H
#define TREE_H

#include "Plant.h"

class Tree : public Plant{
private:
	int height;
public:
	Tree();
	Tree(const Tree&);
	~Tree();
	Tree& operator=(const Tree&);
	Plant* clone();
	void setHeight(int);
	int getHeight();
	char* toString();
	friend ostream& operator<<(ostream &, Tree &);
};
#endif