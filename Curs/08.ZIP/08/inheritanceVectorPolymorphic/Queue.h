#ifndef QUEUE_H
#define QUEUE_H

#include "Plant.h"

class Queue{
private:
	int capacity;
	int size;
	Plant** elements;
public:
	Queue(int);
	Queue(const Queue&);
	~Queue();
	Queue& operator=(const Queue&);
	int getCapacity();
	int getSize();
	Plant* head();	//access the first element 
	void enqueue(Plant*);	//put to the end an elem in the Queue
	Plant* dequeue();	//get the first element and remove it from the Queue
};
#endif