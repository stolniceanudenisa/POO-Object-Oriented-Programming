#include "Queue.h"

Queue::Queue(int c){
	capacity = c;
	size = 0;
	elements = new Plant*[c];
}

Queue::Queue(const Queue &q){
	capacity = q.capacity;
	size = q.size;
	for(int i = 0; i < size; i++)
		//elements[i] = q.elements[i];
		//elements[i] = new Plant(*q.elements[i]);
		elements[i] = q.elements[i]->clone();
}

Queue::~Queue(){
	if (elements){
		for(int i = 0; i < size; i++)
			if (elements[i]){
				delete elements[i];
				elements[i] = NULL;
			}
		delete[] elements;
		elements = NULL;
	}
}

Queue& Queue::operator=(const Queue &q){
	if (this != &q){
		capacity = q.capacity;
		size = q.size;
		for(int i = 0; i < size; i++)
			//elements[i] = q.elements[i];
			//elements[i] = new Plant(*q.elements[i]);
			elements[i] = q.elements[i]->clone();
	}
	return *this;
}

int Queue::getCapacity(){
	return capacity;
}

int Queue::getSize(){
	return size;
}

Plant* Queue::head(){	//access the top element 
	if (size > 0)
		return elements[0];
	return NULL;
}

void Queue::enqueue(Plant* p){	//put an elem on the Stack
	if (size < capacity){
		//elements[size++] = p;
		//elements[size++] = new Plant(*p);
		elements[size++] = p->clone();
	}
	else
		cout << "Queue is full..." << endl;
}

Plant* Queue::dequeue(){	//get the top element and remove it from the stack
	if (size > 0){
		Plant* p = elements[0];
		for(int i = 0; i < size - 1; i++)
			elements[i] = elements[i + 1];
		size--;
		return p;
	}
	return NULL;
}