#ifndef FLOWER_H
#define FLOWER_H

#include "Plant.h"

class Flower : public Plant{
private:
	int noPetals;
public:
	Flower();
	Flower(const Flower&);
	~Flower();
	Flower& operator=(const Flower&);
	Plant* clone();
	void setNoPetals(int);
	int getNoPetals();
	char* toString();
	friend ostream& operator<<(ostream &, Flower &);
};
#endif