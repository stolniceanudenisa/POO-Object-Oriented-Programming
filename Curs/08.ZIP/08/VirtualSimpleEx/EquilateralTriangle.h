#ifndef EQUILATERALTRIANGLE_H
#define EQUILATERALTRIANGLE_H

#include "Triangle.h"

class EquilateralTriangle : public Triangle{
private:
	Point v1;
	Point v2;
	Point v3;
public:
	EquilateralTriangle(Point &p1, Point &p2, Point &p3): Triangle(p1, p2, p3), v1(p1), v2(p2), v3(p3){
	}
	EquilateralTriangle(const EquilateralTriangle &t) : Triangle(t){
		this->v1 = t.v1;
		this->v2 = t.v2;
		this->v3 = t.v3;
	}
	~EquilateralTriangle(){
	}
		//overridden method from Triangle
	float area(){
		cout << "[EquilateralTriangle] : area " << endl;
		float l1 = sqrt((float)((v1.getX() - v2.getX()) * (v1.getX() - v2.getX()) + (v1.getY() - v2.getY()) *  (v1.getY() - v2.getY())));
		float p = ((double)(l1 + l1 + l1)) / 2;
		return sqrt(p * (p - l1) * (p - l1) * (p - l1));
	}
		
	virtual int noOfEdges(){
		cout << "[EquilateralTriangle] : noOfEdges " << endl;
		return 3;
	}
};
#endif