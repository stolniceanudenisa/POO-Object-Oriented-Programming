#ifndef SQUARE_H
#define SQUARE_H
#include "Figure.h"

class Square : public Figure{
private:
	Point leftUpCorner;
	Point rightDownCorner;
public:
	Square(Point &l, Point &r):leftUpCorner(l), rightDownCorner(r){}
	Square(const Square &s){
		leftUpCorner = s.leftUpCorner;
		rightDownCorner = s.rightDownCorner;
	}
	~Square(){}
		//overridden method from Figure
	float area(){
		cout << "[Square] : area " << endl;
		return (leftUpCorner.getX() - rightDownCorner.getX()) * (leftUpCorner.getX() - rightDownCorner.getX());
	}
		//overridden method from Figure
	float perimeter(){
		cout << "[Square] : perimeter " << endl;
		return 4 * (leftUpCorner.getX() - rightDownCorner.getX());
	}
};
#endif