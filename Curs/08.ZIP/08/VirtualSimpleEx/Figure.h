#ifndef FIGURE_H
#define FIGURE_H
#include "Point.h"
#include <iostream>
using namespace std;

class Figure{
public:
	virtual float area(){
		cout << "[Figure] : area " << endl;
		return 0.0;
	}
	virtual float perimeter(){
		cout << "[Figure] : perimeter " << endl;
		return 0.0;
	}
};
#endif