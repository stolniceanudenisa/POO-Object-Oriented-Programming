#ifndef POINT_H
#define POINT_H

class Point{
private:
	int x;
	int y;
public:
	Point():x(0),y(0){
	}
	Point(int x1, int y1):x(x1),y(y1){
	}
	Point(const Point &p){
		x = p.x;
		y = p.y;
	}
	~Point(){
	}
	Point& operator=(const Point &p){
		if (this != &p){
			x = p.x;
			y = p.y;
		}
		return *this;
	}
	int getX(){
		return x;
	}
	int getY(){
		return y;
	}
	void setX(int v){
		x = v;
	}
	void setY(int v){
		y = v;
	}
};
#endif