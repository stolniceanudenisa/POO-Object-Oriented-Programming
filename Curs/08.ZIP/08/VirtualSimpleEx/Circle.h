#ifndef CIRCLE_H
#define CIRCLE_H
#include "Figure.h"

const float PI = 3.14;

class Circle : public Figure{
private:
	float radius;
	Point center;
public:
	Circle(float r, Point &c):radius(r), center(c){}
	Circle(const Circle &c){
		radius = c.radius;
		center = c.center;
	}
	~Circle(){}
		//overridden method from Figure
	float area(){
		cout << "[Circle] : area " << endl;
		return PI * radius * radius;
	}
	float perimeter(){
		cout << "[Circle] : perimeter " << endl;
		return 2 * PI * radius;
	}
};
#endif