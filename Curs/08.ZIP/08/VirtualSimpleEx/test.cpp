#include "Circle.h"
#include "Square.h"
#include "EquilateralTriangle.h"

void printArea(Figure* f){
	cout << f->area() << endl;
}

void printPerimeter(Figure* f){
	cout << f->perimeter() << endl;
}

void virtualSimpleDerived(){
	Figure* vector[2];
	Figure* f1 = new Circle(5, Point(2, 3));
	Figure* f2 = new Square(Point(6, 6), Point(4, 4));

	vector[0] = f1;
	vector[1] = f2;
	for(int i = 0; i < 2; i++)
		printArea(vector[i]);
			//[Circle] : area 78.5
			//[Square] : area 4
	for(int i = 0; i < 2; i++)
		printPerimeter(vector[i]);
			//[Figure] : area 0
			//[Square] : area 8
}

void virtualDoubleDerived(){
	Figure* vector[4];
	vector[0] = new Circle(5, Point(2,3));
	vector[1] = new Square(Point(6,6), Point(4,4));
	vector[2] = new Triangle(Point(0,0), Point(4,4), Point(10, 0));
	vector[3] = new EquilateralTriangle(Point(0,0), Point(2.5, sqrt(18.75)), Point(5, 0));
	for(int i = 0; i < 4; i++)
		printArea(vector[i]);
			//[Circle] : area 78.5
			//[Square] : area 4
	for(int i = 0; i < 4; i++)
		printPerimeter(vector[i]);
			//[Figure] : area 0
			//[Square] : area 8
}

void addNewVirtualFunctionInDerivedClass(){
	Figure* fig;
	fig = new EquilateralTriangle(Point(0,0), Point(2.5, sqrt(18.75)), Point(5, 0));
	//cout << fig->noOfEdges() << endl;	//error: 'noOfEdges' : is not a member of 'Figure'
	cout << ((EquilateralTriangle*)fig)->noOfEdges() << endl;
}

int main(){
	virtualSimpleDerived();
	//virtualDoubleDerived();
	//addNewVirtualFunctionInDerivedClass();
	return 0;
}