#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "Figure.h"
#include <math.h>


class Triangle : public Figure{
protected:
	Point v1;
	Point v2;
	Point v3;
public:
	Triangle(Point &p1, Point &p2, Point &p3):v1(p1), v2(p2), v3(p3){
	}
	Triangle(const Triangle &t){
		v1 = t.v1;
		v2 = t.v2;
		v3 = t.v3;
	}
	~Triangle(){}
		//overridden method from Figure
	float area(){
		cout << "[Triangle] : area " << endl;
		float l1 = sqrt((float)((v1.getX() - v2.getX()) * (v1.getX() - v2.getX()) + (v1.getY() - v2.getY()) *  (v1.getY() - v2.getY())));
		float l2 = sqrt((float)((v1.getX() - v3.getX()) * (v1.getX() - v3.getX()) + (v1.getY() - v3.getY()) *  (v1.getY() - v3.getY())));
		float l3 = sqrt((float)((v3.getX() - v2.getX()) * (v3.getX() - v2.getX()) + (v3.getY() - v2.getY()) *  (v3.getY() - v2.getY())));
		float p = ((double)(l1 + l2 + l3)) / 2;
		return sqrt(p * (p - l1) * (p - l2) * (p - l3));
	}
		//overridden method from Figure
	float perimeter(){
		cout << "[Triangle] : perimeter " << endl;
		float l1 = sqrt((float)((v1.getX() - v2.getX()) * (v1.getX() - v2.getX()) + (v1.getY() - v2.getY()) *  (v1.getY() - v2.getY())));
		float l2 = sqrt((float)((v1.getX() - v3.getX()) * (v1.getX() - v3.getX()) + (v1.getY() - v3.getY()) *  (v1.getY() - v3.getY())));
		float l3 = sqrt((float)((v3.getX() - v2.getX()) * (v3.getX() - v2.getX()) + (v3.getY() - v2.getY()) *  (v3.getY() - v2.getY())));
		return l1 + l2 + l3;
	}
};
#endif