#include <iostream>
using namespace std;

class Person{
protected:
	char* name;
public:
	Person(){
		name = NULL;
	}
	Person(char* s){
		name = new char[strlen(s) + 1];
		strcpy_s(name, strlen(s) + 1, s);
	}
	Person(const Person &p){
		name = new char[strlen(p.name) + 1];
		strcpy_s(name, strlen(p.name) + 1, p.name);
	}
	virtual ~Person(){
		cout << "[Person] :: destructor ... " << endl;
		if (name){
			delete[] name;
			name = NULL;
		}
	}
	char* getName(){
		return name;
	}
	friend ostream& operator<<(ostream &os, Person &p){
		os << p.name;
		return os;
	}
};

class Student : public Person{
private:
	char* faculty;
public:
	Student() : Person(){
		faculty = NULL;
	}
	Student(char* s, char* f) : Person(s){
		faculty = new char[strlen(f) + 1];
		strcpy_s(faculty, strlen(f) + 1, f);
	}
	Student(const Student &s){
		faculty = new char[strlen(s.faculty) + 1];
		strcpy_s(faculty, strlen(s.faculty) + 1, s.faculty);
	}
	~Student(){
		cout << "[Student] :: destructor ... " << endl;
		if (faculty){
			delete[] faculty;
			faculty = NULL;
		}
	}
	char* getFaculty(){
		return faculty;
	}
	friend ostream& operator<<(ostream &os, Student &s){
		os << s.name << "-" << s.faculty;
		return os;
	}
};

void createDestroy(){
	Person* p[3];
	p[0] = new Person("John");
	p[1] = new Student("Mary", "Design");
	p[2] = new Person("George");
	//..........

	for (int i = 0; i < 3; i++)
		delete p[i];
}

void objectSliceing(){
	Person p("John");
	Student s("Mary", "Design");
	cout << p << endl;	//John
	cout << s << endl;	//Mary-Design

	Person* pp = new Person("John");
	Student* sp = new Student("Mary", "Design");
	cout << *pp << endl;	//John
	cout << *sp << endl;    //Mary-Design

	Person* ps = new Student("Anna", "History");
	cout << *ps << endl;	//Anna
}

int main(){
	createDestroy();
	objectSliceing();
	return 0;
}