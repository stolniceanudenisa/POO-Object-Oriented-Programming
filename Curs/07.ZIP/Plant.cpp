#include "Plant.h"
#include <cstring>
#include <stdlib.h>
using namespace std;

/*
Descr:	constructor
In:		-
Out:	an instance of Plant
*/
Plant::Plant(){
	cout << "[Plant] : default constructor " << endl;
	name = NULL;
}

/*
Descr:	constructor
In:		a name (string)
Out:	an instance of Plant (with name)
*/
Plant::Plant(char* n){
	cout << "[Plant] : general constructor " << endl;
	name = new char[strlen(n) + 1];
	strcpy_s(name, strlen(n) + 1, n);
}

/*
Descr:	copy constructor
In:		a plant p
Out:	an instance of Plant (with info from p)
*/
Plant::Plant(const Plant &p){
	cout << "[Plant] : copy constructor " << endl;
	name = new char[strlen(p.name) + 1];
	strcpy_s(name, strlen(p.name) + 1, p.name);
}

/*
Descr:	destructor
In:		crt instance of Plant
Out:	-
*/
Plant::~Plant(){
	cout << "[Plant] : destructor of plant " << name << endl;
	if (name){
		delete[] name;
		name = NULL;
	}
}

/*
Descr:	setter
In:		crt instance of Plant, a name (string)
Out:	crt plant (with changed name)
*/
void Plant::setName(char* n){
	cout << "[Plant] : setName " << endl;
	if (name)
		delete[] name;
	name = new char[strlen(n) + 1];
	strcpy_s(name, strlen(n) + 1, n);
}

/*
Descr:	getter
In:		crt instance of Plant
Out:	the name of crt plant
*/
char* Plant::getName(){
	cout << "[Plant] : getName " << endl;
	return name;
}
/*
Descr:	conversion to string
In:		crt instance of Plant
Out:	a string associated to info about the crt plant
*/
char* Plant::toString(){
	cout << "[Plant] : toString " << endl;
	char* s = new char[strlen(name) + 1];
	strcpy_s(s, strlen(name) + 1, name);
	return s;
	return th
}
