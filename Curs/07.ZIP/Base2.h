#ifndef BASE2_H
#define BASE2_H

#include <iostream>
using namespace std;

class Base2{
protected:
	int data;
public:
	/*
	Descr:	constructor
	In:		 -
	Out:	an instance of Base2
	*/
	Base2(){
		cout << "[Base2] : default constructor " << endl;	
		data = 0;
	}
	/*
	Descr:	constructor with param
	an:		3 number
	Out:	an instance of Base2 (with useful info)
	*/
	Base2(int d){
		cout << "[Base2] : general constructor " << endl;
		data = d;
	}
	//Base2(int d): data(d){}

	/*
	Descr:	copy constructor
	In:		an object b of type Base2
	Out:	a new instance of Base2 containing info from b
	*/
	Base2(const Base2 &b){
		cout << "[Base2] : copy constructor " << endl;
		this->data = b.data;
	}
	
	/*
	Descr:	destructor
	In:		an instance of Base2
	Out:	-
	*/
	~Base2(){
		cout << "[Base2] : destructor " << endl;
	}
	
	/*
	Descr:	assignment operator
	In:		the crt instance of Base2 and an object b of type Base2
	Out:	the crt instance of Base2 (with info from b)
	*/
	Base2& operator=(const Base2 &b){
		cout << "[Base2] : operator= " << endl;
		if (this != &b){
			this->data = b.data;
		}
		return *this;
	}

	/*
	Descr:	setter
	In:		the crt instance of Base and a number
	Out:	the changed instance of Base
	*/
	void setData(int d){
		data = d;
	}
	
	/*
	Descr:	getter
	In:		the crt instance of Base2
	Out:	the value of an attribute of crt Base2 instance
	*/
	int getData(){
		return data;
	}
	/*
	Descr:	convert a Base2 into a string
	In:		crt Base2 instance
	Out:	a string with info about the crt Base2 instance
	*/
	char* toString(){
		char* aux = new char[6];
		_itoa_s(data, aux, 6, 10);
		return aux;
	}

	/*
	Descr:	convert a Base2 into a string
	In:		crt Base2 instance
	Out:	a string with info about the crt Base2 instance
	*/
	char* anotherToString(){
		int len = strlen("a Base2 object: ") + 6;
		char* s = new char[len];	//5 chars for digits of data and another char for \0
		strcpy_s(s, len, "a Base2 object: ");
		char* aux = new char[6];
		_itoa_s(data, aux, 6, 10);
		strcat_s(s, len, aux);
		return s;
	}

	/*
	Descr:	IO operator
	In:		an output stream and an object of type Base2
	Out:	the output stream
	*/
	friend ostream& operator<<(ostream& os, Base2 &b){
		os << " base2 object is " << b.data << endl;
		return os;
	}
};
#endif