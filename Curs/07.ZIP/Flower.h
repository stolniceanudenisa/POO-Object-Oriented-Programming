#ifndef FLOWER_H
#define FLOWER_H

#include "Plant.h"

class Flower : public Plant{
private:
	int noPetals;
public:
	Flower();
	Flower(char*, int);
	Flower(const Flower &);
	~Flower();
	void setNoPetals(int);
	int getNoPetals();
	char* toString();
};
#endif