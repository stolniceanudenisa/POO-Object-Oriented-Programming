#include "Flower.h"
#include <cstring>
#include <stdlib.h>
using namespace std;
/*
Descr:	constructor
In:		-
Out:	an instance of Flower
*/
Flower::Flower():Plant(){
	cout << "[Flower] : default constructor " << endl;
	noPetals = 0;
}

Flower::Flower(char* n, int np):Plant(n){
	cout << "[Flower] : general constructor " << endl;
	noPetals = np;
}

/*
Descr:	constructor
In:		a name (string) and a no of petals (integer)
Out:	an instance of Flower
*/
//Flower::Flower(char* n, int np):Plant(n),noPetals(np){
//	cout << "[Flower] : general constructor " << endl;
//}

/*
Descr:	copy constructor
In:		a flower f
Out:	an instance of Flower (with info from f)
*/
Flower::Flower(const Flower &f) : Plant(f){
	cout << "[Flower] : copy constructor " << endl;
	noPetals = f.noPetals;
}

/*
Descr:	destructor
In:		crt instance of Flower
Out:	-
*/
Flower::~Flower(){
	cout << "[Flower] : destructor of flower " << name << endl;
}

/*
Descr:	setter
In:		crt flower, a no of petals (integer)
Out:	crt flower (with changed no of petals)
*/
void Flower::setNoPetals(int n){
	cout << "[Flower] : set no petals " << endl;
	noPetals = n;
}

/*
Descr:	getter
In:		crt flower
Out:	no of petals (integer) of crt flower
*/
int Flower::getNoPetals(){
	cout << "[Flower] : get no petals " << endl;
	return noPetals;
}

/*
Descr:	conversion to string
In:		crt flower
Out:	a string with info about crt flower
*/
char* Flower::toString(){
	cout << "[Flower] : toString " << endl;
	int len = strlen(this->name) + 1 + 5 + 1;
	char* s = new char[len];
	strcpy_s(s, len, name);	//this->name from Plant
	char* aux = new char[5];
	_itoa_s(this->noPetals, aux, 5, 10);	//this->noPetals from Flower
	strcat_s(s, len, " ");
	strcat_s(s, len, aux);
	delete[] aux;
	return s;
}
