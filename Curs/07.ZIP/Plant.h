#ifndef PLANT_H
#define PLANT_H

#include <iostream>
#include <stdlib.h>
#include <string>
using namespace std;

class Plant{
private:
	char* name;
public:
	Plant();
	Plant(char*);
	Plant(const Plant &p);
	~Plant();
	void setName(char*);
	char* getName();
	char* toString();
};
#endif
