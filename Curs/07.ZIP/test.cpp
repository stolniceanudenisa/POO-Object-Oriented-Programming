#include "Derived.h"

typedef void (Base2::*ptrFunc)(int);

typedef char* (Base2::*PointerFunc)();

void inheritedData(){
	Base2 b(5);
	int x = b.getData();	//getData from class Base2
	cout << "in class Base2, data = " << x << endl;
	Derived d(1, 2, 3, 4, 5);
	x = d.getData() ;	//getData from class Derived
	cout << "in class Derived, data = " << x << endl;
}

void inheritedMethods(){
	Base b1(1,2,3);
	b1.func1();
	b1.func2();
	b1.func3();

	Derived d1(5,6,7,8,9);
	d1.func1();	//func1 from Base class
	d1.func2();	//redefined func2 from Derived class
	d1.func3(9);//overrriden func3 from Derived class

	Base b2;
	b2 = b1;

	Derived d2;
	d2 = d1;

	Base2 b3(5);
	cout << b3;

	Derived d3(1,2,3,4,5);
	cout << d3;
}

void functionWithBaseParam(Base &b){
	cout << "function that accept either a base object or an inherited object " << endl;
}

void functionWithDerivedParam(Derived &d){
	cout << "function that accept only an inherited object " << endl;
}

void objectConversions(){
	Base b;
	Derived d;
	functionWithBaseParam(b);
	functionWithBaseParam(d);

	functionWithDerivedParam(d);
	//functionWithDerivedParam(b);	//error: " cannot convert parameter 1 from 'Base' to 'Derived &'"
}

void functionWithBasePointerParam(Base* b){
	cout << "function that accept either a pointer to a base object or to an inherited object " << endl;
}

void functionWithDerivedPointerParam(Derived* d){
	cout << "function that accept only a pointer to an inherited object " << endl;
}

void objectPointerConversions(){
	Base* bp = new Base(1,2,3);
	Derived* dp = new Derived(1,2,3,4,5);
	
	functionWithBasePointerParam(bp);
	functionWithBasePointerParam(dp);

	functionWithDerivedPointerParam(dp);
	//functionWithDerivedPointerParam(bp);	//error : "cannot convert parameter 1 from 'Base *' to 'Derived *'"
	
	if (dp){
		delete dp;
		dp = NULL;
	}
	if (bp){
		delete bp;
		bp = NULL;
	}
}

void pointerToMethods(){

	PointerFunc pf1 = &Base2::toString;
	PointerFunc pf2 = &Base2::anotherToString;
	
	Base2 b(5);
	char* s = (b.*pf1)();
	cout << s << endl;
	if (s){		delete[] s;		s = NULL;	}
	s = (b.*pf2)();
	cout << s << endl;
	if (s){		delete[] s;		s = NULL;	}

	Derived d(1,2,3,4,5);
	s = (d.*pf2)();	//toString from Base2 class
	cout << s << endl;
	if (s){		delete[] s;		s = NULL;	}

	//PointerFunc pf3 = &Derived::toString;	//error : cannot convert from 'char *(__thiscall Derived::* )(void)' to 'PointerFunc'
	//s = (d.*pf3)();	//toString from Base2 class

}

int main(){
	inheritedData();
	inheritedMethods();
	objectConversions();
	objectPointerConversions();
	pointerToMethods();
	return 0;
}