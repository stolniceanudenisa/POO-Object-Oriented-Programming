#ifndef DERIVED_H
#define DERIVED_H

#include "Base.h"
#include "Base2.h"

class Derived : public Base, public Base2{
private:
	int newData;
	int data;
public:
	/*
	Descr:	constructor
	In:		 -
	Out: an instance of Derived
	*/
	Derived():Base(), Base2(){
		cout << "[Derived] : default constructor " << endl;	
		newData = 0;
		data = 10;
	}
	/*
	Descr:	constructor
	In:		5 numbers (3 for Base, 1 for Base2, 1 for Derived)
	Out:	an instance of Derived
	*/
	Derived(int d1, int d2, int d3, int d4, int d5):Base(d1, d2, d3), Base2(d4){
		cout << "[Derived] : general constructor " << endl;
		newData = d5;
		data = 10;
	}
	/*
	Descr:	copy constructor
	In:		an object d of type Derived
	Out:	an instance of Derived (with info from d)
	*/
	Derived(const Derived& d):Base(d), Base2(d){
		cout << "[Derived] : copy constructor " << endl;
		newData = d.newData;
		data = d.data;
	}

	/*
	Descr:	destructor
	In:		crt instance of Derived
	Out:	-
	*/
	~Derived(){
		cout << "[Derived] : destructor " << endl;
	}

	/*
	Descr:	assignment operator
	In:		the crt instance of Derived and an object d of type Derived
	Out:	the crt instance of Derived (with info from d)
	*/
	Derived& operator=(const Derived &d){
		cout << "[Derived] : operator= " << endl;
		if (this != &d){			
			Base::operator=(d);
			Base2::operator =(d);
			this->newData = d.newData;
			this->data = d.data;
		}
		return *this;
	}

	/*
	Descr:	setter
	In:		the crt instance of Derived and a number
	Out:	the changed instance of Derived
	*/
	void setNewData(int d){
		newData = d;
	}

	/*
	Descr:	getter
	In:		the crt instance of Derived
	Out:	the value of an attribute of crt Derived instance
	*/
	int getNewData(){
		return newData;
	}

	/*
	Descr:	setter
	In:		the crt instance of Derived and a number
	Out:	the changed instance of Derived
	*/
	void setData(int d){
		data = d;
	}

	/*
	Descr:	getter
	In:		the crt instance of Derived
	Out:	the value of an attribute of crt Derived instance
	*/
	int getData(){
		return data;
	}

	/*
	Descr:	converter to string
	In:		the crt instance of Derived
	Out:	the string associated to info from crt Derived instance
	*/
	char* toString(){
		int len = 5 * 6 + 5;
		char* s = new char[len];
		char* aux = new char[6];
		_itoa_s(publicData, aux, 6, 10);
		strcpy_s(s, len, aux);
		strcat_s(s, len, " ");
		_itoa_s(protectedData, aux, 6, 10);
		strcat_s(s, len, aux);
		strcat_s(s, len, " ");
		_itoa_s(getPrivateData(), aux, 6, 10);
		strcat_s(s, len, aux);
		strcat_s(s, len, " ");
		_itoa_s(data, aux, 6, 10);	//data is from Derived class
		strcpy_s(s, len, aux);
		strcat_s(s, len, " ");
		_itoa_s(newData, aux, 6, 10);
		strcat_s(s, len, aux);
		delete[] aux;
		return s;
	}

	/*
	Descr:	just a simple exameple
	In:		the crt instance of Base
	Out:	-
	*/
	void func2(){	//redefined method
		cout << "func2 from Base was redefined for data : " << publicData << ", ";
		cout << protectedData << ", ";
		//cout << privateData << ", ";	//error: "cannot access private member declared in class 'Base'"
		cout << newData << endl;
	}

	/*
	Descr:	just a simple exameple
	In:		the crt instance of Base
	Out:	-
	*/
	void func3(int x){	//overridden method
		cout << "func3 from Base was overridden for data : " << publicData << ", ";
		cout << protectedData << ", ";
		//cout << privateData << ", ";	//error: "cannot access private member declared in class 'Base'"
		cout << newData << ", ";
		cout << x << endl;
	}
};
#endif