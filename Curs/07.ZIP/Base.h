#ifndef BASE_H
#define BASE_H

#include <iostream>
using namespace std;

class Base{
public:
	int publicData;
protected:
	int protectedData;
private:
	int privateData;

public:
	/*
	Descr:	constructor
	In:		 -
	Out: an instance of Base
	*/
	Base(){
		cout << "[Base] : default constructor " << endl;	
		this->publicData = 0;
		this->protectedData = 0;
		this->privateData = 0;
	}
	/*
	Descr:	constructor with params
	In:		3 numbers
	Out:	an instance of Base (with useful info)
	*/
	Base(int d1, int d2, int d3){
		cout << "[Base] : general constructor " << endl;
		this->publicData = d1;
		this->protectedData = d2;
		this->privateData = d3;
	}
	//Base(int d1, int d2, int d3): publicData(d1), protectedData(d2), privateData(d3){}
	
	/*
	Descr:	copy constructor
	In:		an object b of type Base
	Out:	a new instance of Base containing info from b
	*/
	Base(const Base &b){
		cout << "[Base] : copy constructor " << endl;
		this->publicData = b.publicData;
		this->protectedData = b.protectedData;
		this->privateData = b.privateData;
	}
	/*
	Descr:	destructor
	In:		an instance of Base
	Out:	-
	*/
	~Base(){
		cout << "[Base] : destructor " << endl;
	}

	/*
	Descr:	assignment operator
	In:		the crt instance of Base and an object b of type Base
	Out:	the crt instance of Base (with info from b)
	*/
	Base& operator=(const Base &b){
		cout << "[Base] : operator= " << endl;
		if (this != &b){
			this->publicData = b.publicData;
			this->protectedData = b.protectedData;
			this->privateData = b.privateData;
		}
		return *this;
	}
	
	/*
	Descr:	setter
	In:		the crt instance of Base and a number
	Out:	the changed instance of Base
	*/
	void setPtrotectedData(int d){
		protectedData = d;
	}
	
	/*
	Descr:	setter
	In:		the crt instance of Base and a number
	Out:	the changed instance of Base
	*/
	void setPrivateData(int d){
		privateData = d;
	}
	
	/*
	Descr:	getter
	In:		the crt instance of Base
	Out:	the value of an attribute of crt Base instance
	*/
	int getProtectedData(){
		return protectedData;
	}

	/*
	Descr:	getter
	In:		the crt instance of Base
	Out:	the value of an attribute of crt Base instance
	*/
	int getPrivateData(){
		return privateData;
	}

	/*
	Descr:	just a simple exameple
	In:		the crt instance of Base
	Out:	-
	*/
	void func1(){
		cout << "simple func1 for data : " << this->publicData << ", " <<
			this->protectedData << ", " << this->privateData << endl;
	}
	/*
	Descr:	just a simple exameple
	In:		the crt instance of Base
	Out:	-
	*/
	void func2(){
		cout << "simple func2 for data : " << this->publicData << ", " <<
			this->protectedData << ", " << this->privateData << endl;
	}
	/*
	Descr:	just a simple exameple
	In:		the crt instance of Base
	Out:	-
	*/
	void func3(){
		cout << "simple func3 for data : " << this->publicData << ", " <<
			this->protectedData << ", " << this->privateData << endl;
	}
};
#endif