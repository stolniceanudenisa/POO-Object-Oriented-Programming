#include "tests.h"
#include "UI.h"

#include <cstdio>
#include "Floare.h"
#include "parseConfig.h"

using namespace rapidjson;

int main(){
    // testeFloare();
    // testComanda();
    // testFlorarie();

    RepositoryFile<Floare>* repoFlori;
    RepositoryFile<Comanda>* repoComenzi;
    try{
        readConfigFile("D:\\_Work\\School\\_2020-2021\\sem2\\POO\\lectures\\codeExamples\\florarie\\v2\\config.json", 
        repoFlori, repoComenzi);
        
        Florarie* florarie = new Florarie(repoFlori, repoComenzi);
        UI console(florarie);
        console.run();
    }
    catch(MyException &ex){
        cout << "some pb: " << ex.getMessage() << endl;
    }
    catch(...){
        cout << " other problems..." << endl;
    }


    return 0;
}