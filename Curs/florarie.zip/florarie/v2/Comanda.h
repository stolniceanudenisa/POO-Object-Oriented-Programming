#pragma once
#include "Floare.h"

class Comanda{
    // vector<Floare> flori;
    vector<int> flori;
    string adresa;
    int cost;
    bool onorata;
public:
    Comanda(vector<int> v, string a, int c, bool o):flori(v), adresa(a), cost(c), onorata(o){}
    
    Comanda(const Comanda &c):flori(c.flori), adresa(c.adresa), cost(c.cost), onorata(c.onorata){}
    
    Comanda(string args, char sep){
        this->loadFromString(args, sep);
    }
    ~Comanda(){}
    Comanda& operator=(const Comanda &c){
        this->flori = c.flori;
        this->adresa = c.adresa;
        this->cost = c.cost;
        this->onorata = c.onorata;
        return *this;
    }

    void loadFromString(string args, char sep){
        vector<string> elements = split(args, sep);
        int noFlori;
        stringstream nf(elements[0]);
        nf >> noFlori;
        int k = 0;
        for(int i = 0; i < noFlori; i++){
            k++;
            int id;
            stringstream no(elements[k]); 
            no >> id;
            this->flori.push_back(id);
        }
        k++;
        this->adresa = elements[k];
        k++;
        stringstream total(elements[k]);
        total >> this->cost;
        k++;
        stringstream onor(elements[k]);
        onor >> this->onorata;
    }

    string toStringDelimiter(char sep){
        string s;
        s = to_string(this->flori.size()) + sep;
        for(int f : this->flori){
            s += to_string(f) + sep;
        }
        s += this->adresa + sep + to_string(this->cost) + sep + to_string(this->onorata);
        return s;
    }

};


{
    vector<Carte> v;
    // v.reserve(3);

    Carte c1("Beloved",2015);
    Carte c2("Jazz", 2016);
    Carte c3("Quarantine", 2014);

    v.push_back(c1);
    v.push_back(c2);
    v.push_back(c3);
}

Complex& Complex::add(Complex c){
    this->real += c.real;
    this->img += c.img;
    return *this;
}