#pragma once

#include <string>
#include <vector>
#include "utils.h"
#include "MyException.h"

using namespace std;

class Floare{
    int id;
    string specie;
    int cantitate;
    int costUnitar;
public:
    Floare(){}
    Floare(int i, string s, int c, int cu):id(i),specie(s),cantitate(c),costUnitar(cu){}
    Floare(const Floare &f){
        this->id = f.id;
        this->specie = f.specie;
        this->cantitate = f.cantitate;
        this->costUnitar = f.costUnitar;
    }
    Floare(string args, char sep){
        this->loadFromString(args, sep);
    }
    ~Floare(){}
    Floare& operator=(const Floare &f){
        this->id = f.id;
        this->specie = f.specie;
        this->cantitate = f.cantitate;
        this->costUnitar = f.costUnitar;
        return *this;
    }
    void loadFromString(string args, char sep){
        vector<string> elements = split(args, sep);
        if (elements.size() == 4){
            stringstream i(elements[0]); 
            i >> this->id;
            this->specie = elements[1];
            stringstream c(elements[2]); 
            c >> this->cantitate;
            stringstream cu(elements[3]); 
            cu >> this->costUnitar;
        }
        else{
            throw MyException("nr invalid de argumente in stringul ce tb parsat");
        }
    }
    string toStringDelimiter(char sep){
        return to_string(this->id) + sep + this->specie + sep + to_string(this->cantitate) +         sep + to_string(this->costUnitar);
    }
    void setCant(int c){
        this->cantitate = c;
    }
    int getCostUnitar(){
        return this->costUnitar;
    }
    string getSpecie(){
        return this->specie;
    }
    int getID(){
        return this->id;
    }
    bool operator==(const Floare &f){
        return this->specie == f.specie;
    }
};