// see https://rapidjson.org/index.html

#include "rapidjson/filereadstream.h"
#include "rapidjson/document.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/prettywriter.h"
#include <string.h>

#include "RepositoryFileTXT.h"
#include "RepositoryFileCSV.h"
#include "Floare.h"
#include "Comanda.h"

#include <iostream>
using namespace rapidjson;

void readConfigFile(char* configFileName, RepositoryFile<Floare>* &repoFlori, RepositoryFile<Comanda>* &repoComenzi){
    FILE* fp = fopen(configFileName, "rb");
    char readBuffer[65536];
    FileReadStream is(fp, readBuffer, sizeof(readBuffer));
    
    Document d;
    d.ParseStream(is);

    std::cout << d["fileType"].GetString() << endl;
    int val = d["no"].GetInt();

    if (strcmp(d["fileType"].GetString(), "TXT") == 0){
        repoFlori = new RepositoryFileTXT<Floare>(d["floriFileName"].GetString());
        repoComenzi = new RepositoryFileTXT<Comanda>(d["comenziFileName"].GetString());
    }
    else{
        if (strcmp(d["fileType"].GetString(), "CSV") == 0){
            repoFlori = new RepositoryFileCSV<Floare>(d["floriFileName"].GetString());
            repoComenzi = new RepositoryFileCSV<Comanda>(d["comenziFileName"].GetString());
        }
        else{
            //...
        }
    }

    fclose(fp);
}