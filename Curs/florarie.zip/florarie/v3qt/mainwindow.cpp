#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "RepositoryFileTXT.h"

#include <QStringList>
#include <QStringListModel>
#include <QAbstractItemView>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    RepositoryFile<Floare>* repoFlori = new RepositoryFileTXT<Floare>("D:\\_Work\\School\\_2019-2020\\sem2\\POO\\codeEx\\testFlorarie\\flori.txt");
    RepositoryFile<Comanda>* repoComenzi = new RepositoryFileTXT<Comanda>("D:\\_Work\\School\\_2019-2020\\sem2\\POO\\codeEx\\testFlorarie\\comenzi.txt");
    this->florarie = new Florarie(repoFlori, repoComenzi);

    // create a "global" model for commands
    this->modelComenzi = new QStringListModel(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_seeFlowers_clicked()
{
    // Create model
    QStringListModel* model = new QStringListModel(this);

    // Make data
    QStringList List;
    vector<Floare> flori = this->florarie->getFlori();
    for(Floare f : flori){
        List << QString::fromStdString(f.toStringDelimiter(' '));
    }

    // Populate our model
    model->setStringList(List);

    // Glue model and view together
    this->ui->floriListView->setModel(model);

}

void MainWindow::on_commands_clicked()
{

    // Create a local model
    QStringListModel* model = new QStringListModel(this);

    // Make data
    QStringList List;
    vector<Comanda> comenzi = this->florarie->getComenzi();
    for(Comanda c : comenzi){
        List << QString::fromStdString(c.toStringDelimiter(' '));
    }

    // Populate our model
//    model->setStringList(List);
    modelComenzi->setStringList(List);

    // Glue model and view together
//    this->ui->comenziListView->setModel(model);
    this->ui->comenziListView->setModel(modelComenzi);

}

void MainWindow::on_buttonPlasareComanda_clicked()
{
    QString floareComandata = this->ui->textEditFloriDeComandat->toPlainText();
    QString adresaComanda = this->ui->textEditAdresaComenzii->toPlainText();
    vector<string> flori;
    flori.push_back(floareComandata.toStdString());
    vector<int> nrBucati;
    nrBucati.push_back(1);
    string adresa = adresaComanda.toStdString();
    this->florarie->addComanda(flori, nrBucati, adresa);

    QStringList List;
    vector<Comanda> comenzi = this->florarie->getComenzi();
    for(Comanda c : comenzi){
        List << QString::fromStdString(c.toStringDelimiter(' '));
    }

    // Populate our model
    modelComenzi->setStringList(List);

    QMessageBox *msgBox = new QMessageBox(0);
    msgBox->setText("Comanda plasata");
    msgBox->exec();
}
