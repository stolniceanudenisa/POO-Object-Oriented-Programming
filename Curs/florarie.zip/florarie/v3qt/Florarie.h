#pragma once
#ifndef FLORARIE_H
#define FLORARIE_H

#include "RepositoryFile.h"
#include "Comanda.h"

class Florarie{

    RepositoryFile<Comanda>* repoComenzi;
    RepositoryFile<Floare>* repoFlori;

public:
    Florarie(RepositoryFile<Floare>* r1, RepositoryFile<Comanda>* r2):
    repoFlori(r1), repoComenzi(r2){
        // this->repoFlori = r1;
    }
    ~Florarie(){}
    void addComanda(vector<string> numeFlori, vector<int> nrBucFlori, string adresa){
        vector<int> floriComandate;
        int costTotal = 0;
        for(int i = 0; i < numeFlori.size(); i++){
            string s = numeFlori[i];
            Floare faux(-1, s, -1, -1);
            Floare f = this->repoFlori->cauta(faux);
            // f.setCant(nrBucFlori[i]);
            costTotal += nrBucFlori[i] * f.getCostUnitar();
            floriComandate.push_back(f.getID());
        }
        Comanda c(floriComandate, adresa, costTotal, 0);
        this->repoComenzi->adauga(c);
    }
    vector<Comanda> getComenzi(){
        return this->repoComenzi->getAll();
    }

    vector<Floare> getFlori(){
        return this->repoFlori->getAll();
    }

};

#endif
