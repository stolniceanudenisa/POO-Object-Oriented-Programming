#pragma once

#include <string>
#include <vector>
#include <fstream>
#include "MyException.h"
using namespace std;

template <class T> 
class RepositoryFile
{

 protected:
	vector<T> elements;
	string fileName;
	
public:
	RepositoryFile(string);
	virtual void saveToFile() = 0;
	virtual void loadFromFile() = 0;
	~RepositoryFile();
	vector<T> getAll();
	T cauta(T el);
	void adauga(T el);
	T cauta(int id);
};


template<class T>
RepositoryFile<T>::RepositoryFile(string name)
{
	this->fileName = name;
}

template<class T>
RepositoryFile<T>::~RepositoryFile()
{
}


template <class T>
vector<T> RepositoryFile<T>::getAll(){
	return this->elements;
}

template <class T>
T RepositoryFile<T>::cauta(T el){
	for(T elCrt : this->elements){
		if (elCrt == el){
			return elCrt;
		}
	}
	throw MyException("searched elem was not found!");
}

template <class T>
T RepositoryFile<T>::cauta(int id){
	for(T elCrt : this->elements){
		if (elCrt.getID() == id){
			return elCrt;
		}
	}
	throw MyException("searched elem was not found!");
}

template <class T>
void RepositoryFile<T>::adauga(T el){
	this->elements.push_back(el);
	this->saveToFile();
}