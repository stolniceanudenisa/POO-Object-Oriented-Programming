#pragma once
#include "RepositoryFile.h"

template <class T> class 
RepositoryFileTXT : public RepositoryFile<T>
{


public:
	RepositoryFileTXT(string);
	void saveToFile();
	void loadFromFile();
	~RepositoryFileTXT();
};


template<class T>
RepositoryFileTXT<T>::RepositoryFileTXT(string name):RepositoryFile<T>(name){
	this->loadFromFile();
}

template<class T>
RepositoryFileTXT<T>::~RepositoryFileTXT()
{
}

template<class T>
void RepositoryFileTXT<T>::saveToFile()
{
	
	ofstream f(this->fileName);
	for (T crt : this->elements) {
		f << crt.toStringDelimiter(' ') << endl;
	}
	f.close();
}

template<class T>
void RepositoryFileTXT<T>::loadFromFile()
{
	string line;
	ifstream f(this->fileName);
	while (std::getline(f, line)) {
		try{
			T ob(line, ' ');
			this->elements.push_back(ob);
		}
		catch(exception ex){
			// cout << "some pb: " + ex.what() << endl;
			
			throw ex;
		}
	}

}