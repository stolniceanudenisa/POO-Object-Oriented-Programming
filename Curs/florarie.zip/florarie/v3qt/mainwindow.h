#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "Florarie.h"
#include <QStringListModel>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_seeFlowers_clicked();

    void on_commands_clicked();

//    void on_butonulMeu_clicked();

//    void on_buttonPlasareComanda_clicked();

    void on_buttonPlasareComanda_clicked();

private:
    Ui::MainWindow *ui;
    Florarie* florarie;
    QStringListModel* modelComenzi;

};

#endif // MAINWINDOW_H
