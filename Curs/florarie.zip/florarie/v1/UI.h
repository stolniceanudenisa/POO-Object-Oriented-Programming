#pragma once
#include "Florarie.h"
#include <iostream>
using namespace std;

class UI{
    Florarie* florarie;
public:
    UI(Florarie* f){
        this->florarie = f;
    }
    ~UI(){}
    void run(){
        // print all flowers
        cout << "---- FLORI ---" << endl;
        vector<Floare> flori = this->florarie->getFlori();
        for(Floare f : flori){
            cout << f.toStringDelimiter('-') << endl;
        }
        // print all commands
        cout << "---- COMENZI ---" << endl;
        vector<Comanda> comenzi = this->florarie->getComenzi();
        for(Comanda c : comenzi){
            cout << c.toStringDelimiter(';') << endl;
        }
        // add a new cmd
        try{
            int nrFlori = 0; cout << "Nr flori comandate: "; cin >> nrFlori;
            vector<string> numeFlori;
            vector<int> nrBucFlori;
            for(int i = 0; i < nrFlori; i++){
                string nume; cout << "nume floare: "; cin >> nume; numeFlori.push_back(nume);
                int nr; cout << "nr fire: "; cin >> nr; nrBucFlori.push_back(nr);
            }
            string adresa; cout << "adresa: "; cin >> adresa;
            this->florarie->addComanda(numeFlori, nrBucFlori, adresa);
        }
        catch(...){

        }
        // prin all commands
        cout << "---- COMENZI ---" << endl;
        comenzi = this->florarie->getComenzi();
        for(Comanda c : comenzi){
            cout << c.toStringDelimiter(';');
        }
    }
};