#pragma once

#include <string>
#include <vector>
#include "utils.h"
#include "MyException.h"

using namespace std;

class Floare{
    string specie;
    int cantitate;
    int costUnitar;
public:
    Floare(){}
    Floare(string s, int c, int cu):specie(s),cantitate(c),costUnitar(cu){}
    Floare(const Floare &f){
        this->specie = f.specie;
        this->cantitate = f.cantitate;
        this->costUnitar = f.costUnitar;
    }
    Floare(string args, char sep){
        this->loadFromString(args, sep);
    }
    ~Floare(){}
    Floare& operator=(const Floare &f){
        this->specie = f.specie;
        this->cantitate = f.cantitate;
        this->costUnitar = f.costUnitar;
        return *this;
    }
    void loadFromString(string args, char sep){
        vector<string> elements = split(args, sep);
        if (elements.size() == 3){
            this->specie = elements[0];
            stringstream c(elements[1]); 
            c >> this->cantitate;
            stringstream cu(elements[2]); 
            cu >> this->costUnitar;
        }
        else{
            throw MyException("nr invalid de argumente in stringul ce tb parsat");
        }
    }
    string toStringDelimiter(char sep){
        return this->specie + sep + to_string(this->cantitate) + sep + to_string(this->costUnitar);
    }
    void setCant(int c){
        this->cantitate = c;
    }
    int getCostUnitar(){
        return this->costUnitar;
    }
    string getSpecie(){
        return this->specie;
    }
    bool operator==(const Floare &f){
        return this->specie == f.specie;
    }
};