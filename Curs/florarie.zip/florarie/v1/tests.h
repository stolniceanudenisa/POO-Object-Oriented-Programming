#include "Floare.h"
#include "Comanda.h"
#include "RepositoryFileTXT.h"
#include "RepositoryFileCSV.h"
#include "Florarie.h"
#include "assert.h"
#include <iostream>

using namespace std;


void testeFloareSimplu(){
    RepositoryFileTXT<Floare> repo = RepositoryFileTXT<Floare>("flori.txt");
    vector<Floare> flori = repo.getAll();
    assert (flori.size() == 4);
    // cout << flori[0].toStringDelimiter(' ');
    assert (flori[0].toStringDelimiter(' ') == "lalea 10 2");
    Floare f = flori[0];
    assert (f.getSpecie() == "lalea");
    assert (f.getCostUnitar() == 2);
}


void testeFloare(){
    RepositoryFile<Floare>* repo = new RepositoryFileTXT<Floare>("D:\\_Work\\School\\_2020-2021\\sem2\\POO\\lectures\\codeExamples\\florarie\\v1\\flori.txt");
    vector<Floare> flori = repo->getAll();
    assert (flori.size() == 5);
    cout << flori[0].toStringDelimiter(' ');
    assert (flori[0].toStringDelimiter(' ') == "lalea 10 2");
    Floare f = flori[0];
    assert (f.getSpecie() == "lalea");
    assert (f.getCostUnitar() == 2);
}

 void testeFloareCSV(){
    RepositoryFile<Floare>* repo = new RepositoryFileCSV<Floare>("flori.csv");
    vector<Floare> flori = repo->getAll();
    assert (flori.size() == 2);
    cout << flori[0].toStringDelimiter('-');
}

void testComanda(){
    RepositoryFile<Comanda>* repo = new RepositoryFileTXT<Comanda>("comenzi.txt");
    vector<Comanda> comenzi = repo->getAll();
    assert (comenzi.size() == 5);
    // cout << comenzi[0].toStringDelimiter(' ') << endl;
    // cout << comenzi[1].toStringDelimiter(' ') << endl;
    assert (comenzi[4].toStringDelimiter('-') == "1-lalea-3-2-adr-6-0");
}
//....pt cauta, pt adauga,...


void testFlorarie(){
    RepositoryFile<Floare>* repoFlori;
    repoFlori = new RepositoryFileTXT<Floare>("flori.txt");
    // repoFlori = new RepositoryFileCSV<Floare>("flori.csv");
    RepositoryFile<Comanda>* repoComenzi;
    repoComenzi = new RepositoryFileTXT<Comanda>("comenzi.txt");
    Florarie florarie(repoFlori, repoComenzi);
    assert (florarie.getComenzi().size() == 5);
    assert (florarie.getFlori().size() == 4);
    assert (florarie.getFlori()[0].getSpecie() == "lalea");
    assert (florarie.getFlori()[0].toStringDelimiter('-') == "lalea-10-2");
    
    vector<string> flori = {"narcisa", "zambila"};
    vector<int> nr = {5, 3};
    florarie.addComanda(flori, nr, "adresaNoua");
    assert (florarie.getComenzi().size() == 6);
    cout << florarie.getComenzi()[5].toStringDelimiter('-') << endl;
    // assert(...)
}
