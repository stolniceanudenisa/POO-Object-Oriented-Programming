#include "tests.h"
#include "UI.h"

#include <cstdio>
#include "Floare.h"

// using namespace rapidjson;


int main(){
    // testeFloare();
    // testComanda();
    // testFlorarie();

    RepositoryFile<Floare>* repoFlori;
    RepositoryFile<Comanda>* repoComenzi;
    string tip; //txt sau csv
    cin >> tip;

    try{
        if (tip == "txt"){
            repoFlori = new RepositoryFileTXT<Floare>("D:\\_Work\\School\\_2020-2021\\sem2\\POO\\lectures\\codeExamples\\florarie\\v1\\flori.txt");
            repoComenzi = new RepositoryFileTXT<Comanda>("D:\\_Work\\School\\_2020-2021\\sem2\\POO\\lectures\\codeExamples\\florarie\\v1\\comenzi.txt");
        }
        if (tip == "csv"){
            repoFlori = new RepositoryFileCSV<Floare>("D:\\_Work\\School\\_2020-2021\\sem2\\POO\\lectures\\codeExamples\\florarie\\v1\\flori.csv");
            repoComenzi = new RepositoryFileCSV<Comanda>("D:\\_Work\\School\\_2020-2021\\sem2\\POO\\lectures\\codeExamples\\florarie\\v1\\comenzi.csv");
        }
        // if (...)
        Florarie* florarie = new Florarie(repoFlori, repoComenzi);
        UI console(florarie);
        console.run();
    }
    catch(MyException &ex){
        cout << "some pb: " << ex.getMessage() << endl;
    }
    catch(...){
        cout << " other problems..." << endl;
    }


    return 0;
}