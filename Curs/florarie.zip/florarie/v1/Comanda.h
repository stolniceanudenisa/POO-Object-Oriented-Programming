#pragma once
#include "Floare.h"

class Comanda{
    vector<Floare> flori;
    string adresa;
    int cost;
    bool onorata;
public:
    Comanda(vector<Floare> v, string a, int c, bool o):flori(v), adresa(a), cost(c), onorata(o){}
    
    Comanda(const Comanda &c):flori(c.flori), adresa(c.adresa), cost(c.cost), onorata(c.onorata){}
    
    Comanda(string args, char sep){
        this->loadFromString(args, sep);
    }
    ~Comanda(){}
    Comanda& operator=(const Comanda &c){
        this->flori = c.flori;
        this->adresa = c.adresa;
        this->cost = c.cost;
        this->onorata = c.onorata;
        return *this;
    }

    void loadFromString(string args, char sep){
        vector<string> elements = split(args, sep);
        int noFlori;
        stringstream nf(elements[0]);
        nf >> noFlori;
        int k = 0;
        for(int i = 0; i < noFlori; i++){
            k++;
            string nume = elements[k];
            k++;
            int cant;
            stringstream c(elements[k]); 
            c >> cant;
            k++;
            int costUnit;
            stringstream cu(elements[k]); 
            cu >> costUnit;
            Floare f(nume, cant, costUnit);
            this->flori.push_back(f);
        }
        k++;
        this->adresa = elements[k];
        k++;
        stringstream total(elements[k]);
        total >> this->cost;
        k++;
        stringstream onor(elements[k]);
        onor >> this->onorata;
    }

    string toStringDelimiter(char sep){
        string s;
        s = to_string(this->flori.size()) + sep;
        for(Floare f : this->flori){
            s += f.toStringDelimiter(sep) + sep;
            // s += f.getSpecie() + sep;
            // s += to_string(f.getCant()) + sep;
            // s += to_string(f.getCostUnitar()) + sep;
        }
        s += this->adresa + sep + to_string(this->cost) + sep + to_string(this->onorata);
        return s;
    }

};