
template <class T> class MyClass{
};

class Flower{
};


template <Flower*> class MyClass2{
};

template <int (*funcPtr)(int, int)> class MyClass3{
};

int fc(int a, int b){
	return a + b;
}

Flower globalFlower;

void tempalteParameters(){
	MyClass<int> v1;						//predefined type
	MyClass<Flower> v2;						//user defined type
	MyClass<void> v4;						//void
	MyClass2<&globalFlower> v5;				//object address
	MyClass3<fc> v7;						//function
	MyClass<MyClass<int>> v8;				//another template
	MyClass<MyClass2<&globalFlower>> v9;	//another template
}

int main(){
	tempalteParameters();
	return 0;
}