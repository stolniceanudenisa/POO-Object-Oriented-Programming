#ifndef ORDEREDSEQUENCE_H
#define ORDEREDSEQUENCE_H

#include <stdlib.h>

template <class T, int (*compFunc)(T, T)> class OrderedSequence{
private:
	int size;
	T* elements;
public:
	OrderedSequence(int);
	OrderedSequence(const OrderedSequence<T, compFunc> &);
	~OrderedSequence();
	void insertElem(T);
	T getElem(int);
	void deleteElem(int);
	int getSize();
};

//Descr:	create an empty seq
//In:		a capacity
//Out:		an instance of type OrdSeq (without elements, but with prepared space)
template <class T, int (*compFunc)(T, T)> OrderedSequence<T, compFunc>::OrderedSequence(int c){
	this->size = 0;
	this->elements = new T[c];
}

//Descr:	create a seq (from another seq)
//In:		a seq
//Out:		an instance of type OrdSeq (with elements from the given seq)
template <class T, int (*compFunc)(T, T)> OrderedSequence<T, compFunc>::OrderedSequence(const OrderedSequence<T, compFunc> &os){
	this->size = os.size;
	this->elements = new T[os.size];
	for(int i = 0; i < this->size; i++)
		this->elements[i] = os.elements[i];
}

//Descr:	destroy a seq
//In:		a seq
//Out:		-
template <class T, int (*compFunc)(T, T)> OrderedSequence<T, compFunc>::~OrderedSequence(){
	if (elements){
		delete[] elements;
		elements = NULL;
	}
}

//Descr:	add an element into a seq
//In:		the seq and an elem
//Out:		the changed seq (with sorted elements)
template <class T, int (*compFunc)(T, T)> 
void OrderedSequence<T, compFunc>::insertElem(T el){
	int i = 0;
	while ((i < this->size) && (compFunc(elements[i], el) == -1))
		i++;
	for(int j = size; j > i; j--)
		this->elements[j] = this->elements[j - 1];
	this->size++;
	this->elements[i] = el;
}

//Descr:	access an elem from the seq
//In:		the seq and a position
//Out:		the element
template <class T, int (*compFunc)(T, T)> 
T OrderedSequence<T, compFunc>::getElem(int pos){
	return this->elements[pos];
}

//Descr:	eliminate an elem from a seq
//In:		a seq and a position
//Out:		the changed seq
template <class T, int (*compFunc)(T, T)> 
void OrderedSequence<T, compFunc>::deleteElem(int pos){
	for (int i = pos; i < this->size - 1; i++)
		this->elements[i] = this->elements[i + 1];
	this->size--;
}
//Descr:	access the size of a seq
//In:		a seq
//Out:		the seq's size
template <class T, int (*compFunc)(T, T)>
int OrderedSequence<T, compFunc>::getSize(){
	return this->size;
}

#endif