#include "OrderedSequence.h"
#include "Flower.h"
#include <iostream>
using namespace std;

int ascendingDouble(double a, double b){
	if (a < b) 
		return -1;
	if (a > b) 
		return 1;
	return 0;
}

int compareFlowers(Flower f1, Flower f2){
	if (f1.getNoPetals() < f2.getNoPetals())
		return -1;
	if (f1.getNoPetals() > f2.getNoPetals())
		return 1;
	return 0;
}

template <class T> int ascending(T a, T b){
	if (a < b) 
		return -1;
	if (a > b) 
		return 1;
	return 0;
}

int main(){
	OrderedSequence<double, ascendingDouble> os1(10);
	os1.insertElem(4.5);
	os1.insertElem(14.5);
	os1.insertElem(7.8);
	for(int i = 0; i < os1.getSize(); i++)
		cout << os1.getElem(i) << " ";
	cout << endl;

	OrderedSequence<Flower, compareFlowers> os2(10);
	os2.insertElem(Flower("tulip", 10));
	os2.insertElem(Flower("rose", 30));
	os2.insertElem(Flower("daisy", 20));
	for(int i = 0; i < os2.getSize(); i++)
		cout << os2.getElem(i) << " ";
	cout << endl;

	OrderedSequence<double, ascending<double>> os3(10);
	os3.insertElem(4.5);
	os3.insertElem(14.5);
	os3.insertElem(7.8);
	for(int i = 0; i < os3.getSize(); i++)
		cout << os3.getElem(i) << " ";
	cout << endl;

	OrderedSequence<Flower, ascending<Flower>> os4(10);
	os4.insertElem(Flower("tulip", 10));
	os4.insertElem(Flower("rose", 30));
	os4.insertElem(Flower("daisy", 20));
	for(int i = 0; i < os4.getSize(); i++)
		cout << os4.getElem(i) << " ";
	cout << endl;

	return 0;
}