#include <iostream>
using namespace std;
#include "Student.h"

int maxim(int a, int b){
	return (a > b ? a : b);
}
double maxim(double a, double b){
	return (a > b ? a : b);
}
Student& maxim(Student& s1, Student& s2){
	//return (s1.getGrade() > s2.getGrade() ? s1 : s2);
	return (s1 > s2 ? s1 : s2);
}
void mainMaxOverloaded(){
	int x = 5;
	int y = 8;
	int maxInt = maxim(x, y) ;
	cout << "integer maxim is " << maxInt << endl;
	
	double z = 9.5;
	double t = 12.24;
	double maxDouble = maxim(z, t);
	cout << "double maxim is " << maxDouble << endl;
	
	Student student1(10);
	Student student2(9);
	Student maxStudent = maxim(student1, student2);
	cout << "Student maxim is " << maxStudent << endl;
}

template <class T> T maxim(T a, T b){
	return (a > b ? a : b);
}

void mainMaxTemplate(){
	int x = 5;
	int y = 8;
	int maxInt = maxim<int>(x, y) ;
	cout << "integer maxim is " << maxInt << endl;
	
	double z = 9.5;
	double t = 12.24;
	double maxDouble = maxim<double>(z, t);
	cout << "double maxim is " << maxDouble << endl;
	
	Student student1(10);
	Student student2(9);
	Student maxStudent = maxim<Student>(student1, student2);
	cout << "Student maxim is " << maxStudent << endl;
}

int main(){
	mainMaxOverloaded();
	mainMaxTemplate();
	return 0;
}