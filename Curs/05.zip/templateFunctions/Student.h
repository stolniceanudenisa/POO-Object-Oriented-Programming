#ifndef STUDENT_H
#define STUDENT_H

class Student{
private:
	int grade;
public:
	Student(){
		grade = 0;
	}
	Student(int g){
		grade = g;
	}
	Student(const Student& s){
		grade = s.grade;
	}
	~Student(){}
	Student& operator=(const Student& s){
		if (this != &s)
			grade = s.grade;
		return *this;
	}
	int getGrade(){
		return grade;
	}
	bool operator>(const Student& s){
		return grade > s.grade;
	}
	friend ostream& operator<<(ostream &os, Student &s){
		os << "student's grade = " << s.grade << endl;
		return os;
	}
};
#endif