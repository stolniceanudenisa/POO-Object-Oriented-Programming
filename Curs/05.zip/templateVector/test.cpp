#include "Vector.h"
#include "Flower.h"


void vectorProcess(){
	Vector<int> v;
	int n;
	cout << "no of elem = "; 
	cin >> n;
	for(int i = 0; i < n; i++){
		int el;
		cin >> el;
		v.addElem(el);
	}
	for(int i = 0; i < v.getSize(); i++)
		cout << v.getElemPos(i) << " ";
	cout << endl;
}

template <class T, int CAP> 
void readVector(Vector<T, CAP> &v){
	int n;
	cout << "no of elem = "; 
	cin >> n;
	for(int i = 0; i < n; i++){
		cout << " elem[" << i + 1 << "] = ";
		T el;
		cin >> el;
		v.addElem(el);
	}
}

template <class T, int CAP> 
void printVector(Vector<T, CAP> &v){
	for(int i = 0; i < v.getSize(); i++)
		cout << v.getElemPos(i) << " ";
	cout << endl;
}

int main(){
		//vector with elements of type int
	// vectorProcess();
	cout << " process a vector of integers..." << endl;
	Vector<int, 10> v;
	readVector<int, 10>(v);
	printVector<int, 10>(v);	

		//vector with elements of type Flower
	cout << " process a vector of flowers..." << endl;
	Vector<Flower, 5> v2;
	readVector<Flower, 5>(v2);
	printVector<Flower, 5>(v2);	


	return 0;
}