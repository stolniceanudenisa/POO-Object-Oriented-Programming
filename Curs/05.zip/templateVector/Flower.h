#ifndef FLOWER_H
#define FLOWER_H

#include <iostream>
using namespace std;

class Flower{
private:
	char* name;
	int noPetals;
public:
	//Descr: create a flower 
	//In: -
	//Out: an empty instance of Flower
	Flower(){
		cout << "[Flower] : default constructor " << endl;
		this->name = NULL;
		this->noPetals = 0;
	}
	//Descr: create a flower
	//In: a name and a no of petals
	//Out: an instance (with info) of Flower
	Flower(char* n, int nP){
		cout << "[Flower] : constructor with params " << endl;
		this->name = new char[strlen(n) + 1];
		strcpy_s(this->name, strlen(n) + 1, n);
		this->noPetals = nP;
	}
	//Descr: create a flower using info from another flower
	//In: a flower f
	//Out: an instance of Flower with info from f
	Flower(const Flower& f){
		cout << "[Flower] : copy constructor " << endl;
		this->name = new char[strlen(f.name) + 1];
		strcpy_s(this->name, strlen(f.name) + 1, f.name);
		this->noPetals = f.noPetals;
	}
	//Descr: distroy a flower 
	//In: a flower 
	//Out: - (destructor)
	~Flower(){
		cout << "[Flower] : detructor " << endl;
		if (this->name){
			delete[] this->name;
			this->name = NULL;
		}
	}
	//Descr: create a new Flower (equal to a given Flower f)
	//In: a flower (f)
	//Out: a new flower (equal to f)
	Flower& operator=(const Flower &f){
		cout << "[Flower] : operator= " << endl;
		if (this != &f){
			if (this->name)
				delete[] this->name;
			this->name = new char[strlen(f.name) + 1];
			strcpy_s(this->name, strlen(f.name) + 1, f.name);
			noPetals = f.noPetals;
		}
		return *this;
	}
	//Descr: change the name of a flower 
	//In: a flower and a name
	//Out: the flower with changed name
	void setName(char* n){
		if (this->name)
			delete[] this->name;
		this->name = new char[strlen(n) + 1];
		strcpy_s(this->name, strlen(n) + 1, n);
	}
	//Descr: change the no of petals of a flower 
	//In: a flower and a no of petals
	//Out: the flower with changed no of petals
	void setNoPetals(int n){
		this->noPetals = n;
	}
	//Descr: access the name of a flower 
	//In: a flower 
	//Out: the name
	char* getName(){
		return this->name;
	}
	//Descr: access the no of petals of a flower 
	//In: a flower 
	//Out: the no of petals
	int getNoPetals(){
		return this->noPetals;
	}
	//Descr: convert a flower into a string
	//In: a flower 
	//Out: a string with info about the flower 
	char* toString(){
		int len = strlen(name) + strlen("this is flower  with  petals") + 6 + 1;
		char* s = new char[len];
		strcpy_s(s, len, "This is flower ");
		strcat_s(s, len, this->name);
		strcat_s(s, len, " ");
		char* aux = new char[6];
		_itoa_s(this->noPetals, aux, 6, 10);
		strcat_s(s, len, aux);
		strcat_s(s, len, " petals");
		delete[] aux;
		return s;
	}
	//Descr: compare 2 flowers (the current one and a new one)
	//In: two flowers 
	//Out: true/false
	bool operator==(Flower &f){
		return ((strcmp(this->name, f.name) == 0) && (this->noPetals == f.noPetals));
	}
	//Descr: compare 2 flowers (the current one and a new one)
	//In: two flowers 
	//Out: true/false
	bool operator<(Flower &f){
		if (noPetals < f.noPetals)
			return true;
		return false;
	}
	//Descr: compare 2 flowers (the current one and a new one)
	//In: two flowers 
	//Out: true/false
	bool operator>(Flower &f){
		if (noPetals > f.noPetals)
			return true;
		return false;
	}

	//Descr: load a flower from an input stream
	//In: an input stream
	//Out: a new Flower
	friend ostream& operator<<(ostream &os, Flower &f){
		os << f.name << " " << f.noPetals << endl;
		return os;
	}
	//IO operators
	//Descr: save a flower into an output stream
	//In: an output stream, a flower
	//Out: the output stream (loaded by info about flower)
	friend istream& operator>>(istream &is, Flower &f){
		char* s = new char[100];
		cout << "flower name = ";
		is >> s;
		f.setName(s);
		delete[] s;
		int n;
		cout << "no of petals = ";
		is >> n;
		f.setNoPetals(n);
		return is;
	}
};
#endif